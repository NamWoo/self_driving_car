#include "my_lib.h"
#include "option.h"
#include "2450addr.h"

extern unsigned int HandleDMA;
void WDT_Init(int timeout);

int laptime;
int dmaComplete= 0;

void DMA0_SW_Init(void);
void DMA0_Timer_Init(void);
void DMA0_UART_Init(void);
void DMA0_SW_Start(void);
void DMA0_HW_Start(void);

#define EXAMPLE 421
/*	
 * 420 : SW_DMA (실습 8-1 : SW DMA Trigger Test )				//메모리 에서 메모리로 1초기화와 시작 설정해줘야한다.
 *
 * 421 : UART_DMA (실습 8-2 : UART0 에 의한 DMA trigger Test)
 *	
 * Advanced Course
 * 1. make macro function 
 */

 void MEMCPY_SINGLE(unsigned long dst, unsigned long src, int size);
 
 /***************************************
 * 
 * Title: SW_DMA
 * 
 ***************************************/

#if EXAMPLE == 420			//메모리에서 메모리로 복사하는 예제 

//** ISR Function declaration 
 __attribute__((interrupt("IRQ"))) void DMA0_ISR(void);
// Global Variables Declaration
// 목적지는 CACHE 영역이 아닐것
unsigned int src=0x33F10000;					//소스메모리 주소  memory adress 우리 메모리는 30000000부터시작 
unsigned int dst=0x33F20000;					//목적지 주소
unsigned int size = 480; /* byte size */			//전송크기 만큼을 소스메모리에서 목적지로 보내라
unsigned int pattern;									//다음 주에 캐쉬, DMA쓸 때는 캐쉬 끄고 한다. DCache 'off'

 __attribute__((interrupt("IRQ"))) void DMA0_ISR(void)		//여기 뜨면 DMA 들어온 거 
{		
	/* TODO: Pendng Clear on DMA1 */
	rSUBSRCPND = 0x1<<18;		//SUBSRCPND  DMA0번 18로 설정 
	rSRCPND1 = 0x1<<17;
	rINTPND1 = 0x1<<17;						//인터럽트 상태 클리어 하기  밑 쓴 17 로 수정 하기 

	/*  TODO: Stop DMA0 trigger  */
	rDMASKTRIG0 |= 0x1<<2;

	Uart_Printf("__irq ISR실행결과  ");	
	MemDump(dst, size+16); 					//목적지 dst 화면에 덤프 중 	 

	//여기다가 dma 들어온거 플래그  dnaComplete = 1
}

void Main(void)
{	
	char value;

	// MMU 초기화
	MMU_Init();
	
	Uart_Init(115200);						
	DMA0_SW_Init();		// 초기화 

	Uart_Send_Byte('\n');
	Uart_Send_Byte('A');	
	Uart_Send_String("Hello Uart Test...!!!\n");
	
	/* 인터럽트 벡터에 DMA0_ISR 함수 등록 */			//인터럽트 핸들러 등록 
	HandleDMA = (unsigned int)DMA0_ISR;			//0번 DMA

	/*  인터럽트 허용 on DMA0 */		
	rINTMSK1 &= ~(0x1<<17);		//ch0 DMA mask 풀어 		// 이걸 보고 짐작 17 의미는 0번채널 인터럽트 번호 

	DMA0_SW_Start();							//DMA 시작  완료는 인터럽트 발생하면 알 수 있다.

	cnt = 0;

	ElapseTimer_Star();

	//1
	while(1)
	{
		cnt++
		if (damComplete)
		{
			elaseTime = ElapseTimer_Stop(); //2
			printf("cnt=%d\n"=,cnt);		// dma도하면서 씨피유도 도는?  758 막 가있으면 씨피유도 돌았다는 확인 

printf("		elaseTime	", 복사시간 확인 )//2
		}
}



}
# endif
 

/***************************************
 * 
 * Title: UART_DMA
 * 
 ***************************************/

#if EXAMPLE == 421


//** ISR Function declaration 
 __attribute__((interrupt("IRQ"))) void DMA0_ISR(void);
// Global Variables Declaration
// 목적지는 CACHE 영역이 아닐것
unsigned int src=0x33F10000;
unsigned int dst=0x33F20000;
unsigned int size = 480; /* byte size */
unsigned int pattern;

 __attribute__((interrupt("IRQ"))) void DMA0_ISR(void)
{
	/* TODO: Pendng Clear on DMA1 */
	rSUBSRCPND = 0x1<<19;	//
	rSRCPND1 = 0x1<<17;  //밑이 17 확인 하고 17로 바꿔주자 
	rINTPND1 = 0x1<<17;

	Uart_Printf("__irq ISR실행결과  ");	
	MemDump(dst, 12); 	// 화면에도 찍게 해부면. 밑에 했기에 주석처리 
	
	dmaComplete = 1; // DMA 전송완료		// 플래그, 끝났다는거 확인 
}

void Main(void)
{	
	// MMU 초기화
	MMU_Init();
	
	Uart_Init(115200);	
	DMA0_UART_Init();

	Uart_Send_Byte('\n');
	Uart_Send_Byte('A');	
	Uart_Send_String("Hello Uart Test...!!!\n");
	
	/* 인터럽트 벡터에 DMA0_ISR 함수 등록 */
	HandleDMA = (unsigned int)DMA0_ISR;
		
	/*  인터럽트 허용 on DMA */		
	rINTMSK1 &= ~(0x1<<17);

	DMA0_HW_Start();
	
	while(1){
	Uart_Printf("your input character\n");	
	    while(dmaComplete == 0); // DMA 전송이 완료될때까지 기다림...
	dmaComplete= 0;
	Uart_Printf("your input character is %s \n",  (unsigned char*)dst);
	}
}
# endif
