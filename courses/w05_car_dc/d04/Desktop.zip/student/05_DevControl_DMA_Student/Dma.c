/*
 * =====================================================================
 * NAME         : Dma.c
 *
 * Descriptions : DMA Test Driver
 *
 * IDE          : CodeWarrior 2.0 or Later
 *
 * Modification
 *     Modified by MDS Tech. NT Div.(2Gr) (2007.3.1~4)
 * =====================================================================
 */
#include "2450addr.h"
#include "my_lib.h"

// Global Variables Declaration
// 목적지는 CACHE 영역이 아닐것
extern unsigned long src;
extern unsigned long dst;
extern unsigned int size;
extern unsigned long pattern;

//Function Declatation
void DMA0_SW_Init(void);
void DMA0_Timer_Init(void);
void DMA0_UART_Init(void);
void DMA0_SW_Start(void);
void DMA0_HW_Start(void);

void DMA0_SW_Init(void)
{
	/* Init DMASKTRIG on DMA0*/
	rDMASKTRIG0 = 0x0;			// 
	
	/* TODO : Select Base Address of Source and Destination*/
	rDISRC0 = src;			//소스 주소 초기화
	rDIDST0 = dst;			//목적지 주소 초기화 
	
	/*  Init Source & Destination Control Register on DMA0 
	 * (memory -> AHB bus, INC mode, CHK_INT = after auto-reload)
	 */
	/* TODO : */ 
	rDISRCC0 = (0 << 1) | (0 << 0); 		//atribute속성셋팅  4.2 DMA INITIAL SOURCE CONTROL REGISTER (DISRCC)
	rDIDSTC0 = (0 << 2) | (0 << 1) | (0 << 0);

	/* TODO : setting for S/W DMA request
	 * DCON0 : Handshake[31-1], HCLK[30-1], INT mode[29-1], Single Unit[28-0], Whole service[27-1],
	 * HW_select[26:24],  S/W trigger[23-0], Auto Reload ON[22-0], Byte size[21:20](Note: Word size<->Byte size)
	 */
	rDCON0 = (0 << 31) | (0 << 30) | (0 << 29) | (0 << 28) | (0 << 27) | (0 << 24) | (0 << 23) \
	| (0 << 22) | (0 << 20) | ((size/4) << 0);

	rDMAREQSEL0 &=~ (1<<0); // software trigger 

}

void DMA0_UART_Init(void)
{
	/* Init DMASKTRIG on DMA0*/
	rDMASKTRIG1 = 0x0;
	
	/* TODO : Select Base Address of Source and Destination*/
	rDISRC1 = rURXH1; //rURXH1 register's Address	//아까는 소수 주소 메모리 주소 적었다. 이번엔 유아트 신호 글자 나오면 DMA 걸리는 그래서 여기는 주소 rURXH1버퍼의 주소 입력 
	rDIDST1 = dst; // 목적 메모리 글자 뚜둘긴게 rs버퍼에서 끝나는게 아니고 DMA 에서 새로운 메모리로 이동 
	
	/* TODO : Init Source & Destination Control Register on DMA1 
	 * (memory -> AHB bus, INC mode, CHK_INT -> after auto-reload )
   	 */
	rDISRCC1 = (1 << 1) | (1 << 0); // APB, FIXED			//아까는 둘다 인크리먼트  버스 선택 이번엔 APB 
	rDIDSTC1 = (0 << 2) | (0 << 1) | (0 << 0);

	
	/* TODO : setting for H/W DMA request
	 * DCON1 : Handshake[31-1], HCLK[30-1], INT mode[29-1], Single Unit[28-0], Whole service[27-1], 
	 * Uart1[26:24], H/W trigger[23-1], Auto Reload ON[22-0], Byte size[21:20](Note: Word size<->Byte size)
	 */						//26:25, 24 메모리에선 필요없다 아무거나 상관없다.
	//PADDRFIX 주변장치 fix 하려면 1로 해라 ?컨트롤 에서 24번 비트를 1로 

	rDCON1 = (1 << 31) | (1 << 30) | (1 << 29) | (0 << 28) | (1 << 27) | (1 << 24) | (0 << 23) \
	| (1 << 22) | (2 << 20) | (size/4 << 0);		//size/4   480로 4나눈 120 		//여기까지 컨트롤 레지스터 

//마지막 8의 의미는 8글자 


	rDMAREQSEL1 = (rDMAREQSEL1 &~ (0x1f<<1))|(22<<1); // hardware trigger 
	rDMAREQSEL1 |= 1;

	 /* TODO : Turn on Trigger*/
	rDMASKTRIG1 |= (1 << 1); // DMA CHANNEL 'ON'	
}

void DMA0_SW_Start(void)
{
	MemFill(src, 0x00000000, size);   // 소스 지우고
	MemFill(dst, 0x00000000, size);		// 목적지 지우
	Uart_Printf("\nStart Memory copy test With DMA\n");	
	
	/* memory copy test with DMA */
	pattern = 0x5555aaaa;			// 소스 메모리 채우면 목적지에 저 내용이 보인다. 
	Uart_Printf("Fill pattern [0x%08x] to [0x%08x]\n",pattern, src);
	MemFill(src, pattern, size);
	MemDump(src, size);				// 화면에 뿌려주는거 
	Uart_Printf("\nCopy from [0x%08x] to [0x%08x] by DMA\n",src, dst);
	
	/* TODO : Turn on Trigger*/			// 여기서부터 DMA시작 
	rDMASKTRIG0 |= (1<<1); // DMA CHANNEL 'ON'			// 코드 꽂고 
	
	/* TODO : Start S/W Trigger in S/W Request mode */
	rDMASKTRIG0 |= 1; // DMA START!!!								//전원 켜기 바로 !! 메모리 복사 할떄만! 
}

void DMA0_HW_Start(void)
{	
	MemFill(src, 0x00000000, size);
	MemFill(dst, 0x00000000, size);	
	Uart_Printf("\nStart Memory copy test With DMA\n");	
}
