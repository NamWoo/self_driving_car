#include "my_lib.h"

void mymic(void)
{

	// WM8960_LINVOL = 0x3f;		//111111  3f




	return 0;
}




void Main(void)
{
	
	// MMU_Init();

	Uart_Init(115200);
	Uart_Send_String("\nHello ARM !!!\n\n");

	mymic();

#if 0
	Play_Iis_speak();
#else
	Play_Iis_Bypass();
#endif
	for(;;);
	return ;

	
}


