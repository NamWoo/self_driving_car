#include "2440addr.h"
#include "option.h"

#define LCD_SIZE_X (320)
#define LCD_SIZE_Y (240)
#define CLKVAL  	4	   
#define HOZVAL 	   (LCD_SIZE_X-1)
#define LINEVAL    (LCD_SIZE_Y-1)

#define VBPD (10)
#define VFPD (10)
#define VSPW (5)
#define HBPD (10)
#define HFPD (10)
#define HSPW (5)


//Function Declaration
void Lcd_Port_Init(void);
void Lcd_Init(void);
void Put_Pixel(int x, int y, int color);
void Lcd_Draw_BMP(int x, int y, const unsigned char *fp);

static unsigned short bfType;
static unsigned int bfSize;
static unsigned int bfOffbits;
static unsigned int biWidth, biWidth2;
static unsigned int biHeight;

// Functions
void Lcd_Port_Init()
{
	rGPCCON &= ~(0xffffffff);
	rGPCCON |= 0xaaaaaaaa;
	
	rGPDCON &= ~(0xffffffff);
	rGPDCON |= 0xaaaaaaaa;	
}

void Lcd_Init()
{	
	rLCDCON1 |= (CLKVAL<<8)|(0<<7)|(3<<5)|(0xc<<1)|(0<<0);// YCbCr 8bit mode Enable
	rLCDCON2 |= (VBPD<<24)|(LINEVAL<<14)|(VFPD<<6)|(VSPW<0);
	rLCDCON3 |= (HBPD<<19)|(HOZVAL<<8)|(HFPD<<0);
	rLCDCON4 |= (0<<8)|(HSPW<07);
	rLCDCON5 |= (1<<11)|(1<<9)|(1<<8)|(1<<0);

	rLCDSADDR1= (((unsigned int)LCDFRAMEBUFFER>>22)<<21)+(0x1ffff&((unsigned int)LCDFRAMEBUFFER>>1));
	rLCDSADDR2 = 0x1ffff & ( ((unsigned int)0+(LCD_SIZE_X*LCD_SIZE_Y*2))>>1 );
	//rLCDSADDR2 = 0x17700;
	rLCDSADDR3=  ((0)<<11)|(LCD_SIZE_X);
	Uart_Printf("addr1 = 0x%x\n", rLCDSADDR1);
	Uart_Printf("addr2 = 0x%x\n", rLCDSADDR2);
	//rREDLUT    
	//rGREENLUT 
	//rBLUELUT 
	//rDITHMODE
	rTPAL = 0;   
	//rLCDINTPND  
	//rLCDSRCPND 
	//rLCDINTMSK 
	rTCONSEL &= ~(0x7);     
     
    rLCDCON1 |= 1;  	
}

#define  Lcd_Fb   ((volatile unsigned short int(*)[320]) LCDFRAMEBUFFER) 
 
void Put_Pixel(int x, int y, int color)
{
	Lcd_Fb[y][x] = (unsigned short int)color;	
	
	
//	if(x<SCR_XSIZE_TFT_240320 && y<SCR_YSIZE_TFT_240320)
//    Lcd_Fb[(y)][(x)/2]=( Lcd_Fb[(y)][x/2]
 //   & ~(0xffff0000>>((x)%2)*16) ) | ( (color&0x0000ffff)<<((2-1-((x)%2))*16) );
}

void Lcd_Draw_BMP(int x, int y, const unsigned char *fp)
{
     int xx=0, yy=0;	
     unsigned int tmp;
     unsigned char tmpR, tmpG, tmpB;
	
     bfType=*(unsigned short *)(fp+0);
     bfSize=*(unsigned short *)(fp+2);
     tmp=*(unsigned short *)(fp+4);
     bfSize=(tmp<<16)+bfSize;
     bfOffbits=*(unsigned short *)(fp+10);
     biWidth=*(unsigned short *)(fp+18);    
     biHeight=*(unsigned short *)(fp+22);    
     biWidth2=(bfSize-bfOffbits)/biHeight;	
     for(yy=0;yy<biHeight;yy++)
     {
         for(xx=0;xx<biWidth;xx++)
         {
             tmpB=*(unsigned char *)(fp+bfOffbits+(biHeight-yy-1)*biWidth*3+xx*3+0);
             tmpG=*(unsigned char *)(fp+bfOffbits+(biHeight-yy-1)*biWidth*3+xx*3+1);
             tmpR=*(unsigned char *)(fp+bfOffbits+(biHeight-yy-1)*biWidth*3+xx*3+2);
             tmpR>>=3;
             tmpG>>=3;
             tmpB>>=3;
             
             if(xx<biWidth2) Put_Pixel(x+xx,y+yy,(tmpR<<11)+(tmpG<<6)+(tmpB<<1));
         } 
     }
    
}