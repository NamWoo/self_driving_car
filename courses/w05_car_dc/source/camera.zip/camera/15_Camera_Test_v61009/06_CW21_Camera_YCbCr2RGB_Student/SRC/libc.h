/*
 * =====================================================================
 * NAME         : libc.h
 *
 * Descriptions : Definition of S3C2440 Library prototype
 *
 * IDE          : CodeWarrior 2.0 or Later
 *
 * Modification
 *	   2006.9.12 by JunGyu Park
 * =====================================================================
 */

extern void MemFill(unsigned long ptr, unsigned long pattern, int size);
extern void MemDump(unsigned long ptr, int size);

//Uart
void Uart_Init(int baud);
extern void Uart_Printf(char *fmt,...);
void Uart_Send_String(char *pt);
void Uart_Send_Byte(int data);
char Uart_Get_Char(void);

//Lcd
void Lcd_Port_Init(void);
void Lcd_Init(void);
void Put_Pixel(int x, int y, int color);
void Lcd_Draw_BMP(int x, int y, const unsigned char *fp);

//Camera
void Camera_Init(void);
void Camera_Port_Init(void);
void Camera_Start(void);
void Camera_Stop(void);
void Display_Cam_Image(unsigned int size_x, unsigned int size_y);
unsigned int Conv_YCbCr_Rgb(unsigned char y0, unsigned char y1, unsigned char cb0, unsigned char cr0);
void CalculatePrescalerRatioShift(unsigned int SrcSize, unsigned int DstSize, unsigned int *ratio,unsigned int *shift);
