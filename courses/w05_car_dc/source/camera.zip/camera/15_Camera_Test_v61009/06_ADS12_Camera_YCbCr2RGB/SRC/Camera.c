#include "2440addr.h"
#include "option.h"

#define CAM_SRC_HSIZE		(640)
#define CAM_SRC_VSIZE		(512)
#define WinHorOffset		0
#define WinVerOffset		0
//#define PrDstWidth		320
//#define PrDstHeight		240



//#define  Fb   ((volatile unsigned long(*)[160]) LCDFRAMEBUFFER) 

#define	YCbCrtoR(Y,Cb,Cr)	(1000*Y + 1371*(Cr-128))/1000
#define YCbCrtoG(Y,Cb,Cr)	(1000*Y - 336*(Cb-128) - 698*(Cr-128))/1000
#define	YCbCrtoB(Y,Cb,Cr)	(1000*Y + 1732*(Cb-128))/1000

//#define	YCbCrtoR(Y,Cb,Cr)	Y+0.956*Cb+0.621*Cr
//#define   YCbCrtoG(Y,Cb,Cr)	Y+0.272*Cb+0.647*Cr
//#define	YCbCrtoB(Y,Cb,Cr)	Y+1.1061*Cb+1.703*Cr

// Function 
void Camera_Init(void);
void Camera_Port_Init(void);
void Camera_Start(void);
void Camera_Stop(void);
void Display_Cam_Image(unsigned int size_x, unsigned int size_y);
unsigned int Conv_YCbCr_Rgb(unsigned char y0, unsigned char y1, unsigned char cb0, unsigned char cr0);
void CalculatePrescalerRatioShift(unsigned int SrcSize, unsigned int DstSize, unsigned int *ratio,unsigned int *shift);


void Camera_Port_Init()
{
	// Camera Port Init 
	rGPJCON = 0x2aaaaaa;
	rGPJDAT = 0;
	rGPJUP = 0;
}

void Camera_Init(void)
{
//	unsigned int MainBurstSizeRGB=16, RemainedBurstSizeRGB=16;
	unsigned int 	PreHorRatio, H_Shift, PreVerRatio,	V_Shift;
	unsigned int 	SrcWidth, SrcHeight,MainHorRatio, MainVerRatio ;
	unsigned int  	MainBurstSizeY,	RemainedBurstSizeY, MainBurstSizeC, RemainedBurstSizeC;
	unsigned int 	CoDstWidth, CoDstHeight;
		
	CoDstWidth=320;
    CoDstHeight=240;
	SrcWidth=CAM_SRC_HSIZE-WinHorOffset*2;	
	SrcHeight=CAM_SRC_VSIZE-WinVerOffset*2;

// Camera Clock ����  
	rCLKCON |= (1<<19); // enable camclk
	rUPLLCON = (60<<12) | (4<<4) | 1;	//upll���� 
	rCAMDIVN = (rCAMDIVN & ~(0xf))|(1<<4)|(0); // cam clock ���� - CAMCLK is divided..
	rCLKDIVN|=(1<<3); //upll = 96Mhz ������ ��� 

	rCIPRSCCTRL &= ~(1<<15);
// Camera Control Register Init 
	////////////////// common control setting
	rCIGCTRL |=(0<<31)|(1<<30)|(1<<29)|(0<<27)|(0<<26)|(0<<25)|(0<<24); // inverse PCLK, test pattern
	rCIWDOFST = (1<<30)|(0xf<<12); // clear overflow 
	rCIWDOFST = 0;	
	rCIWDOFST=(1<<31)|(WinHorOffset<<16)|(WinVerOffset);
	rCISRCFMT=(1<<31)|(0<<30)|(0<<29)|(CAM_SRC_HSIZE<<16)|(1<<14)|(CAM_SRC_VSIZE);

	
///////////////// codec port setting
		rCICOYSA1=CAM_FRAMEBUFFER;	
		rCICOYSA2=rCICOYSA1;
		rCICOYSA3=rCICOYSA1;
		rCICOYSA4=rCICOYSA1;
	
		rCICOCBSA1=rCICOYSA1+CoDstWidth*CoDstHeight;
		rCICOCBSA2=rCICOCBSA1;
		rCICOCBSA3=rCICOCBSA1;
		rCICOCBSA4=rCICOCBSA1;
		
		rCICOCRSA1=rCICOCBSA1+CoDstWidth*CoDstHeight/2; //divisor;
		rCICOCRSA2=rCICOCRSA1;
		rCICOCRSA3=rCICOCRSA1;
		rCICOCRSA4=rCICOCRSA1;
    
    Uart_Printf("   rCICOYSA1 = 0x%x \n", rCICOYSA1);
    Uart_Printf("   rCICOCBSA1 = 0x%x \n", rCICOCBSA1);
    Uart_Printf("   rCICOCRSA1 = 0x%x \n", rCICOCRSA1);	
		
//	rCIPRTRGFMT=(PrDstWidth<<16)|(0<<14)|(PrDstHeight);   
	rCICOTRGFMT=(1<<31)|(1<<30)|(CoDstWidth<<16)|(0<<14)|(CoDstHeight); 
//	rCIIMGCPT|=(1<<30);
//	rCIPRCTRL=(MainBurstSizeRGB<<19)|(RemainedBurstSizeRGB<<14); 
 	MainBurstSizeY = 16;
 	RemainedBurstSizeY=16;
 	MainBurstSizeC=16;
 	RemainedBurstSizeC=16;
 	
	rCICOCTRL=(MainBurstSizeY<<19)|(RemainedBurstSizeY<<14)|(MainBurstSizeC<<9)|(RemainedBurstSizeC<<4);

//	CalculatePrescalerRatioShift(SrcWidth, CoDstWidth, &PreHorRatio, &H_Shift);
//	CalculatePrescalerRatioShift(SrcHeight, CoDstHeight, &PreVerRatio, &V_Shift);
	PreHorRatio=2;
	H_Shift=1;
	PreVerRatio=2;
	V_Shift=1;  

//	rCIPRSCPRERATIO=((10-H_Shift-V_Shift)<<28)|(PreHorRatio<<16)|(PreVerRatio);		 
//	rCIPRSCPREDST=((SrcWidth/PreHorRatio)<<16)|(SrcHeight/PreVerRatio);
	rCICOSCPRERATIO=((10-H_Shift-V_Shift)<<28)|(PreHorRatio<<16)|(PreVerRatio);
	rCICOSCPREDST=((SrcWidth/PreHorRatio)<<16)|(SrcHeight/PreVerRatio);  
	
	MainHorRatio=(SrcWidth<<8)/(CoDstWidth<<H_Shift);
	MainVerRatio=(SrcHeight<<8)/(CoDstHeight<<V_Shift);
//	rCIPRSCCTRL=(1<<31)|(0<<30)|(1<<29)|(1<<28)|(MainHorRatio<<16)|(MainVerRatio);    
	rCICOSCCTRL=(0<<31)|(3<<29)|(MainHorRatio<<16)|(MainVerRatio); //409, 341
	rCICOTAREA= CoDstWidth*CoDstHeight*2;
	//rCIPRSTATUS
/*		         
		rCICOTRGFMT         
		rCICOCTRL          
		rCICOSCPRERATIO  
		rCICOSCPREDST
		rCICOSCCTRL 
		rCICOTAREA       
		rCICOSTATUS  */
	
}

void Camera_Start(void)
{
//	rCIIMGCPT|=(1<<30);
//	rCIPRSCCTRL|=1<<15;
//	camCodecStatus=0;
	rCICOSCCTRL|= 1<<15;
	rCIIMGCPT|=(1<<31);	
	rCIIMGCPT|=(1<<30);	
}

void Camera_Stop(void)
{
	
//	rCIPRSCCTRL|=1<<15;
	rCICOSCCTRL&= ~(1<<15);
	rCIIMGCPT&=~(1<<31);	
	rCIIMGCPT&=~(1<<30);
	
	rCICOCTRL |= (1<<2);
}

void Display_Cam_Image(unsigned int size_x, unsigned int size_y)
{
	unsigned char *buffer_y, *buffer_cb, *buffer_cr;
	unsigned char y0,y1,cb0,cr0;
	int r0,r1,g0,g1,b0,b1;
	unsigned int rgb_data0, rgb_data1; 
	unsigned int x, y;
	int temp;


		temp = 4;
//	Uart_Printf("Current Frame memory %d\n", temp);

		buffer_y = (unsigned char *)rCICOYSA1;
		buffer_cb = (unsigned char *)rCICOCBSA1;
		buffer_cr = (unsigned char *)rCICOCRSA1;

//	Uart_Printf("End setting : Y-0x%x, Cb-0x%x, Cr-0x%x\n", buffer_y, buffer_cb, buffer_cr);	


	for (y=0;y<size_y;y++) // YCbCr 4:2:2 format
	{
//		Uart_Printf("End setting : x=%d, Y=%d, Y-0x%x, Cb-0x%x, Cr-0x%x\n",x,y, *buffer_y, *buffer_cb, *buffer_cr);
	
		for (x=0;x<size_x;x+=2)
		{ 	
			rgb_data0 = Conv_YCbCr_Rgb(*buffer_y++, *buffer_y++, *buffer_cb++, *buffer_cr++);
			
			Fb[y][x/2] = rgb_data0;
		}
	} 
}


unsigned int Conv_YCbCr_Rgb(unsigned char y0, unsigned char y1, unsigned char cb0, unsigned char cr0)  // second solution... by junon
{
	// bit order is
	// YCbCr = [Cr0 Y1 Cb0 Y0], RGB=[R1,G1,B1,R0,G0,B0].
	
	int r0, g0, b0, r1, g1, b1;
	unsigned int rgb0, rgb1, rgb;
 
	#if 1 // 4 frames/s @192MHz, 12MHz ; 6 frames/s @450MHz, 12MHz
	r0 = YCbCrtoR(y0, cb0, cr0);
	g0 = YCbCrtoG(y0, cb0, cr0);
	b0 = YCbCrtoB(y0, cb0, cr0);
	r1 = YCbCrtoR(y1, cb0, cr0);
	g1 = YCbCrtoG(y1, cb0, cr0);
	b1 = YCbCrtoB(y1, cb0, cr0);
	#endif

	if (r0>255 ) r0 = 255;
	if (r0<0) r0 = 0;
	if (g0>255 ) g0 = 255;
	if (g0<0) g0 = 0;
	if (b0>255 ) b0 = 255;
	if (b0<0) b0 = 0;

	if (r1>255 ) r1 = 255;
	if (r1<0) r1 = 0;
	if (g1>255 ) g1 = 255;
	if (g1<0) g1 = 0;
	if (b1>255 ) b1 = 255;
	if (b1<0) b1 = 0;
	
	// 5:6:5 16bit format
	rgb0 = (((unsigned short)r0>>3)<<11) | (((unsigned short)g0>>2)<<5) | (((unsigned short)b0>>3)<<0);	//RGB565.
	rgb1 = (((unsigned short)r1>>3)<<11) | (((unsigned short)g1>>2)<<5) | (((unsigned short)b1>>3)<<0);	//RGB565.

	rgb = (rgb1<<16) | rgb0;

	return(rgb);
}

void CalculatePrescalerRatioShift(unsigned int SrcSize, unsigned int DstSize, unsigned int *ratio,unsigned int *shift)
{
	if(SrcSize>=64*DstSize) {
		Uart_Printf("ERROR: out of the prescaler range: SrcSize/DstSize = %d(< 64)\n",SrcSize/DstSize);
		while(1);
	}
	else if(SrcSize>=32*DstSize) {
		*ratio=32;
		*shift=5;
	}
	else if(SrcSize>=16*DstSize) {
		*ratio=16;
		*shift=4;
	}
	else if(SrcSize>=8*DstSize) {
		*ratio=8;
		*shift=3;
	}
	else if(SrcSize>=4*DstSize) {
		*ratio=4;
		*shift=2;
	}
	else if(SrcSize>=2*DstSize) {
		*ratio=2;
		*shift=1;
	}
	else {
		*ratio=1;
		*shift=0;
	}    	
}