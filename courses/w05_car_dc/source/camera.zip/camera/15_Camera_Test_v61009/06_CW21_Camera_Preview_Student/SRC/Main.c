/*
 * =====================================================================
 * NAME         : Main.c
 *
 * Descriptions : Main routine for S3C2440
 *
 * IDE          : CodeWarrior 2.0 or Later
 *
 * Modification
 *	   2006.9.12 by JunGyu Park
 * =====================================================================
 */
#include "2440addr.h"
#include "libc.h"

void __irq Cam_ISR(void);

void __irq Cam_ISR(void)
{
	rINTSUBMSK |= (1<<12);
	rINTMSK |= (1<<6);
	
	rSUBSRCPND |=(1<<12);
	rSRCPND |=(1<<6);
	rINTPND |=(1<<6);
	
	Uart_Printf("[P]");
	
	rINTSUBMSK &= ~(1<<12);
	rINTMSK &= ~(1<<6);	
	
}


void Main(void)
{	
	char i_value;
	Uart_Init(115200);
	
	Uart_Send_Byte('\n');
	Uart_Send_Byte('A');	
	Uart_Send_String("Hello Camera Test...!!!\n");
		
	Lcd_Port_Init();
	Lcd_Init();
	
	Camera_Port_Init();
	Camera_Init();
	
	pISR_CAM = (unsigned int)Cam_ISR;
	rINTSUBMSK &= ~(1<<12);
	rINTMSK &= ~(1<<6);
	
	Camera_Start();
	
	Uart_Send_String("Input value...!!!\n");
	i_value = (unsigned char)Uart_Get_Char();
	
	while(!(i_value & 's'));
	
	Camera_Stop();			
}

