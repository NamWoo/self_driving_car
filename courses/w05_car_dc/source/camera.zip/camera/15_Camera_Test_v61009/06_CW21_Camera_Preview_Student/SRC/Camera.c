#include "2440addr.h"
#include "libc.h"

// Define
#define CAM_SRC_HSIZE		(640)
#define CAM_SRC_VSIZE		(480)
#define WinHorOffset		112
#define WinVerOffset		20

#define PrDstWidth		320//2
#define PrDstHeight		240

// Functions Declaration
void Camera_Port_Init(void);
void Camera_Init(void);
void Camera_Start(void);
void Camera_Stop(void);

// Functions 
void Camera_Port_Init()
{
	//** TODO :  Camera Port Init 
	rGPJCON = /* YOUR CODE HERE */;
	rGPJDAT = 0;
	rGPJUP = 0;
}

void Camera_Init(void)
{
	unsigned int MainBurstSizeRGB, RemainedBurstSizeRGB;
	unsigned int 	PreHorRatio, H_Shift, PreVerRatio,	V_Shift;
	unsigned int 	SrcWidth, SrcHeight,MainHorRatio, MainVerRatio ;
	
	SrcWidth=CAM_SRC_HSIZE-WinHorOffset*2;	
	SrcHeight=CAM_SRC_VSIZE-WinVerOffset*2;
	
//** TODO : Camera Clock ����  
	rCLKCON |= (1<<19); // enable camclk
	rUPLLCON = /* YOUR CODE HERE */;	//upll���� 
	rCAMDIVN = (rCAMDIVN & ~(0xf))|(1<<4)|(0); // cam clock ���� - CAMCLK is divided..
	rCLKDIVN|=(1<<3); //upll = 96Mhz ������ ��� 
	
	
// Camera Control Register Init 
	////////////////// common control setting
	rCIGCTRL |=(0<<31)|(1<<30)|(1<<29)|(0<<27)|(1<<26)|(0<<25)|(0<<24); // inverse PCLK, test pattern
	rCIWDOFST = (1<<30)|(0xf<<12); // clear overflow 
	rCIWDOFST = 0;	
	rCIWDOFST=(1<<31)|(WinHorOffset<<16)|(WinVerOffset);
	rCISRCFMT=(1<<31)|(0<<30)|(0<<29)|(CAM_SRC_HSIZE<<16)|(1<<14)|(CAM_SRC_VSIZE);

	
///////////////// preview port setting
	rCIPRCLRSA1=/* YOUR CODE HERE */;
	rCIPRCLRSA2=rCIPRCLRSA1;
	rCIPRCLRSA3=rCIPRCLRSA1;
	rCIPRCLRSA4=rCIPRCLRSA1;  
		
	rCIPRTRGFMT=(PrDstWidth<<16)|(0<<14)|(PrDstHeight);
	  
	MainBurstSizeRGB=16;
	RemainedBurstSizeRGB=16;  
	rCIPRCTRL=(MainBurstSizeRGB<<19)|(RemainedBurstSizeRGB<<14);  
	
	PreHorRatio =2;
	H_Shift=1;
	PreVerRatio = 1;
	V_Shift=0;  
	
	rCIPRSCPRERATIO=/* YOUR CODE HERE */;		 
	rCIPRSCPREDST=/* YOUR CODE HERE */; 
	
	MainHorRatio=/* YOUR CODE HERE */;
	MainVerRatio=/* YOUR CODE HERE */;
		
	rCIPRSCCTRL=(1<<31)|(0<<30)|(1<<29)|(1<<28)|(MainHorRatio<<16)|(MainVerRatio);    
	rCIPRTAREA= PrDstWidth*PrDstHeight;
	//rCIPRSTATUS

	
}

void Camera_Start(void)
{

	rCIPRSCCTRL/* YOUR CODE HERE */
	rCIIMGCPT/* YOUR CODE HERE */

	
}

void Camera_Stop(void)
{
	rCIPRSCCTRL&=~(1<<15);
	rCIIMGCPT&=~(1<<29);
	rCIIMGCPT&=~(1<<31);	
	
	rCIPRCTRL |= (1<<2);
	
}