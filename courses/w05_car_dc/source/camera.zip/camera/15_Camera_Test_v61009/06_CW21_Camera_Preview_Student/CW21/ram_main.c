/*
 * File:		main.c
 * Purpose:		sample C Stationery program 
 *
 */

#include <stdio.h>

int main ()
{	
	printf("Hello World\n");
	return 0;
}