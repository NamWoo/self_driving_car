/*
 * =====================================================================
 * NAME         : Main.c
 *
 * Descriptions : Main routine for S3C2440
 *
 * IDE          : CodeWarrior 2.0 or Later
 *
 * Modification
 *	   2006.9.12 by JunGyu Park
 * =====================================================================
 */
#include "2440addr.h"
#include "libc.h"

static unsigned char flagCaptured_C=0 ;
void __irq Cam_ISR(void);

void __irq Cam_ISR(void)
{
	int i; 
	rINTSUBMSK |= (1<<11);
	rINTMSK |= (1<<6);
	

	
	Uart_Printf("[C]");
	
	rSUBSRCPND |= (1<<11);
	rSRCPND |= (1<<6);
	rINTPND |= (1<<6);
	
	flagCaptured_C = 1;
	
//	Display_Cam_Image(320,240);

//	for(i=0;i<0xffff;i++);
	

	rINTSUBMSK &= ~(1<<11);
	rINTMSK &= ~(1<<6);
}

void Main(void)
{	
	int i,j;
		
	Uart_Init(115200);
		
	Lcd_Port_Init();
	Lcd_Init();
	
	for(i=0;i<240;i++)
		for(j=0;j<320;j++)
			Put_Pixel(j,i,0xffff);
	for(i=0;i<120;i+=2)
		for(j=0;j<160;j+=2)
			Put_Pixel(j,i,0x33ff);
	
	Camera_Port_Init();
	Camera_Init();
	
	rSUBSRCPND |= (1<<11);
	rSRCPND |= (1<<6);
	rINTPND |= (1<<6);
	pISR_CAM = (unsigned int)Cam_ISR;
	rINTSUBMSK &= ~(1<<11);
	rINTMSK &= ~(1<<6);
	
	Camera_Start();
	
	while(1)
	{
		if(flagCaptured_C)
		{
			flagCaptured_C = 0;	
			Display_Cam_Image(320, 240);
	//		Uart_Printf("Display Image \n");
		}
	//		if (Uart_Get_Char()== '\r') break;
	}
	
	Camera_Stop();
	
	Uart_Send_Byte('\n');
	Uart_Send_Byte('A');	
	Uart_Send_String("Hello Camera Test...!!!\n");
	
	
			
}

