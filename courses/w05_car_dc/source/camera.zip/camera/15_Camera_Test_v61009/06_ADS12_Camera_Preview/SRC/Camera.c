#include "2440addr.h"
#include "libc.h"

#define CAM_SRC_HSIZE		(640)
#define CAM_SRC_VSIZE		(480)
#define WinHorOffset		112
#define WinVerOffset		20

#define PrDstWidth		320//2
#define PrDstHeight		240

// Function Declaration
void Camera_Port_Init(void);
void Camera_Init(void);
void Camera_Start(void);
void Camera_Stop(void);

// Functions 
void Camera_Port_Init()
{
	// Camera Port Init 
	rGPJCON = 0x2aaaaaa;
	rGPJDAT = 0;
	rGPJUP = 0;
}

void Camera_Init(void)
{
	unsigned int MainBurstSizeRGB, RemainedBurstSizeRGB;
	unsigned int 	PreHorRatio, H_Shift, PreVerRatio,	V_Shift;
	unsigned int 	SrcWidth, SrcHeight,MainHorRatio, MainVerRatio ;
	
	SrcWidth=CAM_SRC_HSIZE-WinHorOffset*2;	
	SrcHeight=CAM_SRC_VSIZE-WinVerOffset*2;
	
// Camera Clock ����  
	rCLKCON |= (1<<19); // enable camclk
	rUPLLCON = (60<<12) | (4<<4) | 1;	//upll���� 
	rCAMDIVN = (rCAMDIVN & ~(0xf))|(1<<4)|(0); // cam clock ���� - CAMCLK is divided..
	rCLKDIVN|=(1<<3); //upll = 96Mhz ������ ��� 
	
	
// Camera Control Register Init 
	////////////////// common control setting
	rCIGCTRL |=(0<<31)|(1<<30)|(1<<29)|(0<<27)|(1<<26)|(0<<25)|(0<<24); // inverse PCLK, test pattern
	rCIWDOFST = (1<<30)|(0xf<<12); // clear overflow 
	rCIWDOFST = 0;	
	rCIWDOFST=(1<<31)|(WinHorOffset<<16)|(WinVerOffset);
	rCISRCFMT=(1<<31)|(0<<30)|(0<<29)|(CAM_SRC_HSIZE<<16)|(1<<14)|(CAM_SRC_VSIZE);

	
///////////////// preview port setting
	rCIPRCLRSA1=LCDFRAMEBUFFER;
	rCIPRCLRSA2=LCDFRAMEBUFFER;
	rCIPRCLRSA3=LCDFRAMEBUFFER;
	rCIPRCLRSA4=LCDFRAMEBUFFER;  
		
	rCIPRTRGFMT=(PrDstWidth<<16)|(0<<14)|(PrDstHeight);
	  
	MainBurstSizeRGB=16;
	RemainedBurstSizeRGB=16;  
	rCIPRCTRL=(MainBurstSizeRGB<<19)|(RemainedBurstSizeRGB<<14);  
	PreHorRatio =2;
	H_Shift=1;
	PreVerRatio = 1;
	V_Shift=0;  
	rCIPRSCPRERATIO=((10-H_Shift-V_Shift)<<28)|(PreHorRatio<<16)|(PreVerRatio);		 
	rCIPRSCPREDST=((SrcWidth/PreHorRatio)<<16)|(SrcHeight/PreVerRatio); 
	
	MainHorRatio=(SrcWidth<<8)/(PrDstWidth<<H_Shift);
	MainVerRatio=(SrcHeight<<8)/(PrDstHeight<<V_Shift);
	rCIPRSCCTRL=(1<<31)|(0<<30)|(1<<29)|(1<<28)|(MainHorRatio<<16)|(MainVerRatio);    
	rCIPRTAREA= PrDstWidth*PrDstHeight;
	//rCIPRSTATUS

	
}

void Camera_Start(void)
{
//	rCIIMGCPT|=(1<<29);
	rCIPRSCCTRL|=1<<15;
	rCIIMGCPT|=(1<<31)|(1<<29);
	
//	rCIPRCTRL &= ~(1<<2);
	
}

void Camera_Stop(void)
{
	rCIPRSCCTRL&=~(1<<15);
	rCIIMGCPT&=~(1<<29);
	rCIIMGCPT&=~(1<<31);	
	
	rCIPRCTRL |= (1<<2);
	
}