#include "2440addr.h"
#include "option.h"
#include "libc.h"

#define LCD_SIZE_X (320)
#define LCD_SIZE_Y (240)
#define CLKVAL  	4	   
#define HOZVAL 	   (LCD_SIZE_X-1)
#define LINEVAL    (LCD_SIZE_Y-1)

#define VBPD (10)
#define VFPD (10)
#define VSPW (5)
#define HBPD (10)
#define HFPD (10)
#define HSPW (5)


//Function Declaration
void Lcd_Port_Init(void);
void Lcd_Init(void);
void Put_Pixel(int x, int y, int color);
void Lcd_Draw_BMP(int x, int y, const unsigned char *fp);

static unsigned short bfType;
static unsigned int bfSize;
static unsigned int bfOffbits;
static unsigned int biWidth, biWidth2;
static unsigned int biHeight;

void Lcd_Port_Init()
{
	rGPCCON &= ~(0xffffffff);
	rGPCCON |= 0xaaaaaaaa;
	
	rGPDCON &= ~(0xffffffff);
	rGPDCON |= 0xaaaaaaaa;	
}

void Lcd_Init()
{	
	rLCDCON1 |= (CLKVAL<<8)|(0<<7)|(3<<5)|(0xc<<1)|(0<<0);
	rLCDCON2 |= (VBPD<<24)|(LINEVAL<<14)|(VFPD<<6)|(VSPW<0);
	rLCDCON3 |= (HBPD<<19)|(HOZVAL<<8)|(HFPD<<0);
	rLCDCON4 |= (0<<8)|(HSPW<07);
	rLCDCON5 |= (0<<12)|(1<<11)|(0<<10)|(0<<9)|(1<<8)|(0<<3)|(0<<1)|(1<<0);

	rLCDSADDR1= ((LCDFRAMEBUFFER>>22)<<21)+(0x1ffff&(LCDFRAMEBUFFER>>1));
	rLCDSADDR2 = (0x1ffff & ((LCDFRAMEBUFFER + (LCD_SIZE_X)*(LCD_SIZE_Y*2))>>1));
//	rLCDSADDR3= LCD_SIZE_X/2>>11 | LCD_SIZE_X/2;
	//rREDLUT    
	//rGREENLUT 
	//rBLUELUT 
	//rDITHMODE
	rTPAL = 0;   
	//rLCDINTPND  
	//rLCDSRCPND 
	//rLCDINTMSK 
	rTCONSEL &= ~(0x7);     
     
    rLCDCON1 |= 1;  	
}

#define  Fb   ((volatile unsigned short(*)[320]) LCDFRAMEBUFFER) 
 
void Put_Pixel(int x, int y, int color)
{
	Fb[y][x] = (unsigned short int)color;	
	
}

void Lcd_Draw_BMP(int x, int y, const unsigned char *fp)
{
     int xx=0, yy=0;	
     unsigned int tmp;
     unsigned char tmpR, tmpG, tmpB;
	
     bfType=*(unsigned short *)(fp+0);
     bfSize=*(unsigned short *)(fp+2);
     tmp=*(unsigned short *)(fp+4);
     bfSize=(tmp<<16)+bfSize;
     bfOffbits=*(unsigned short *)(fp+10);
     biWidth=*(unsigned short *)(fp+18);    
     biHeight=*(unsigned short *)(fp+22);    
     biWidth2=(bfSize-bfOffbits)/biHeight;	
     for(yy=0;yy<biHeight;yy++)
     {
         for(xx=0;xx<biWidth;xx++)
         {
             tmpB=*(unsigned char *)(fp+bfOffbits+(biHeight-yy-1)*biWidth*3+xx*3+0);
             tmpG=*(unsigned char *)(fp+bfOffbits+(biHeight-yy-1)*biWidth*3+xx*3+1);
             tmpR=*(unsigned char *)(fp+bfOffbits+(biHeight-yy-1)*biWidth*3+xx*3+2);
             tmpR>>=3;
             tmpG>>=3;
             tmpB>>=3;
             
             if(xx<biWidth2) Put_Pixel(x+xx,y+yy,(tmpR<<11)+(tmpG<<6)+(tmpB<<1));
         } 
     }
    
}