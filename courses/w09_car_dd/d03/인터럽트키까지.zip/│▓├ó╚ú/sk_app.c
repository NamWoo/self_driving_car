/***************************************
 * Filename: sk_app.c
 * Title: Skeleton Device Application
 * Desc: Implementation of system call
 ***************************************/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <fcntl.h>

#include "sk_ioctl.h"

int main(void)
{
	  int fd;
	  
	  fd = open("/dev/SK",O_RDWR);
	 
	  ioctl(fd,IOCTL_LED_ON_TEST);
	  
	  close(fd);
	  return (0);
}
