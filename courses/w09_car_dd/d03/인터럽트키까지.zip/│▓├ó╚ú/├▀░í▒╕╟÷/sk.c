/***************************************
 * Filename: sk.c
 * Title: Skeleton Device
 * Desc: Implementation of system call
 ***************************************/
#include <linux/module.h>
#include <linux/init.h>
#include <linux/major.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/kernel.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include <linux/delay.h>
#include <linux/timer.h>
#include <linux/kdev_t.h>
#include <linux/device.h>
#include <linux/slab.h>   /* kmalloc() */
#include <linux/errno.h>    /* error codes */
#include <linux/types.h>    /* size_t */

#include "sk_ioctl.h"

#define DEVICE_NAME "ledon"

#define GPGCON *(volatile unsigned long *)(kva)
#define GPGDAT *(volatile unsigned long *)(kva + 4)

MODULE_LICENSE("GPL");

static int sk_major = 0, sk_minor = 0;
static int result;
static dev_t sk_dev;
static void *kva;

static struct cdev sk_cdev;

static int sk_register_cdev(void);

/* TODO: Define Prototype of functions */
static int sk_open(struct inode *inode, struct file *filp);
static int sk_release(struct inode *inode, struct file *filp);
static int sk_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos);
static int sk_read(struct file *filp, char *buf, size_t count, loff_t *f_pos);

/* TODO: Implementation of functions */
static int sk_open(struct inode *inode, struct file *filp)
{
    printk("Device has been opened...\n");
    
    /* H/W Initalization */
    kva = ioremap(0x56000060, 16);
    printk("kva = 0x%x\n", (int)kva);
    
    GPGDAT |= 0xf << 4;

    GPGCON &= ~(0xff << 8);
    GPGCON |= 0x55 << 8;

    return 0;
}

static int sk_release(struct inode *inode, struct file *filp)
{
    printk("Device has been closed...\n");
    
    return 0;
}

static int sk_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos)
{
	printk("sk_write is invoked\n");
	
	return count;
}

static int sk_read(struct file *filp, char *buf, size_t count, loff_t *f_pos)
{
	  printk("sk_read is invoked\n");
	  return 0;
}

static int sk_ioctl ( struct file *filp, unsigned int cmd, unsigned long arg)  
{  
	
	ioctl_buf *k_buf;
	int   i,err, size;  
	volatile int j;
	unsigned int kcmd;

	if( _IOC_TYPE( cmd ) != IOCTL_MAGIC ) return -EINVAL;  
	if( _IOC_NR( cmd )   >= IOCTL_MAXNR ) return -EINVAL;  

	size = _IOC_SIZE( cmd );   

	if( size )  
	{  
	err = -EFAULT;  
	if( _IOC_DIR( cmd ) & _IOC_READ  ) 
		err = !access_ok( VERIFY_WRITE, (void __user *) arg, size );  
	else if( _IOC_DIR( cmd ) & _IOC_WRITE ) 
		err = !access_ok( VERIFY_READ , (void __user *) arg, size );  
	if( err ) return err;          
	}  
	
	kcmd = cmd;
	for(i=0; i<5; i++){
		switch( kcmd )  
		{  

		case IOCTL_LED_ON_TEST1 :
		    	
			printk("LED on\n");
			GPGDAT &= ~(0xf  <<  4);
			for(j=0; j<30; j++)
			{
				GPGDAT ^= (0xf << 4);
				mdelay(1000);
			}
		    break;
		    	       
		case IOCTL_MYDRV_WRITE :
			k_buf = kmalloc(size,GFP_KERNEL);
			if(copy_from_user(k_buf,(void __user *) arg,size))
				return -EFAULT;
			printk("k_buf = %s\n",k_buf->data);
			if(strcmp(k_buf, "LED") == 0) kcmd = IOCTL_LED_ON_TEST1;
			else printk("command error!!\n");
			kfree(k_buf);
			printk("IOCTL_MYDRV_WRITE Processed!!\n");
			break;	
		}	        
	}
	return 0;  
}  
struct file_operations sk_fops = { 
    .open       = sk_open,
    .release    = sk_release,
	.write		= sk_write,
	.read		= sk_read,
	.unlocked_ioctl = sk_ioctl,
};

static int __init sk_init(void)
{
    printk("SK Module is up... \n");

	if((result = sk_register_cdev()) < 0)
	{
		return result;
	}

    return 0;
}

static void __exit sk_exit(void)
{
    printk("The module is down...\n");
	cdev_del(&sk_cdev);
	unregister_chrdev_region(sk_dev, 1);
}

static int sk_register_cdev(void)
{
	int error;

	/* allocation device number */
	if(sk_major) {
		sk_dev = MKDEV(sk_major, sk_minor);
		error = register_chrdev_region(sk_dev, 1, "sk");
	} else {
		error = alloc_chrdev_region(&sk_dev, sk_minor, 1, "sk");
		sk_major = MAJOR(sk_dev);
	}

	if(error < 0) {
		printk(KERN_WARNING "sk: can't get major %d\n", sk_major);
		return result;
	}
	printk("major number=%d\n", sk_major);

	/* register chrdev */
	cdev_init(&sk_cdev, &sk_fops);
	sk_cdev.owner = THIS_MODULE;
	sk_cdev.ops = &sk_fops;
	error = cdev_add(&sk_cdev, sk_dev, 1);

	if(error)
		printk(KERN_NOTICE "sk Register Error %d\n", error);

	return 0;
}



module_init(sk_init); 
module_exit(sk_exit); 
