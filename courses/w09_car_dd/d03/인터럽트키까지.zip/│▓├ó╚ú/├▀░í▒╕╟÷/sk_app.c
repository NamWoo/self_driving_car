/***************************************
 * Filename: sk_app.c
 * Title: Skeleton Device Application
 * Desc: Implementation of system call
 ***************************************/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <fcntl.h>

#include "sk_ioctl.h"

int main(void)
{
	int fd,i,size;
	ioctl_buf *buf_in,*buf_out;

	size = sizeof(ioctl_buf);
	//buf_in = (ioctl_buf *)malloc(size);
	buf_out = (ioctl_buf *)malloc(size);

	fd = open("/dev/SK",O_RDWR);
	
	printf("command(1) :");
	gets(buf_out);
	ioctl(fd, IOCTL_MYDRV_WRITE, buf_out );

	ioctl(fd,IOCTL_LED_ON_TEST1);
	
	free(buf_out);
	close(fd);
	return (0);
}
