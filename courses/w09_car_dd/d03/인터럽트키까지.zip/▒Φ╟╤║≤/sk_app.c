/***************************************
 * Filename: sk_app.c
 * Title: Skeleton Device Application
 * Desc: Implementation of system call
 ***************************************/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <termio.h>
#define IOCTL_MAGIC    254

typedef struct
{
	unsigned char data[26];	
	
} __attribute__ ((packed)) ioctl_buf;

#define IOCTL_MYDRV_TEST                _IO(  IOCTL_MAGIC, 0 )
#define IOCTL_MYDRV_READ                _IOR( IOCTL_MAGIC, 1 , ioctl_buf )
#define IOCTL_MYDRV_WRITE               _IOW( IOCTL_MAGIC, 2 , ioctl_buf )
#define IOCTL_MYDRV_WRITE_READ     _IOWR( IOCTL_MAGIC, 3 , ioctl_buf )

#define IOCTL_LED0_ON	_IO(IOCTL_MAGIC, 0)
#define IOCTL_LED1_ON	_IO(IOCTL_MAGIC, 1)
#define IOCTL_LED2_ON	_IO(IOCTL_MAGIC, 2)
#define IOCTL_LED3_ON	_IO(IOCTL_MAGIC, 3)
#define IOCTL_LED_OFF	_IO(IOCTL_MAGIC, 4)
#define IOCTL_MAXNR                   4



int main(void)
{
    int retn;
    int fd, flag, i, N;

    // char buf[100] = "write...\n";
    char buf[100] = {0};
    
    fd = open("/dev/SK", O_RDWR);
    printf("fd = %d\n", fd);
    if (fd<0) {
        perror("/dev/SK error");
        exit(-1);
    }
    else
        printf("SK has been detected...\n");
    
    //  retn = write(fd, buf, 10);
    while(1)
    {
    	printf("input num: ");
    	scanf("%d", &N);
    	if(N==0)     retn = ioctl(fd, IOCTL_LED0_ON);
	if(N==1)     retn = ioctl(fd, IOCTL_LED1_ON);
	if(N==2)     retn = ioctl(fd, IOCTL_LED2_ON);
	if(N==3)     retn = ioctl(fd, IOCTL_LED3_ON);
	if(N==4) 	 retn = ioctl(fd, IOCTL_LED_OFF);
	if(N==5)
	{
		printf("\ndata : %s\n", buf);
		close(fd);
		break;
	}
    }
    //retn = read(fd, buf, 20); // fd�� ����Ű�� ���Ͽ� buf���� 20byte ����
    //close(fd);
    return 0;
}
