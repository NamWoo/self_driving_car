/*
  mydrv.c - kernel 2.6 skeleton device driver
               copy_to_user()
 */

#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/kernel.h>   /* printk() */
#include <linux/slab.h>   /* kmalloc() */
#include <linux/fs.h>       /* everything... */
#include <linux/errno.h>    /* error codes */
#include <linux/types.h>    /* size_t */
#include <asm/uaccess.h>
#include <linux/kdev_t.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <asm/io.h>
#include <linux/major.h>
#include <linux/delay.h>
#include <linux/timer.h>

#define DEVICE_NAME "myled"

#define GPGCON *(volatile unsigned long *)(kva)
#define GPGDAT *(volatile unsigned long *)(kva + 4)

static int myled_major = 240;
static int myled_minor = 0;
static int result;
//static int dev_t myled_dev;
static void *kva;

#define MAX_MYLED_DEV 1

static int myled_open(struct inode *inode, struct file *file)
{
  printk("myled opened !!\n");
  
  /* H/W Initalization */
  kva = ioremap(0x56000060, 28);
  printk("kva = 0x%x\n", (int)kva);
    
  GPGDAT |= 0xf << 4;

  GPGCON &= ~(0xff << 8);
  GPGCON |= 0x55 << 8;
  return 0;
}

static int myled_release(struct inode *inode, struct file *file)
{
  printk("myled released !!\n");
  return 0;
}

static ssize_t myled_read(struct file *filp, char __user *buf, size_t count,loff_t *f_pos)
{
  printk("myled_read is invoked\n");
  return 0;
}

static ssize_t myled_write(struct file *filp,const char __user *buf, size_t count,
                            loff_t *f_pos)
{
  volatile int i;
  printk("LED on\n");
  GPGDAT &= ~(0xf  <<  4);
  printk("myled_write is invoked\n");
  return 0;
}

static struct file_operations mydrv_fops = {
	.owner   = THIS_MODULE,
   	.read	   = myled_read,
    	.write     = myled_write,
	.open    = myled_open,
	.release = myled_release,
};

static int myled_init(void)
{
	int result;
	static void *kva;
	dev_t dev = MKDEV(myled_major, 0);

	/* Figure out our device number. */
	if (myled_major)
		result = register_chrdev_region(dev, 1, DEVICE_NAME);
	else {
		result = alloc_chrdev_region(&dev,0, 1, DEVICE_NAME);
		myled_major = MAJOR(dev);
	}
	if (result < 0) {
		printk(KERN_WARNING "myled: unable to get major %d\n",
 myled_major);
		return result;
	}
	if (myled_major == 0) {
		myled_major = result;
	}



	kva = ioremap(0x56000060,28) ;
	printk("kva = 0x%x\n",(int)kva);
	printk("myled_init done\n");	
	return 0;
}

static void myled_exit(void)
{
	unregister_chrdev_region(MKDEV(myled_major, 0), 1);
	printk("myled_exit done\n");
}

module_init(myled_init);
module_exit(myled_exit);

MODULE_LICENSE("Dual BSD/GPL");
