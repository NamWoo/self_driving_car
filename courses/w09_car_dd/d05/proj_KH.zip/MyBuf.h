typedef struct 
{
    int Pid;
    int Signal;
    int ProcessNumber;
    char Command[30];
}MyBuf;