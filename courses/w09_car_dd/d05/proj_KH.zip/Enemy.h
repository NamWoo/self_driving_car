#ifndef __SHARE_MEMORY_H__
#define __SHARE_MEMORY_H__

#define SHM_INFO_COUNT 30

typedef struct EnemyInfo_{
  char name[20];
	unsigned int CurrentHP;
  unsigned int CurrentMP;
}EnemyInfo;
#endif//__SHARE_MEMORY_H__

