/***************************************
 * Filename: sk_app.c
 * Title: Skeleton Device Application
 * Desc: Implementation of system call
 ***************************************/
#include <sys/ioctl.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <signal.h>
#include <pthread.h>
#include <sys/shm.h>
#include <sys/ipc.h>

//TODO �۴� custome Header
#include "myioctl.h"
#include "MyBuf.h"
#include "Enemy.h"

#define SIZE_OF_BUF 100
#define SetCursorPosition(x,y) printf("\033[%d;%dH", (y), (x))

int ThreadArgs[2] = {0,1};
pthread_t Threads[2];


//.bss
MyBuf buf;
int fd;
int PosX, PosY;
int dmg;

void* MeleeAttackThread(void*);
void* RangeAttackThread(void*);

//TODO �ñ״��� ������ �ٽ� �����غ��� 
void* MeleeAttackThread(void* something)
{
    // system("cls");
    int atkcnt;
    for(atkcnt=0; atkcnt<0x1000;++atkcnt)
    {
        
        SetCursorPosition(PosX,PosY);
        printf("Melee...[%5d] : [%d] ",atkcnt,buf.Pid);
    }
    pthread_exit(0);
}

void* RangeAttackThread(void* something)
{
    // system("cls");
    int atkcnt;
    for(atkcnt=0; atkcnt<0x1000;++atkcnt)
    {
        
        SetCursorPosition(PosX,PosY+1);
        printf("Ranged...[%5d] : [%d] ",atkcnt,buf.Pid);
    }
    pthread_exit(0);
}


//TODO ���ݽ��� ������ ,Ŀ�ο��� SIGUSR2 �� ������ �����ϱ� 
void AttackSignalHandler(int signo)
{
    if(signo == SIGUSR2)
    {
        // TODO thread run 
        printf("[USER] : thread on !\n");
        		/*TODO: initialize thread atrribute variable here */ 
        

        pthread_create(&Threads[0],NULL, RangeAttackThread,&ThreadArgs[0]);
        pthread_create(&Threads[1],NULL, MeleeAttackThread,&ThreadArgs[1]);
        
    }

    
}

void KillSignalHandler(int signo)
{
    if(signo==SIGUSR1)
    {
        printf("%d got SIGUSR1 !... closing..\n\n",buf.Pid);
        exit(0);
    }
    return;
}

int main(void)
{
    int retn;
    int pid;
    int enemyshmid;

    //TODO enemy �����޸� ����� 
    EnemyInfo* enemy = NULL;
    enemyshmid = shmget((key_t)3836, sizeof(EnemyInfo), 0666|IPC_CREAT);

    

	system("rm /dev/MyProject");
	system("rmmod sk.ko");
	system("insmod sk.ko");
	system("mknod /dev/MyProject c 240 0");


    fd = open("/dev/MyProject", O_RDWR);
    if (fd < 0)
    {
        perror("/dev/MyProject error");
        exit(-1);
    }

    //fork �ؼ� ���μ��� ����� ���μ��� ID �Ѱ��ֱ�

    //pid �޾ƿ���
    pid = fork();

    if (pid == -1)
    {
        printf("fork failed \n");
    }
    else if (pid == 0)
    {
        PosX = 0;
        PosY = 5;

        buf.Pid = getpid();
    }
    else
    {
        PosX = 0;
        PosY = 10;
        buf.Pid = getpid();
    }

    //signal ��� 
    signal(SIGUSR1,KillSignalHandler);
    signal(SIGUSR2,AttackSignalHandler);
    //TODO register process ID 
    write(fd,&buf.Pid , sizeof(buf));
    read(fd,&buf.Pid,sizeof(buf));

    if(pid!=0)
    {
        // printf("\nOK I'm Parent [%d] input \"END\" to kill procs and close dev \n",pid);
        // fgets(buf.Command,sizeof(buf.Command),stdin);
        // buf.Command[strlen(buf.Command)-1] = '\0';
        // write(fd,buf.Command,sizeof(buf.Command));

        ioctl(fd,LED_OFF_1);
    }
    
    while (1){}
    

    close(fd);
    
    //TODO �����޸� ���� �Ǵ��� �� Ȯ���ϱ�..
    shmctl( enemyshmid, IPC_RMID, 0);
    printf("shared memory is Deallocated...");
    return 0;
}
