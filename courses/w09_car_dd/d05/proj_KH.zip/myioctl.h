

#define LED_ON_1 _IO(1,0)
#define LED_ON_2 _IO(2,1)
#define LED_ON_3 _IO(3,2)
#define LED_ON_4 _IO(4,3)

#define LED_OFF_1 _IO(5,4)
#define LED_OFF_2 _IO(6,5)
#define LED_OFF_3 _IO(7,6)
#define LED_OFF_4 _IO(8,7)

