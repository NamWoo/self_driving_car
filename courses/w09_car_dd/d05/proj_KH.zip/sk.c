/***************************************
 * Filename: sk.c
 * Title: Skeleton Device
 * Desc: Implementation of system call
 ***************************************/
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kernel.h>
#include <linux/major.h>

#include <linux/init.h>
#include <linux/delay.h>
#include <linux/timer.h>

#include <linux/interrupt.h>
// Kernel headers
#include <asm/io.h>
#include <mach/gpio.h>
#include <mach/regs-gpio.h>
#include <linux/types.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/errno.h>
#include <linux/device.h>
#include <asm/irq.h>
#include <asm/uaccess.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <linux/interrupt.h>

// custom Headers
#include "Myioctl.h"
#include "myprockill.h"
#include "MyBuf.h"

MODULE_LICENSE("GPL");

static int sk_major = 240, sk_minor = 0;
static int result;
static int UserPIDs[20];
static int CurrentProcessSize = 0;
static dev_t sk_dev;
struct timer_list timer;
static struct cdev sk_cdev;
static int sk_register_cdev(void);

static int sk_open(struct inode *inode, struct file *filp);
static int sk_release(struct inode *inode, struct file *filp);
static int sk_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos);
static int sk_read(struct file *filp, char *buf, size_t count, loff_t *f_pos);

// TODO Timer
void KillTimer(unsigned long data);

// LED 켜주는 MACRO
#define GPGCON *(volatile unsigned int *)ledReg
#define GPGDAT *((volatile unsigned int *)ledReg + 1)

// KEY 인터럽트를 위한 Macro
#define GPFCON *(volatile unsigned int *)keyReg
#define GPFDAT *((volatile unsigned int *)keyReg + 1)

#define GPFUDP *((volatile unsigned int*)keyReg+2)

#define KEY_IRQ_OPTION IRQF_DISABLED | IRQF_TRIGGER_RISING
#define DRV_NAME "Project"

#define SetCursorPosition(x,y) printk("\033[%d;%dH", (y), (x))
static int Myioctl(struct file *filp, unsigned int cmd, unsigned long arg);

//TODO LED mapping - GPGCON, GPGDAT mapping 하기
static void *ledReg;
static void *keyReg;


static int ParentIdx;
static int ChildIdx;


// TODO 키 인터럽트 작성

static irqreturn_t LowerKeyInterrupt(int irq, void *dev_id, struct pt_regs *regs)
{
	int i;
	
	SetCursorPosition(20,20);
	printk("Lower key Pressed, sending SIGUSR2 to Child : [%d]",UserPIDs[ChildIdx]);
	printk("  %0x  \n", (GPFDAT >> 2));
	
//TODO Child idx 구하기 
	ChildIdx = 1;
	my_kill_proc(UserPIDs[ChildIdx],SIGUSR2);

	//TODO 5개 키 polling 
	// for (i = 2; i <= 6; ++i)
	// {
	// 	if (GPFDAT & (0x1 << i))
	// 	{
	// 		printk("key %d pressed\n", i);
	// 	}
	// }
	return IRQ_HANDLED;
}
static irqreturn_t UpperKeyInterrupt(int irq, void *dev_id, struct pt_regs *regs)
{

	
	printk("Upper Key Pressed, seding SIGUSR2 to parent");


//TODO Parent Idx 구하기 
	my_kill_proc(UserPIDs[ParentIdx],SIGUSR2);
	printk("  %0x  \n", (GPFDAT >> 2));
	
	return IRQ_HANDLED;
}

// TODO 워크함수 작성 (인터럽트 핸들러용..?) 나중에하기

void AttackTimer(unsigned long data)
{
	return;
}


//TODO Timer 구현(공격 시그널 주기)
void KillTimer(unsigned long data)
{
	if (CurrentProcessSize == 0)
	{
		printk("\n All Process are cleaned  !\n");
		del_timer(&timer);
		return;
	}
	my_kill_proc(UserPIDs[--CurrentProcessSize], SIGUSR1);
	printk("\n sending SIGUSR1 TO %d ....\n", UserPIDs[CurrentProcessSize]);

	timer.expires = jiffies + HZ / 2;
	add_timer(&timer);
}

static int sk_open(struct inode *inode, struct file *filp)
{
	printk("Device has been opened...\n");

	return 0;
}

static int sk_release(struct inode *inode, struct file *filp)
{
	printk("Device has been closed...\n");
	GPGDAT |= (0xf << 4);

	printk("\n\nKilling Procs Started !..\n");
	init_timer(&timer);
	timer.expires = jiffies + 1 * HZ;
	timer.function = KillTimer;
	add_timer(&timer);
	return 0;
}

static int sk_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos)
{
	char data[100];
	copy_from_user(data, buf, count);

	get_user(UserPIDs[CurrentProcessSize], (int *)buf);
	printk("===============\n\nregistered Process num is :%d \n\n===================", UserPIDs[CurrentProcessSize++]);

	return count;
}

static int sk_read(struct file *filp, char *buf, size_t count, loff_t *f_pos)
{
	return 0;
}

struct file_operations sk_fops = {
		.open = sk_open,
		.release = sk_release,
		.unlocked_ioctl = Myioctl,
		.write = sk_write,
		.read = sk_read,
};

static int __init sk_init(void)
{

	printk("SK Module is up... LED ON\n");

	// KEY INT INIT
	s3c_gpio_cfgpin(S3C2410_GPG(0), S3C_GPIO_SFN(2));
	s3c_gpio_cfgpin(S3C2410_GPF(7), S3C_GPIO_SFN(2));



	/* H/W Initalization */
	ledReg = ioremap(0x56000060, 8);
	keyReg = ioremap(0x56000050, 10);
	

	// input 모드로 바꿈 
	GPFCON &= ~(0x3ff<<4);
	GPFUDP &= ~(0x1f<<2);
  
	//LED Init and turn on
	GPGCON &= ~(0xff) << 8;
	GPGCON |= (0x55 << 8);
	GPGDAT &= ~(0xf) << 4;

	//enable interrupt
	request_irq(IRQ_EINT8, (void *)LowerKeyInterrupt, KEY_IRQ_OPTION, DRV_NAME, NULL);
	request_irq(IRQ_EINT7, (void *)UpperKeyInterrupt, KEY_IRQ_OPTION, DRV_NAME, NULL);

	if ((result = sk_register_cdev()) < 0)
	{
		return result;
	}

	return 0;
}

static void __exit sk_exit(void)
{
	printk("The module is down...\n");
	cdev_del(&sk_cdev);
	unregister_chrdev_region(sk_dev, 1);
	free_irq(IRQ_EINT8, NULL);
	free_irq(IRQ_EINT7, NULL);



	return;
}

static int sk_register_cdev(void)
{
	int error;

	/* allocation device number */
	if (sk_major)
	{
		sk_dev = MKDEV(sk_major, sk_minor);
		error = register_chrdev_region(sk_dev, 1, "Project");
	}
	else
	{
		error = alloc_chrdev_region(&sk_dev, sk_minor, 1, "Project");
		sk_major = MAJOR(sk_dev);
	}

	if (error < 0)
	{
		printk(KERN_WARNING "Project: can't get major %d\n", sk_major);
		return result;
	}
	printk("major number=%d\n", sk_major);

	/* register chrdev */
	cdev_init(&sk_cdev, &sk_fops);
	sk_cdev.owner = THIS_MODULE;
	sk_cdev.ops = &sk_fops;
	error = cdev_add(&sk_cdev, sk_dev, 1);

	if (error)
		printk(KERN_NOTICE "Project Register Error %d\n", error);

	return 0;
}

module_init(sk_init);
module_exit(sk_exit);

static int Myioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	switch (cmd)
	{
	case LED_ON_1:
		GPGDAT &= ~(1 << 4);
		break;
	case LED_ON_2:
		GPGDAT &= ~(1 << 5);
		break;
	case LED_ON_3:
		GPGDAT &= ~(1 << 6);
		break;
	case LED_ON_4:
		GPGDAT &= ~(1 << 7);
		break;
	case LED_OFF_1:
		GPGDAT |= (1 << 4);
		break;
	case LED_OFF_2:
		GPGDAT |= (1 << 5);
		break;
	case LED_OFF_3:
		GPGDAT |= (1 << 6);
		break;
	case LED_OFF_4:
		GPGDAT |= (1 << 7);
		break;
	default:
		break;
	}

	return 0;
}
