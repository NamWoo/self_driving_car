#include <linux/module.h>	/* Needed by all modules */
#include <linux/kernel.h>	/* Needed for KERN_INFO	*/
#include <linux/init.h>		/* Needed for the macros */
#include <linux/slab.h>

// #include <stdlib.h> user library cannot include

#define	DRIVER_AUTHOR	"bkh"
#define	DRIVER_DESC		"my driver"

static int recursive(int n);
//static int memoryTest(void);
static int __init INIT_HELLO_4(int a, int b );

static void kmallocTest()
{
int* myNum = (int*)kmalloc(4,GFP_KERNEL);
*myNum = 100;
printk("my allocked num is %d",*myNum);
kfree(myNum);
printk("freed my num");
}

static void __init main(int argc, char** argv)
{
//cannot send parameter 
//	printk("parameter send %s %s\n", argv[2],argv[3]);
	recursive(10);
kmallocTest();
//	memoryTest();

}


// 반복문 possible
static int recursive(int n)
{
printk("current num is  = %d\n", n);
if(n==1)
{
return 1;
}
return recursive(n-1)+n;
}

//memalloc X 
/*
static void memoryTest(void)
{
int *numptr = (int*)malloc(sizeof(int));
*numptr = 199;
printk("memory allocation : %d\n", *numptr);

}
*/

static int __init INIT_HELLO_4(int a, int b )
{

/*
int* myNum = (int*)malloc(sizeof(int));
*myNum = 100;
*/
//printk("malloc num is %d",*myNum);
	
//KERN_INFO 빼고 해도 문제 없었음 
int i=0;
for(i=0; i<10; ++i)
{
printk("adding num = %d\n",a+b);
	printk(", world 4.\n");
	printk(KERN_INFO "Hello, world 4.\n");
}
	return 0;
}

static void __exit cleanup_hello_4(void)
{
	printk(KERN_INFO "Goodbye, world 4.\n");
	printk(KERN_INFO "Goodbye, world 4.\n");
	printk(KERN_INFO "Goodbye, world 4.\n");
	printk(KERN_INFO "Goodbye, world 4.\n");
	printk(KERN_INFO "Goodbye, world 4.\n");
}

//module_init(INIT_HELLO_4);
module_init(main);
module_exit(cleanup_hello_4);
/* Get rid of taint message by declaring code as GPL. */
MODULE_LICENSE("MIT");
MODULE_AUTHOR(DRIVER_AUTHOR);		/* Who wrote this module? */
MODULE_DESCRIPTION(DRIVER_DESC);	/* What does this module do */
MODULE_SUPPORTED_DEVICE("testdevice");
