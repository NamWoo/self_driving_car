typedef struct node
{
    struct node* Next;
    int Data;
}Node;


typedef struct list
{
    Node* Head;
    Node* Tail;
}List;

//  리스트 초기화하기 (초기화할 리스트 받기, 동적할당 해제를 해주는 함수등록하기)
void InitList(List* list);

//  리스트 제거하기 제거할게 없으면 -1 반환 성공시 0
int DestroyList(List* list);

// 노드를 idx 번쨰에 리스트에 넣는다 실패시 -1, 성공시 0반환
int InsertNodeIntoList(Node* element,int idx, List* list);

//idx 번째의 노드의 데이터를 가져온다
int GetIdxData(List* list, int idx);

// 리스트의 사이즈를 반환
int GetListSize(List* list);


void TestList();
