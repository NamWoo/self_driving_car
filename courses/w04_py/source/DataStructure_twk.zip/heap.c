#include "heap.h"
#include <stdio.h>

void TestHeap()
{
    printf(" Test Heap OK\n");
}