#include <malloc.h>
#include <stdlib.h>
#include <stdio.h>
#include "list.h"
#include <assert.h>
#include "TEST_MACRO.h"

//  리스트 초기화하기 (초기화할 리스트 받기, 동적할당 해제를 해주는 함수등록하기)
void InitList(List* list)
{
  list->Head->Next = list->Tail;
  list->Tail->Next = list->Tail;
}


//  리스트 제거하기 제거할게 없으면 -1 반환 성공시 0
int DestroyList(List* list)
{
  // list head의 next가 tail이라면 그 중간에는 노드가 없다는 뜻
  if(list->Head->Next == list->Tail){
      return -1; 
  }
  
  Node* temp = list->Head->Next;
  
  // 지워질 노드를 지정하고, 
  // 그 다음 노드를 확보해둔다.
  while(temp != list->Tail){
      Node* removed = temp;
      temp = removed->Next;
      free(removed);
  }
  
  // 비워준 다음에는 초기화를 실시한다. 
  InitList(list);

  return 0;
}

// 노드를 idx 번쨰에 리스트에 넣는다 (idx 위치에 노드가 위치하게됨) 실패시 -1, 성공시 0반환, 
int InsertNodeIntoList(Node* element, int idx, List* list)
{
    // 기준이 필요하다.
    // 일반적?으로, 적어도 내가 공부했던 방식에서는 head, tail은 dummy
    // head와 tail사이에 node가 1개 존재할 때, 그 노드의 인덱스를 0이라고 합시다. 
    // 우선 list의 사이즈를 반환하는 함수를 만들고 오도록 한다. 그것을 사용해야 하므로
     
    int sizeOfList =  GetListSize(list);

    if( idx > sizeOfList || idx < 0 ){
        return -1; 
        //ex) 현재 5개 들어있다면 0부터 5에 해당하는 자리에 삽입하라는 명령이 의미가 있다.
    }

    // head가 가리키는 노드에 대해서, head로부터 1만큼 떨어져 있다고 표현한다면
    // 추가될 노드는 head로부터 idx + 1만큼 떨어져 있다.

    // prev는 삽입될 노드의 이전 노드에 해당한다. 
    Node* prev = list->Head;
    for(int i = 0; i < idx; i++)
        prev = prev->Next;

    element->Next = prev-> Next ;
    prev->Next =element;

    return 0;
}

// 리스트의 사이즈를 반환
int GetListSize(List* list)
{
    if(list->Head->Next == list->Tail){
        return 0;
    }

    int count = 0;
    Node* temp = list->Head->Next;

    while(temp  != list->Tail){
        count++;
        temp = temp->Next;
    }
    
    return count;
}

//idx 번째의 노드의 데이터를 가져온다
int GetIdxData(List* list, int idx)
{
    int sizeOfList = GetListSize(list);
    if(idx < 0 || idx > sizeOfList){
        // 이건 이 함수를 사용하기전에 사전 점검하도록 한다. 
        // return -1을 쓸 수 없는 이유 : 노드의 데이터에 제약이 없다면 -1이라는 값을 갖고 있을 수도 있기 때문
    }
    Node* prev = list->Head;
    for(int i = 0 ; i < idx ; i++)
        prev = prev->Next;

    return prev->Next->Data;

}


void TestList()
{


}
