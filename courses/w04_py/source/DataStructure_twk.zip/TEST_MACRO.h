#define EMPTY_SPACE printf("\n\n\n\n\n");

#define TEST_START(description) printf("# %s 단계 테스트 시작 \n",#description);

#define TEST_FAIL(description) printf("# %s 단계 실패...\n",#description);

#define STAGE_CLEAR(stage) printf("=======%s 단계 통과!========\n",#stage);

#define PRINT_SCORE(score) printf("=====현재점수는 %s 입니다 =======\n",#score);

