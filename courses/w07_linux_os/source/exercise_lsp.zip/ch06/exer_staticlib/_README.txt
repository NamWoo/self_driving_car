1. compile mylib.c with -c option
2. archive it with ar
3. compile main.c
4. link main.o and library
5. run it
