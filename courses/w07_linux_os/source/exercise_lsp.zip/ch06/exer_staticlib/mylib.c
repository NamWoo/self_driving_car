#include "mylib.h"
int sum(int a , int b)
{
	return a+b;
}

int diff (int a, int b)
{
	return a-b;
}
