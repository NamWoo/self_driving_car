int sum(int a , int b);
int diff(int a, int b);
