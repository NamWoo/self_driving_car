1. build library in lib/   by make
2. build hello.c           by make
3. set LD_LIBRARY_PATH    (without it, it would complain)
4. run it

how about review the Makefile


