#include "myfunc.h"

int main(void)
{
	say_hello();
	return 0;
}
