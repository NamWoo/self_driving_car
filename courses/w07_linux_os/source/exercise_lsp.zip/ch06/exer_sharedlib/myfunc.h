#ifndef __MYFUNC__
#define __MYFUNC__

void say_hello (void);


#endif //__MYFUNC__
