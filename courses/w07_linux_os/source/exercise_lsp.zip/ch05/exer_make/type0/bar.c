#include <stdio.h>

void bar(void)
{
	printf("Good bye, my love \n");
}
