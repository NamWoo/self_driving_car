// func1.c
#include <stdio.h>

void func1()
{
	printf("this is function1 program\n");
}


