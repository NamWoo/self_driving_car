// func2.c
#include <stdio.h>

void func2()
{
	printf("this is function2 program\n");
}


