// main.c
#include <stdio.h>
#include "io.h"

int main()
{
	printf("this is main program\n");
	func1();
	func2();
	
	return 0;
}


