// io.h
void func1();
void func2();

