exercise each makefile in type0 .. type4 directories
