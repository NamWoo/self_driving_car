do ex1.c 
do ex2.c
exercise vi with vi_sample.txt
