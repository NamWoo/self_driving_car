;
; debug test with gdb using coredump file, core
;

$gdb test core-dump
