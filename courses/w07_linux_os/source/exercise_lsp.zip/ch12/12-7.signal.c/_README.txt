
;
; you can see signal list by $ kill -l 
; you can send signal to a precess by using $ kill -SIGNAL <processno>
;


sig_action:

-> send SIGINT by ^C
-> send SIGUSR2 by $kill -12

sig_change:
-> send SIGINT
-> send SIGQUIT

sig_talk:
-> just run and hold a minutes

use-alarms:
-> type as input messsage... it works fine.
-> or holding typing for 10 secs.

