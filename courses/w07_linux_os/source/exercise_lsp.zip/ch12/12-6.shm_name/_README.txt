To build:
	make
To run:
	. ./runme.sh


