./s & 
./c &
sleep 2
kill %1
kill %2
