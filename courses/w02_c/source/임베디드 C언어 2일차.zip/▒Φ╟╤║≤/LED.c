#if EXAMPLE == 310 

void Delay (int n)

{

	int i;

	int a=0;

	for(i=0; i<n;i++)

	{

		a++;

	}

}


void Main(void)

{	

	*(unsigned int *)0x56000064 =0;

	*(volatile unsigned int *)0x56000064 =0;

	volatile unsigned int *p2 = (unsigned int *)0x56000064;



	volatile unsigned int *const GPDAT = (unsigned int *) 0x56000064;

	*GPDAT &= ~(0x3 << 8);

	*GPDAT |= (0x1 << 8);

	*GPDAT &= ~(0x3 << 10);

	*GPDAT |= (0x1 << 10);





	*(unsigned int *)0x56000060 = 0;

	*(volatile unsigned int *)0x56000060 =0;

	volatile unsigned int *p = (unsigned int *)0x56000060;



	volatile unsigned int *const GPCON = (unsigned int *)0x56000060;



	while(1)

	{

		*GPCON &= ~(0x3 << 8);

		*GPCON |= (0x1 << 8);

	

		*GPDAT &= ~(0x3 << 8);

		*GPDAT |= (0x1 << 8);



		Delay(1000000);

		

		*GPCON &= ~(0x3 <<8);

		*GPDAT &= ~(0x3 <<8);



	}





}

#endif 
