void Main(void)

{	

	volatile unsigned int *const GPGCON = (unsigned int *)0x56000060;

	volatile unsigned int *const GPGDAT = (unsigned int *)0x56000064;



	*GPGCON = *GPGCON & ~(0x3<<8);

	*GPGCON = *GPGCON & ~(0x3<<10);

	*GPGCON = *GPGCON | (0x1<<8);

	*GPGCON = *GPGCON | (0x1<<10);

	while(1)

	{

		*GPGDAT = *GPGDAT & ~(0x1<<4);

		*GPGDAT = *GPGDAT & ~(0x1<<5);

	}

	

}
