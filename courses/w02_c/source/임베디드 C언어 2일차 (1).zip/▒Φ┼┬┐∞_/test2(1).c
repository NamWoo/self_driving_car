#if EXAMPLE == 310 




void test2(void){



	volatile unsigned int *const GPGCON = (unsigned int *) 0x56000060;

	volatile unsigned int *const GPGDAT = (unsigned int *) 0x56000064;

	*GPGDAT = 0x00000000; 



	register int i = 0;

	while(1){



		for(i = 0; i < 4; i++){

			*GPGCON = *GPGCON & ~(0x3<<(2*i+8)); 

			*GPGCON = *GPGCON | (0x1<<(2*i+8));

		}

		

		for(i = 0; i < 0xfffff; i++){}		

		

		for(i = 0; i < 4; i++){

			*GPGCON = *GPGCON & ~(0x3<<(2*i+8)); 

		}



		for(i = 0; i < 0xfffff; i++){}		

	}



}





void Main(void){	

	test2();

}

#endif 
