#!/bin/bash

# 도전 QUIZ Regular Expression
# 다음의 출력 결과가 나올 수 있도록 주어진 빈칸(☺︎)을 채우세요
# 정규식(Regular Expression) 비교를 이용하세요

num=$1
re='☺︎'
if ! [[ $num =~ $re ]] ; then
   echo "error: Not a number" >&2; exit 1
else
    echo "is a number"
fi


# 실행결과
# user@ubuntu:~$  ./A05.sh 12
# is a number
# user@ubuntu:~$  ./A05.sh 1A
# error: Not a number
# user@ubuntu:~$

