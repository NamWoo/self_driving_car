#!/bin/bash

count() {
local i
for ((i=1; i<=$1; i++)); do echo $i; done
echo 'Ah, ah, ah!'
}
for ((i=1; i<=3; i++)); do count $i; done

