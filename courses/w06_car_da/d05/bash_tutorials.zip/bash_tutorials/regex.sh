#!/bin/bash
# REGEX

myFiles=*
year="2015"
pat="(.*)($year)(\.png|\.jpg)"
for f in $myFiles
do
    if [[ $f =~ $pat ]]
    then
        ext="${BASH_REMATCH[3]}" # This is the extension, .png or .jpg
        # Additionally ${BASH_REMATCH[1]} is the part before $year in $f.
        echo "$f" "$ext"
    fi
done
