#!/bin/bash

for filename in *.$1
# 첫번째 인자로 끝나는 파일 목록을 전부 탐색.
do
  mv $filename ${filename%$1}$2 # <-keynote
  # 첫번째 인자와 일치하는 부분을 떼어내고,
  # 두번째 인자를 덧붙임.
done
