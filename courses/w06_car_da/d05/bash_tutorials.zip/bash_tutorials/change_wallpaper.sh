#! /bin/bash
#script to change all desktop backgrounds

IMAGE="$1"
function change_wallpaper
{
    sqlite3 ~/Library/Application\ Support/Dock/desktoppicture.db \
    "update data set value = '$IMAGE'" && killall Dock

    killall Dock
}
change_wallpaper

