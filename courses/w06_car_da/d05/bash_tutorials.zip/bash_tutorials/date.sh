#!/bin/bash

while true; do 
    TIME=$(date "+DATE: %Y-%m-%d %H:%M:%S"); 
    echo -ne "${TIME}\r";
done

