#!/bin/bash

DIRECTORY=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
echo $DIRECTORY

