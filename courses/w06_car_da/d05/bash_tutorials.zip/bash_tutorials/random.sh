#!/bin/bash

if [[ $(($RANDOM % 6)) = 0 ]]; then
    echo "BANG"
else
    echo "Try again"
fi

