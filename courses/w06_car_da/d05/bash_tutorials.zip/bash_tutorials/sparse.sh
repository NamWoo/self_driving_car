#!/bin/bash
# sparse array

arr=([3]=item2 [7]=item3 [10]=item4 [1]=item5)
value="item3"
switch="0"

# loop over array's indexes
for i in "${!arr[@]}"; do
  if [[ $switch = "1" ]]; then
    echo "found ${arr[$i]} in element $i"
    switch="0"
    break
  fi

  if [[ ${arr[$i]} = "$value" ]]; then
    echo "found ${arr[$i]} in element $i"
    switch="1"
    continue
  fi
done

