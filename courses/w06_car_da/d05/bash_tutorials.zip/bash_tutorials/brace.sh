#!/bin/bash
# brace expansion

ex=({foo,bar,baz})
echo ${ex[@]} #foo bar baz

