#!/bin/bash

echo $1 | egrep '^[0-9]+$' > /dev/null
if [ $? -eq 0 ]; then
    numvar=$1
else
    echo "Invalid input"
    exit 1
fi

