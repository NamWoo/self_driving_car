#!/bin/bash
# extend globs
shopt -s extglob

myFiles=*
year="2015"
for f in $myFiles
do
	[[ $f = *"$year".@(png|jpg) ]] && echo "$f"
done

