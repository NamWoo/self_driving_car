#!/bin/bash

while true; do
 echo -n -e "\a"; 
 sleep 1; 
done

