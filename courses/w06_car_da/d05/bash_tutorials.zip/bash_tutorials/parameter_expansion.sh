#!/bin/bash

# Many files, each with same format: "bla_{year}-{month}-{day}_{hour}-{minute}.zip"
aFile="bla_2016-11-24_17-24.zip" 
aDate=${aFile#*_} # remove "bla_"
aDate=${aDate%.*} # remove ".zip"
aDate=${aDate//_/ } # replace "_" with " "
aDate=(${aDate//-/ }) # replace "-" with " " and make array
aPath="${aDate[0]}/${aDate[1]}/${aDate[2]}/${aDate[3]}/${aDate[4]}"
mkdir -p $aPath

