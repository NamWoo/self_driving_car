#!/bin/bash

shopt -s extglob

case $1 in
    ?([[:digit:]]) ) echo "digits" ;;
    *) echo "not digits" ;;
esac

