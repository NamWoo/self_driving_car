#!/usr/bin/env bash

function addnums {
  TOTAL=0
  while read val; do
    TOTAL=$(($TOTAL+$val))
  done
  echo 
  echo 
  echo $TOTAL
}
addnums