#!/bin/bash

# 도전 QUIZ HERE DOCUMENT
# 다음의 출력 결과가 나올 수 있도록 주어진 빈칸(☺︎)을 채우세요
# admin☠  cd ~/Desktop
# admin☠  ls
# 0	1	2	3	4	5	6	7	8	9
# admin☠

ssh -T user@ubuntu <<'ENDSSH'
#commands to run on remote host
mkdir -p ~/Desktop/{0..9}
ENDSSH
