#!/bin/bash

open() {
case "$1" in
*.mp3|*.ogg|*.wav|*.flac|*.wma) xmms "$1";;
*.jpg|*.gif|*.png|*.bmp) display "$1";;
*.avi|*.mpg|*.mp4|*.wmv) mplayer "$1";;
esac
}
for file; do
open "$file"
done

