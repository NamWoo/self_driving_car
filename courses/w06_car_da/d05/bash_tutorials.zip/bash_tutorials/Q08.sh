#!/bin/bash

# 도전 QUIZ for..do..done
# 다음의 출력 결과가 나올 수 있도록 주어진 빈칸(☺︎)을 채우세요
# 파일의 확장자가 'zip' 인 파일 모두를 대상으로 for loop 적용시켜야 함
# Hint: 총 4 줄로 작성하시오

for i ☺︎
newdir="${i☺︎ }" && mkdir "$newdir"
unzip $i -d $newdir
done

# 실행결과
# user@ubuntu:~$ tree
# .
# └── US_state.txt.zip
# user@ubuntu:~$ 
# user@ubuntu:~$  ../A08.sh
# Archive:  US_state.txt.zip
#   inflating: US_state/US_state.txt
# user@ubuntu:~$ 
# user@ubuntu:~$  tree
# .
# ├── US_state
# │   └── US_state.txt
# └── US_state.txt.zip
