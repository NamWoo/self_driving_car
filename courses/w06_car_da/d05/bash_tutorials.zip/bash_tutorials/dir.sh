#!/bin/bash

DIRECTORY=`dirname $0`
echo $DIRECTORY

