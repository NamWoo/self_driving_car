#!/usr/bin/env bash
# 파일내의 라인수를 카운트 

lines=0
#for i in $(find . -type f); do 
for i in *; do 
rowline=$(wc -l "$i" | awk '{print $1}');
file="$(wc -l "$i" | awk '{print $2}')"; 
lines=$((lines + rowline)); 
echo "Lines["$lines"] " "$file" "has "$rowline" rows.";
done && unset lines
