#!/bin/bash

# declare -a # 배열
set -- "bla@some.com john@home.com"  
declare -a Array=($*) 
echo "${Array[@]}" 
echo "${Array[0]}" 
echo "${Array[1]}"

# declare -i # 정수
var1=1
var1=var1+1
echo var1=$var1 by no-declare

declare -i var2=1
var2=var2+1
echo var2=$var2 by declare

# declare -r # 읽기전용
declare -r PI=3.14
PI=314 ### bash: PI: readonly variable

