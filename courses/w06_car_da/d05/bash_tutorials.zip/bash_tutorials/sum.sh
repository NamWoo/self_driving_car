#!/bin/bash

sum() {
echo "$1 + $2 = $(($1 + $2))"
}
sum "$1" "$2"

