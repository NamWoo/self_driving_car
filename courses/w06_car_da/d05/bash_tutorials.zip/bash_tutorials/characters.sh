#!/bin/bash
# 대소문자 변환

function to-lower() { echo "$@" |tr '[:upper:]' '[:lower:]' ; }

function capitalize() {
    input="$(to-lower "$@")"
    for i in $input; do
        cap=$(echo -n "${i:0:1}" | tr "[:lower:]" "[:upper:]")
        echo -n "${cap}${i:1} "
    done
    echo
}
capitalize $@

