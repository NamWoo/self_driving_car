#!/bin/bash

# 도전 QUIZ select
# 다음의 출력 결과가 나올 수 있도록 주어진 빈칸(☺︎)을 채우세요
# 사용자에게 명령을 입력받아 'make install' 을 실행하는 스크립트를 작성하시오
# Hint: 총 6 줄로 작성하시오

echo "Do you wish to install this program?"
select answer in ☺︎
    case ☺︎ in
        Yes ) make install; break;;
        No ) exit;;
    esac
done

# 실행결과
# user@ubuntu:~$ cd linux-2.4.21
# user@ubuntu:~$ ../A10.sh
# Do you wish to install this program?
# 1) Yes
# 2) No
# ? 1
# make -C arch/x86_64/tools /..........
# .....................................
# user@ubuntu:~$
# user@ubuntu:~$ ../A10.sh
# Do you wish to install this program?
# 1) Yes
# 2) No
# ? 2
# user@ubuntu:~$