#!/bin/bash
# shift1.sh

HOST=$1
USERNAME=$2
shift 2
PASSWORD=$3

echo "HOST is ${HOST}," "USERNAME is ${USERNAME}," "PASSWORD is ${PASSWORD}"

