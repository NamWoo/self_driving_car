#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <string.h>
#define MAX_BUFFER 200
#define STRUCT 0
#define IOCTL 1


int main()
{

  int fd,i;
	char buffer[MAX_BUFFER];

  fd = open("/dev/hello",O_RDWR);
	printf("input somehting and press key 14   \n ");
	pritnf("input something :")
	gets(buffer);
	
	read(fd,buffer,MAX_BUFFER);

	gets(buffer);
	close(fd);
}
