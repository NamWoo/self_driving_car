#include <linux/module.h>	/* Needed by all modules */
#include <linux/moduleparam.h>
#include <linux/kdev_t.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/types.h>
#include <linux/kernel.h>	/* Needed for KERN_INFO	*/
#include <linux/init.h>		/* Needed for the macros */
#include <linux/errno.h>
#include <linux/slab.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/device.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <mach/gpio.h>
#include <mach/regs-gpio.h>
#include <plat/gpio-cfg.h>
#include <linux/cdev.h>
#include <asm/uaccess.h>

#define	DRIVER_AUTHOR	"DongKyu, Kim <dongkyu@mdstec.com>"
#define	DRIVER_DESC		"A sample driver"
#define     DRV_NAME                "keyint"
#define MY_MAX_DEVICES 100
#define MY_MAX_BUFFER 200
static int MajorNumber = 241;
static struct cdev MyDevs[MY_MAX_DEVICES];
module_param(MajorNumber,int,0);

static char DeviceBuffer[MY_MAX_BUFFER];
static char UserBuffer[MY_MAX_BUFFER];
static void my_setup_cdev(struct cdev* dev, int minor, struct file_operations* fops)
{
	int err, devno = MKDEV(MajorNumber,minor);
	cdev_init(dev,fops);
	dev->owner = THIS_MODULE;
	dev->ops = fops;
	err=cdev_add(dev,devno,1);
	printk("Major Number : %d, Minor Number : %d \n\n",MajorNumber, minor);
	if(err)
		printk("Error when adding MinorNubmer\n\n\n");
}


static void __exit cleanup_hello_4(void)
{
	printk(KERN_INFO "Goodbye, world 4.\n");

        free_irq(IRQ_EINT0, NULL);

    printk(KERN_INFO "%s successfully removed\n", DRV_NAME);

}

static int my_open(struct inode* inode, struct file* file)
{
	printk("opened!!!\n");
	return 0;
}
static int my_release(struct inode* inode, struct file* file)
{
	printk("released!!!\n");
	return 0;
}

static ssize_t my_read(struct file* file, char __user* buf , size_t count, loff_t* f_pos)
{
	
	copy_from_user(DeviceBuffer,buf,MY_MAX_BUFFER);
	printk("Current DeviceBuffer: %s",DeviceBuffer);
	printk("inside kernel, reading...\n");
	return 0;
}

static irqreturn_t keyinterrupt_func14(int irq, void *dev_id, struct pt_regs *resgs)
{

      printk("Key pressed....14\n");
			printk("User Buffer : %s ",DeviceBuffer);
      return IRQ_HANDLED;
}

static irqreturn_t keyinterrupt_func15(int irq, void *dev_id, struct pt_regs *resgs)
{
      printk("Key pressed....15\n");
      return IRQ_HANDLED;
}

static struct file_operations my_fops = {
	.owner = THIS_MODULE,
	.open = my_open,
	.read = my_read,
	.release = my_release
};

static int __init init_hello_4(void)
{
	int ret;

	printk(KERN_INFO "Hello, world 4.\n");
  dev_t dev = MKDEV(MajorNumber, 0);
    // set Interrupt mode
  s3c_gpio_cfgpin(S3C2410_GPF(0), S3C_GPIO_SFN(2));
  s3c_gpio_cfgpin(S3C2410_GPF(1), S3C_GPIO_SFN(2));

  if( request_irq(IRQ_EINT0, (void *)keyinterrupt_func14,
			IRQF_DISABLED|IRQF_TRIGGER_FALLING, DRV_NAME, NULL) )
        {
                printk("failed to request external interrupt14.\n");
                ret = -ENOENT;
                return ret;
        }
        if( request_irq(IRQ_EINT1, (void *)keyinterrupt_func15,
                IRQF_DISABLED|IRQF_TRIGGER_FALLING, DRV_NAME, NULL) )
        {
                printk("failed to request external interrupt15.\n");
                ret = -ENOENT;
                return ret;
        }
        printk(KERN_INFO "%s successfully loaded\n", DRV_NAME);
	my_setup_cdev(MyDevs,0,&my_fops);
	printk("Device Driver init done!!\n\n\n");

	return 0;
}

module_init(init_hello_4);
module_exit(cleanup_hello_4);
/* Get rid of taint message by declaring code as GPL. */
MODULE_LICENSE("GPL");
MODULE_AUTHOR(DRIVER_AUTHOR);		/* Who wrote this module? */
MODULE_DESCRIPTION(DRIVER_DESC);	/* What does this module do */
MODULE_SUPPORTED_DEVICE("testdevice");
