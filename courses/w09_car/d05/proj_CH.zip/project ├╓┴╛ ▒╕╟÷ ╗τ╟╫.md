## Application 실행
1. pid값 write로 커널에 전달
2. main 프로세스에서 메세지 큐를 생성하고 receive 대기 (waiting for start)

## SW14 기능 구현(프로그램 스타트 기능)
1. SW14 클릭시 SIGUSR1 발생시키기
    - pthread 생성, 메세지 큐에 trigger 신호를 넣음
2. main에서 메세지를 받으면 printf "program start"하고 이후 프로세스를 진행
3. 워크큐 사용하여 SW4~8 버튼 체크하는 loop 발생

## SW15 기능 구현
1. 인터럽트 핸들러 실행
    1. 핸들러에서 인터럽트 타이머 실행
        - 타이머 핸들러에 따라 LED 이동
        - LED 이동을 워크큐에 포함 시켜 다른 버튼 누를시 종료되고 해당 기능 수행
2. SIGUSR2 시그널 발생시킴
3. main에서 signal 핸들러 발생시켜 ioctl_read 실행
4. 커널에서 copy to user로 "Hi, this was sent from Kernel to App" 전달
 
 ## SW4~13 기능 구현
 1. 워크큐 사용
    - 워크큐가 polling 형식으로 SW4~13을 계속해서 감지
 2. SW4~13을 누름에 따라 다른 LED 출력