#include <linux/module.h>
#include <linux/init.h>
#include <linux/major.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/kernel.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include <linux/delay.h>
#include <linux/timer.h>
#include <linux/kdev_t.h>
#include <linux/device.h>
#include <linux/slab.h>   /* kmalloc() */
#include <linux/errno.h>    /* error codes */
#include <linux/types.h>    /* size_t */
#include <asm/irq.h>
#include <linux/sched.h>
#include <linux/interrupt.h>

#include <mach/gpio.h>
#include <mach/regs-gpio.h>
#include <plat/gpio-cfg.h>
#include <linux/gpio.h>
#include "project_ioctl.h"

#define DEVICE_NAME "project"
#define GPGCON *(volatile unsigned long *)(Gkva)
#define GPGDAT *(volatile unsigned long *)(Gkva + 4)
#define GPFCON *(volatile unsigned long *)(Fkva)
#define GPFDAT *(volatile unsigned long *)(Fkva + 4)

struct timer_list timer;
static int project_major = 241, project_minor = 0;
static int result;
static dev_t project_dev;
static void *Gkva;
static void *Fkva;
static pid_t userpid;
static int status;
int led = 0x1;

static struct cdev project_cdev;
static int project_register_cdev(void);

static work_func_t mywork_queue_func(void *data);
DECLARE_DELAYED_WORK(mywork,(work_func_t)mywork_queue_func);

/* TODO: Define Prototype of functions */
static int project_open(struct inode *inode, struct file *filp);
static int project_release(struct inode *inode, struct file *filp);
static int project_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos);
static int project_read(struct file *filp, char *buf, size_t count, loff_t *f_pos);

int my_kill_proc(pid_t pid, int sig) {
    int error = -ESRCH;           /* default return value */
    struct task_struct* p;
    struct task_struct* t = NULL; 
    struct pid* pspid;
    rcu_read_lock();
    p = &init_task;               /* start at init */
    do {
        if (p->pid == pid) {      /* does the pid (not tgid) match? */
            t = p;    
            break;
        }
        p = next_task(p);         /* "this isn't the task you're looking for" */
    } while (p != &init_task);    /* stop when we get back to init */
    if (t != NULL) {
        pspid = t->pids[PIDTYPE_PID].pid;
        if (pspid != NULL) error = kill_pid(pspid,sig,1);
    }
    rcu_read_unlock();
    return error;
}

static work_func_t mywork_queue_func (void *data)
{
	unsigned int key;
	int i;
    printk("Work queue func's got started!\n");

    while(1){
		//status = 0;

        GPFDAT &= ~(0x80); //GPF7 Low
        GPGDAT |= (0x01); //GPG0 High

        for(i = 0; i < 5; i++){
            key = GPFDAT;
            key &= (0x01 << (i + 2));
            key = (key >> (i + 2));
            if(key == 0){
                status = i + 1;
            } 	
        }

        GPFDAT |= 0x80; //GPF7 High
        GPGDAT &= ~(0x01); //GPG0 Low

        for(i = 0; i < 5; i++){
            key = GPFDAT;
            key &= (0x01 << (i + 2));
            key = (key >> (i + 2));
            if(key == 0) {
                status = i + 6;	
            }
        }

		switch(status){
			case 1: 
				del_timer(&timer);
				printk("\nkeypad 2 was pressed \n");
				GPGDAT |= (0x0f << 4);
				GPGDAT &= ~(0x01 << 4);
				status = 0; break;

			case 2: 
				del_timer(&timer);
				printk("\nkeypad 3 was pressed \n");
				GPGDAT |= (0x0f << 4);
				GPGDAT &= ~(0x02 << 4);
				status = 0; break;

			case 3: 
				del_timer(&timer);
				printk("\nkeypad 4 was pressed \n");
				GPGDAT |= (0x0f << 4);
				GPGDAT &= ~(0x04 << 4);
				status = 0; break;

			case 4: 
				del_timer(&timer);
				printk("\nkeypad 5 was pressed \n");
				GPGDAT |= (0x0f << 4);
				GPGDAT &= ~(0x08 << 4);
				status = 0; break;

			case 5: 
				del_timer(&timer);
				printk("\nkeypad 6 was pressed \n");
				GPGDAT |= (0x0f << 4);
				GPGDAT &= ~(0x0f << 4);
				status = 0; break;

			case 6: 
				del_timer(&timer);
				printk("\nkeypad 7 was pressed \n");
				GPGDAT |= (0x0f << 4);
				GPGDAT &= ~(0x01 << 4);
				status = 0; break;

			case 7: 
				del_timer(&timer);
				printk("\nkeypad 8 was pressed \n");
				GPGDAT |= (0x0f << 4);
				GPGDAT &= ~(0x02 << 4);
				status = 0; break;

			case 8: 
				del_timer(&timer);
				printk("\nkeypad 9 was pressed \n");
				GPGDAT |= (0x0f << 4);
				GPGDAT &= ~(0x04 << 4);
				status = 0; break;

			case 9: 
				del_timer(&timer);
				printk("\nkeypad 10 was pressed \n");
				GPGDAT |= (0x0f << 4);
				GPGDAT &= ~(0x08 << 4);
				status = 0; break;

			case 10: 
				del_timer(&timer);
				printk("\nkeypad 11 was pressed \n");
				GPGDAT |= (0x0f << 4);
				GPGDAT &= ~(0x0f << 4);
				status = 0; break;

			default : break;
		}
	}

	return 0;
}

void my_timer(unsigned long data)
{
	led = led << 1;
	if(led > 0x8) led = 0x1;

	GPGDAT |= (0xf << 4);
	GPGDAT &= ~(led << 4);

	timer.expires = jiffies + 1*HZ;
	add_timer(&timer);

	//printk("Kernel Timer Time-Out Function Done!!!\n");
}

static irqreturn_t key14int_func(int irq, void *dev_id, struct pt_regs *resgs)
{
    printk("SIGUSR1 sent....\n");
	my_kill_proc(userpid, SIGUSR1);
	schedule_delayed_work( &mywork,0);
    return IRQ_HANDLED;
}

static irqreturn_t key15int_func(int irq, void *dev_id, struct pt_regs *resgs)
{
    printk("SIGUSR2 sent....\n");
	my_kill_proc(userpid, SIGUSR2);

	// set timer
    init_timer(&timer);
	//timer.expires = get_jiffies_64() + 3*HZ;
	timer.expires = jiffies + 3*HZ;
	timer.function = my_timer;
	timer.data = 5;
	add_timer(&timer);

    return IRQ_HANDLED;
}

int project_init(void)
{
	int ret;
	printk(KERN_INFO "project Module is Loaded!! ....\n");
	// register module
	if((result = project_register_cdev()) < 0)
	{
		return result;
	}

	// set Interrupt mode
	s3c_gpio_cfgpin(S3C2410_GPF(0), S3C_GPIO_SFN(2));
	s3c_gpio_cfgpin(S3C2410_GPF(1), S3C_GPIO_SFN(2));

	if( request_irq(IRQ_EINT0, (void *)key14int_func,
			IRQF_DISABLED|IRQF_TRIGGER_FALLING, DEVICE_NAME, NULL) )
	{
		printk("failed to request external interrupt.\n");
		ret = -ENOENT;
		return ret;
	}
	if(request_irq(IRQ_EINT1, (void *)key15int_func, 
			IRQF_DISABLED|IRQF_TRIGGER_FALLING, DEVICE_NAME, NULL))
	{
		printk("failed to request external interrupt.\n");
		ret = -ENOENT;
		return ret;
	}

    /* H/W Initalization */
    Gkva = ioremap(0x56000060, 16);
    printk("Gkva = 0x%x\n", (int)Gkva);
	Fkva = ioremap(0x56000050, 16);
    printk("Gkva = 0x%x\n", (int)Fkva);
    
    GPGDAT |= 0xf << 4;

    GPGCON &= ~(0xff << 8);
    GPGCON |= 0x55 << 8;	

	// key input mode
	GPFCON &= ~(0x3 << 14);
	GPFCON |= (0x1 << 14);	// GPF7 output
	GPGCON &= ~(0x3); //GPG0 output
	GPFCON &= ~(0x3ff << 4); // GPF2, 3, 4, 5, 6 input

	printk(KERN_INFO "%s successfully loaded\n", DEVICE_NAME);

	return 0;
}

static int project_open(struct inode *inode, struct file *filp)
{
    printk("Device has been opened...\n");
    

    return 0;
}

static int project_release(struct inode *inode, struct file *filp)
{
    printk("Device has been closed...\n");
    
    return 0;
}

static int project_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos)
{
	printk("project_write is invoked\n");
	
	get_user(userpid, (int *)buf);
	printk("userpid : %d\n", userpid);
	//my_kill_proc(userpid, SIGUSR1);
    
	return count;
}

static int project_read(struct file *filp, char *buf, size_t count, loff_t *f_pos)
{
	  printk("project_read is invoked\n");
	  return 0;
}

static int project_ioctl ( struct file *filp, unsigned int cmd, unsigned long arg)  
{  
  
   ioctl_buf *k_buf;
   int   i,err, size;  
      
   if( _IOC_TYPE( cmd ) != IOCTL_MAGIC ) return -EINVAL;  
   if( _IOC_NR( cmd )   >= IOCTL_MAXNR ) return -EINVAL;  

   size = _IOC_SIZE( cmd );   
 
   if( size )  
   {  
       err = -EFAULT;  
       if( _IOC_DIR( cmd ) & _IOC_READ  ) 
		err = !access_ok( VERIFY_WRITE, (void __user *) arg, size );  
       else if( _IOC_DIR( cmd ) & _IOC_WRITE ) 
		err = !access_ok( VERIFY_READ , (void __user *) arg, size );  
       if( err ) return err;          
   }  
            
   switch( cmd )  
   {  
      
    //    case IOCTL_PROJECT_TEST :
    //         printk("IOCTL_PROJECT_TEST Processed!!\n");
	//     break;

       case IOCTL_PROJECT_READ :
            k_buf = kmalloc(size,GFP_KERNEL);
            
            //sprintf(k_buf->data, %s, "Hi, this was sent from Kernel to App");
			strcpy(k_buf->data, "Hi, this was sent from kernel to App");
			//printk("k_buf->data : %s\n", k_buf->data);
            if(copy_to_user ( (void __user *) arg, k_buf, (unsigned long ) size ))
	          return -EFAULT;   
            kfree(k_buf);
            printk("IOCTL_PROJECT_READ Processed!!\n");
	    break;
	                              
		default :
				printk("Invalid IOCTL  Processed!!\n");
				break; 
    }  
  
    return 0;  
}  
 
struct file_operations project_fops = { 
    .open       = project_open,
    .release    = project_release,
	.write		= project_write,
	.read		= project_read,
	.unlocked_ioctl   = project_ioctl,
};

void project_exit(void)
{
	del_timer(&timer);

	// gpio 해제
	gpio_free(S3C2410_GPF(0));
	gpio_free(S3C2410_GPF(1));

	// 인터럽트 해제
	free_irq(IRQ_EINT0, NULL);
	free_irq(IRQ_EINT1, NULL);

	// device 등록 해제
    cdev_del(&project_cdev);
	unregister_chrdev_region(MKDEV(project_major, 0), 1);

	printk("project Module is Unloaded ....\n");
}

static int project_register_cdev(void)
{
	int error;

	/* allocation device number */
	if(project_major) {
		project_dev = MKDEV(project_major, project_minor);
		error = register_chrdev_region(project_dev, 1, "project");
	} else {
		error = alloc_chrdev_region(&project_dev, project_minor, 1, "project");
		project_major = MAJOR(project_dev);
	}

	if(error < 0) {
		printk(KERN_WARNING "project: can't get major %d\n", project_major);
		return result;
	}
	printk("major number=%d\n", project_major);

	/* register chrdev */
	cdev_init(&project_cdev, &project_fops);
	project_cdev.owner = THIS_MODULE;
	project_cdev.ops = &project_fops;
	error = cdev_add(&project_cdev, project_dev, 1);

	if(error)
		printk(KERN_NOTICE "project Register Error %d\n", error);

	return 0;
}

module_init(project_init);
module_exit(project_exit);

MODULE_LICENSE("Dual BSD/GPL");


/*
 #tail -f /var/log/messages
*/
