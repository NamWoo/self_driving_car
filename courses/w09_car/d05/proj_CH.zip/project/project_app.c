/***************************************
 * Filename: sk_app.c
 * Title: Skeleton Device Application
 * Desc: Implementation of system call
 ***************************************/
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <mqueue.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include "project_ioctl.h"

#define MAX_BUFFER 10

int fd,size;

char buf_out[MAX_BUFFER];
ioctl_buf *buf_in;

pid_t pid;

pthread_t threads[2];
pthread_attr_t      attr0, attr1;

struct mq_attr attr;
mqd_t mq;

void recv_thread( void ) {
	char msg[20];
	int len;
	unsigned int prio=0;

    len = mq_receive(mq, msg, sizeof(msg), &prio);
    sleep(1);

    if ( len > 0 ) {
        msg[len] = '\0';
        printf( "\t\tI got [%s] message\n", msg);
    }
}

void send_thread( void ) {
	char msg[20] = "Program start!";
	unsigned int prio = 0;

   // printf( "S(%c, prio = %d)\n", c, prio );
/* TODO: send c via message-q */ 
    mq_send(mq, msg, sizeof(msg), prio);

    sleep(1);
}

void mySigHdlr1(int signo)
{
  if (signo == SIGUSR1) {
    printf("received SIGUSR1\n");
    pthread_create(&threads[1], &attr1, (void*)send_thread, NULL);
    pthread_detach(threads[1]);
  }
}

void mySigHdlr2(int signo)
{
    size = sizeof(ioctl_buf);
    buf_in = (ioctl_buf *)malloc(size);
    if (signo == SIGUSR2) {
        printf("received SIGUSR2\n");
        
        ioctl(fd, IOCTL_PROJECT_READ, buf_in);
        printf("mySigHdlr2 : %s\n",buf_in->data);
  }
  free(buf_in);
}

int main(void)
{

    // 메시지 큐 생성
	attr.mq_maxmsg  =  3;
	attr.mq_msgsize = 20;
	attr.mq_flags   =  0;

	mq = mq_open("/mqueue", O_RDWR|O_CREAT,0,&attr);
	if(mq == -1)
	{
		perror("mq_open error");
		exit(0);
	}	

   // 시그널 생성
    if (signal(SIGUSR1, mySigHdlr1) == SIG_ERR) {
        printf("\ncan't catch SIGUSR1\n");
    }
    if (signal(SIGUSR2, mySigHdlr2) == SIG_ERR) {
        printf("\ncan't catch SIGUSR2\n");
    }

	//system("insmod project_mod.ko");
	//system("mknod /dev/project c 241 0");

    // device file open
    fd = open("/dev/project",O_RDWR);
    
    // pid 전달
    pid = getpid();
    printf("app process id : %d\n", pid);
    write(fd, &pid, 4);

    pthread_attr_init(&attr0); pthread_attr_init(&attr1);
	//pthread_create(&threads[0], &attr0, (void*)recv_thread, NULL);

    // start message가 큐에 들어가면 프로그램 계속 실행
    printf("waiting for start message... press SW14 to start!\n");
    recv_thread();

	while(1){
        printf("put 'close' :" );
        gets(buf_out);
        if(strcmp(buf_out, "close") == 0){
            //system("rmmod project_mod.ko");
            //system("rm /dev/project");
            break;
        }
    }

	close(fd);
	return (0);
}
