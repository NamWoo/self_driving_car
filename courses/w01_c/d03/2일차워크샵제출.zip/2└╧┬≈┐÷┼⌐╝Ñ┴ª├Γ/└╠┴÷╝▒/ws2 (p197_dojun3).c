#include <stdio.h>

int main(void)
{
	int year, month, day;
	int i, j, d, y=0;
	int pyeong[13]={0,31,28,31,30,31,30,31,31,30,31,30,31}; //365�� 
	int yoon[13]=  {0,31,29,31,30,31,30,31,31,30,31,30,31}; //366�� 
	
	while(1){
		printf(">��, ���� �Է��ϼ���(����� 0) : ");
		scanf("%d", &year); 
		if(year==0) break;
		scanf("%d", &month); 
		d=1;
		 
		day=365*(year-1) + (year-1)/4 - (year-1)/100 + (year-1)/400 +1;	//���⵵ 12�����ϱ��� �ϼ�		
		
		for(i=1;i<month;i++){
			if(((year%4==0) && (year%100!=0)) || (year%400==0)){ //���� 
				day+=yoon[i];					
			}
			else
				day+=pyeong[i];
		}	//�������ϱ��� �ϼ� 
				
		//�޷� ��� 
		printf("\t  %d�� %d�� \n", year, month);
		printf("\t=============\n");
		printf("-----------------------------\n");
		printf(" SUN MON TUE WED THU FRI SAT\n");
		printf("-----------------------------\n");
		
		
		if(((year%4==0) && (year%100!=0)) || (year%400==0)){ //���� 
				
			
			for(i=day;i<day+yoon[month];i++){
				if(d==1){
					for(j=0;j<i%7;j++)
					printf("    ");
				}
				switch(i%7){			
					case 0 : printf("%4d",d++); break;
					case 1 : printf("%4d",d++); break;
					case 2 : printf("%4d",d++); break;
					case 3 : printf("%4d",d++); break;
					case 4 : printf("%4d",d++); break;
					case 5 : printf("%4d",d++); break;
					case 6 : printf("%4d\n",d++); break;
				}
			}
		
		}
		else{
			for(i=day;i<day+pyeong[month];i++){
				if(d==1){
					for(j=0;j<i%7;j++)
						printf("    ");
				}
				switch(i%7){
					case 0 : printf("%4d",d++); break;
					case 1 : printf("%4d",d++); break;
					case 2 : printf("%4d",d++); break;
					case 3 : printf("%4d",d++); break;
					case 4 : printf("%4d",d++); break;
					case 5 : printf("%4d",d++); break;
					case 6 : printf("%4d\n",d++); break;
				}
			}
		}
		
		
	printf("\n");	
	}
	
	return 0;
}


