#include <stdio.h>

#include <math.h>

void numberGame(int answer)
{
    int num;
    int cnt=0;
    while(1)
    {
        cnt++;
        printf("숫자를 입력하세요(1-30)");
        scanf("%d",&num);
        if(num==answer)
        {
            printf("정답입니다\n");
            break;
        }
        else if(num>answer)
        {
            printf("정답보다 큽니다");
        }
        else if(num <answer)
        {
            printf("정답보다 작습니다\n");
        }
        
    }
    printf("정답을 맞춘 시도 횟수는 %d 입니다",cnt);

}