#include <stdio.h>

int total(int kor,int eng, int mat);
double average(int tot);
void print_title(void);

int main()
{
	
	int kor,eng,mat,sum;
	double avg;
	

	printf("# �� ������ ���� �Է� : ");
	scanf("%d %d %d",&kor,&eng,&mat);
	
	sum = total(kor,eng,mat);
	avg = average(sum);
	
	print_title();
	
	printf("     %d      %d      %d      %d      %.1lf\n",kor,eng,mat,sum,avg);
	
		
	return 0;
}

int total(int kor,int eng, int mat)
{
	int sum=0;
	
	sum = kor+eng+mat;
	
	return sum;
}

double average(int tot)
{
	double avg;
	
	avg = (double)tot/3;
	
	return avg;
}

void print_title(void)
{
	printf("\n            =====< ����ǥ >=====\n\n");
	printf("-------------------------------------------\n");
	printf("   ����    ����    ����     ����     ���  \n");
	printf("-------------------------------------------\n");

}


