#include <stdio.h>


int total(int kor, int eng, int mat);
double average(int tot);
void print_title(void);





int main(){
	int korean,english,math,tot;
	double avg;
	printf("# �� ������ ���� �Է� : ");
	scanf("%d %d %d",&korean,&english,&math); 
	print_title();
	tot = total(korean,english,math);
	printf("\t %d\t %d\t %d\t %d\t %.1lf\n",korean,english,math,tot,average(tot));
	
	return 0;
} 

int total(int kor, int eng, int mat){
	return (kor+eng+mat);
}

double average(int tot){
	return (tot/3.0);
}

void print_title(void){
	printf("\t\t=====<����ǥ>=====\n\n");
	printf("\t-------------------------------------\n");
	printf("\t����\t����\t����\t����\t���\n");
	printf("\t-------------------------------------\n");
	return;
}

