#include <stdio.h>

int total(int kor, int eng, int mat);
double average(int tot);
void print_title(void);

int main(void)
{
	int kor, eng, mat, tot;
	double avg;
			
	printf("# �� ������ ���� �Է� : ");
	scanf("%d%d%d", &kor, &eng, &mat);
	
	tot = total(kor, eng, mat);
	avg = average(tot);
	
	print_title();
	
	printf("\t%d\t%d\t%d\t%d\t%.1lf\n", kor, eng, mat, tot, avg);
	
	return 0;
}
int total(int kor, int eng, int mat)
{
	int tot = kor + eng + mat;
	return tot;
}
double average(int tot)
{
	double avg = tot/3;
	return avg;
}
void print_title(void)
{
	printf("\t\t=====< �� �� ǥ >=====\n");
	printf("     ------------------------------------------\n");
	printf("\t����\t����\t����\t����\t���\n");
	printf("     ------------------------------------------\n");
}


