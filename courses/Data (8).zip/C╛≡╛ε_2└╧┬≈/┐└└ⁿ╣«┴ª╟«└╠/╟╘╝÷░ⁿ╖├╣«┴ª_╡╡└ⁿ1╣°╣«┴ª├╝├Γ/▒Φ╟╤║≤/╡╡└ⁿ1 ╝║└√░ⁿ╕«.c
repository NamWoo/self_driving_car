#include<stdio.h>

int total(int kor, int eng, int mat);
double average(int tot);
void print_title(void);
void printf_line(int n);

int main(void)
{
	int korean, english, math;
	printf("# �� ������ ���� �Է�(��, ��, ��) : ");
	scanf("%d %d %d", &korean, &english, &math);
	print_title();
	int sumScore = total(korean, english, math);
	double avgScore = average(sumScore);
	
	printf("%8d%8d%8d%8d%8.1lf", korean, english, math, sumScore, avgScore);
}


int total(int kor, int eng, int mat)
{
	int sum = kor+eng+mat;
	return sum;
}

double average(int tot)
{
	return tot/3;
}

void print_line(int n)
{
	int i=0; 
	for(i=0; i<n; i++) printf("-");	
}

void print_title(void)
{
	printf("\n====< ����ǥ >====\n\n");
	print_line(60);
	printf("\n");
	printf("\t����\t����\t����\t����\t���\n");
	print_line(60);
	printf("\n");
}
