#include <stdio.h>

int total(int kor, int eng, int mat);
double average(int tot);
void print_title(void);

int main(void)
{	
	int a,b,c,d;
	double e;
	printf("#�� ������ ���� �Է� :");
	scanf("%d%d%d",&a,&b,&c);
	d=total(a, b, c);
	e=average(d);
	print_title();
	printf(" %d\t%d\t%d\t%d\t%.1lf\n",a,b,c,d,e);
	
	return 0;
	
}

int total(int kor, int eng, int mat)
{
	int output=0;
	output = kor + eng + mat;
	return output;
}

double average(int tot)
{
	double output=0;
	output = tot/3.0;
	return output;
}

void print_title(void)
{
	printf("\n");
	printf("		=====< ����ǥ >=====\n");
	printf("\n");
	printf("---------------------------------------\n");
	printf("����\t����\t����\t����\t���\n");
	printf("---------------------------------------\n");
}
