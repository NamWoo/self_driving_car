/*#include<stdio.h>

int main(){
	
	int year, month;
	int day;
	int i;
	
	while(1){
	
	printf("��, ���� �Է��ϼ���(����� 0) : ");
	scanf(" %d",&year);
	if(!year)
		break;
	scanf(" %d",&month);
	
	day=365*year;
	day+=year/4;
	day-=year/100;
	day+=year/400;
	
	if(month>=3&&(!year%400||(!year%100&&year%4==0))){
 		
 		
 


	
	}
	
	
	
	printf("\t    %d�� %d�� \n",year,month);
	printf("\t   =========== \n");
	printf("--------------------------------- \n");
	printf(" SUN MON TUE WED THU FRI SAT \n");
	printf("--------------------------------- \n");
	
	
	
	
	
	
		
}
	return 0;
}*/



#include<stdio.h>


void print_title(void){
	
	printf("\t=====<����ǥ>=====\n");
	printf("-----------------------------\n");
	printf(" ���� ���� ���� ���� ���\n");
	printf("-----------------------------\n");
}

double average(int tot){
	return (double)tot/3;
}


int total(int kor,int eng,int mat){
	return kor+eng+mat;
}



int main(){
	
	int ko,eg,ma; 
	int sum;
	double aver;
	printf("# �� ������ ���� �Է� : ");
	scanf(" %d %d %d",&ko,&eg,&ma);
	
	sum=total(ko,eg,ma);
	aver=average(sum);
	
	print_title();

	printf("  %d   %d   %d   %d   %.1lf",ko,eg,ma,sum,aver);
	return 0;
}
