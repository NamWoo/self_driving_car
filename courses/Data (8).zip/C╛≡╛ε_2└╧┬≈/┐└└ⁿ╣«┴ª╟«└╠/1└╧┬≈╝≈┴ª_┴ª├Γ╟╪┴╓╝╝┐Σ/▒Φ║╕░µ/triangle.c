#include<stdio.h>

int main(void){
	int a;
	int i,j;
	while(1){
		printf("input number : ");
		scanf("%d",&a);
		if(a%2==0) break;
		for(i=0;i<a;i++){
		    for(j=0;j<a;j++){
		 	   if((a-i)<=j+1){
				printf("*");
		  	}
			   else{
				printf(" ");
		    	}
	    	}
		    printf("\n");
    	}
	    printf("\n");
	    for(i=0;i<a;i++){
		    for(j=0;j<a;j++){
		     	if(i<=j){
				    printf("*");
		     	}
			    else{
				    printf(" ");
		  	    }
	    	}
		    printf("\n");
        }
        for(i=0;i<a;i++){
        	for(j=0;j<a;j++){
        		int tmp=i;
        		if(tmp>a/2){
        			tmp=a-i-1;
				}
        		if(j>=a/2-tmp && j<=a/2+tmp){
        			printf("*");
				}
				else{
					printf(" ");
				}
			}
			printf("\n");
		}
	}
	printf("# ¦���� �ԷµǾ����ϴ�!\n");
}
