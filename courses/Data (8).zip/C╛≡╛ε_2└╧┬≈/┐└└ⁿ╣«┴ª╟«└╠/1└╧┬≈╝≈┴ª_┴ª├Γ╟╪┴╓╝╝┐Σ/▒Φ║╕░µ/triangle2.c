#include<stdio.h>

void triangle1(int num){
	int i,j;
	for(i=0;i<num;i++){
		for(j=0;j<num;j++){
			if(i>=j){
				printf("*");
			}
			else{
				printf(" ");
			}
		}
		printf("\n");
	}
}
void triangle2(int num){
	int i,j;
	for(i=0;i<num;i++){
		for(j=0;j<num;j++){
			if((num-i)<=j){
				printf(" ");
			}
			else{
				printf("*");
			}
		}
		printf("\n");
	}
}
void triangle3(int num){
	int i,j;
	for(i=0;i<num;i++){
		for(j=0;j<num;j++){
			if((num-i)<=j+1){
				printf("*");
			}
			else{
				printf(" ");
			}
		}
		printf("\n");
	}
}
void triangle4(int num){
	int i,j;
	for(i=0;i<num;i++){
		for(j=0;j<num;j++){
			if(i<=j){
				printf("*");
			}
			else{
				printf(" ");
			}
		}
		printf("\n");
	}
}
void diamond(int num){
	int i,j;
	for(i=0;i<num;i++){
        	for(j=0;j<num;j++){
        		int tmp=i;
        		if(tmp>num/2){
        			tmp=num-i-1;
				}
        		if(j>=num/2-tmp && j<=num/2+tmp){
        			printf("*");
				}
				else{
					printf(" ");
				}
			}
			printf("\n");
		}
}
void sandglass(int num){
	int i,j;
	int half=num/2;
	for(i=0;i<=num;i++){
		int tmp=i;
		if(tmp>half){
			tmp=num-i;
		}
		for(j=0;j<num;j++){
			if(j<tmp || j>num-tmp-1){
				printf(" ");
			}
			else{
				printf("*");
			}
		}
		printf("\n");
	}
}
void rectangleEmpty(int num){
	int i,j;
	for(i=0;i<num;i++){
		for(j=0;j<num;j++){
			if(i==0 || i==num-1 || j==0 || j==num-1){
				printf("*");
			}
			else {
				printf(" ");
			}
		}
		printf("\n");
	}
}
int main(void){
	int a;
	scanf("%d",&a);
	if(a%2==0){
		a++;
	}
	triangle1(a);
	printf("\n");
	triangle2(a);
	printf("\n");
	triangle3(a);
	printf("\n");
	triangle4(a);
	printf("\n");
	diamond(a);
	printf("\n");
	sandglass(a);
	printf("\n");
	rectangleEmpty(a);

}
