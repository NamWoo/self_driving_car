#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "fibo.h"

// repeative fibo
int fibo_repeative(int num) {
	int result = 1;
	int an_2 = 1; 
	int an_1 = 1; 

	printf("Input number : %d\n", num);

	for (int i = 0; i <= 1; i++) {
		printf("1 ");
		if (num == i)
			return 1;
	}

	for (int i = 0; i <= num-2; i++) { 
		result = an_1 + an_2;
		int temp = an_1;
		an_1 = result;
		an_2 = temp;
		printf("%d ", result);
	}

	return result;
}

// recursive fibo
int fibo_recursive(int num) {

	int result = 0;
	if (num == 0 || num == 1) {
		result = 1;
	}
	else {
		result = fibo_recursive(num - 2) + fibo_recursive(num - 1);
	}
	
	return result;
}

int main() {
	printf("%d\n", fibo_recursive(15));
	return 0;
}