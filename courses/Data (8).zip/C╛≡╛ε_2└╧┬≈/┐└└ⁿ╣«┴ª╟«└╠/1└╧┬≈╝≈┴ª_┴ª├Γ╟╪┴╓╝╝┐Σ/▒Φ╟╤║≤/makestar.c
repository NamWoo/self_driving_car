#include<stdio.h>

int main(void)
{
	int num;
	printf("Input number : ");
	scanf("%d", &num);
	if((num%2)==0) printf("¦���� �ԷµǾ����ϴ�!\n");
	else
	{
		char star[num];
		int i, j, k;
		for(i=0;i<num;i++)
		{
			star[i]=' ';
		}
		for(i=0;i<num;i++)
		{
			for(j=0;j<=i;j++)
			{
				star[num-(j+1)] = '*';
			}
			printf("%s\n", star);
		}
		printf("\n");
		
		for(i=0;i<num;i++)
		{
			star[i]='*';
		}
		for(i=0;i<num;i++)
		{
			for(j=0;j<i;j++)
			{
				star[j] = ' ';
			}
			printf("%s\n", star);
		}
		printf("\n");
		
		for(i=0;i<num;i++)
		{
			star[i]=' ';
		}
		int mid = num/2;
		for(i=0;i<mid;i++)
		{
			star[mid] ='*';
			for(j=0;j<=i;j++) star[mid+j] = '*';
			for(j=0;j<=i;j++) star[mid-j] = '*';
			printf("%s\n", star);
		}
				
		for(i=0;i<num;i++)
		{
			star[i]=' ';
		}
		for(i=mid;i<num;i++)
		{
			star[mid] ='*';
			for(j=0;j<=i;j++) star[mid+j] = '*';
			for(j=0;j<=i;j++) star[mid-j] = '*';
			printf("%s\n", star);
		}		
	}
}
