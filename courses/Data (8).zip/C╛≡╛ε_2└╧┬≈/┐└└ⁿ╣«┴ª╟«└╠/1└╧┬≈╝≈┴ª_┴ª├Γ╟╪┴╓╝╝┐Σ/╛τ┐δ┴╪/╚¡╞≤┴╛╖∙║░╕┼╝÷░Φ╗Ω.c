#include <stdio.h>

int input(void);
void devide(int money);
int isY(void);

int main(void)
{
	int a;
	
	a = input();
	devide(a);
	 
 } 
 
 int input(void)
 {
 	int money;
	
	printf("���� : ");
	scanf("%d",&money);
	
	return money;
 }
 
 void devide(int money)
 {
 	int remain, remain_10000;
	int remain_5000, remain_1000, remain_500;
	int remain_100, remain_50, remain_10;
	
	remain = money;
	remain_10000 =  remain / 10000;
	remain = remain - remain_10000*10000;
	printf("10000d���� %d��\n",remain_10000);
	remain_5000 =  remain / 5000;
	remain = remain - remain_5000*5000;
	printf("��õ���� : %d��\n",remain_5000);
	remain_1000 =  remain / 1000;
	remain = remain - remain_1000*1000;
	printf("õ���� : %d��\n",remain_1000);
	remain_500 =  remain / 500;
	remain = remain - remain_500*500;
	printf("�����¥�� : %d��\n",remain_500);
	remain_100 =  remain / 100;
	remain = remain - remain_100*100;
	printf("���¥�� : %d��\n",remain_100);
	remain_50 =  remain / 50;
	remain = remain - remain_50*50;
	printf("���ʿ�¥�� : %d��\n",remain_50);
	remain_10 =  remain / 10;
	remain = remain - remain_10*10;
	printf("�ʿ�¥�� : %d��\n",remain_10);
	printf("�ʿ�¥�� : %d��\n",remain);
	
 }
