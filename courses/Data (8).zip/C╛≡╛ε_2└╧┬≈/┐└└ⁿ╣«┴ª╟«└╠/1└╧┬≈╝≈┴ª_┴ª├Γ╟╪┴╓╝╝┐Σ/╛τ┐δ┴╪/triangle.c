
#include <stdio.h>

int main(void)
{
	int input, a, i, j, k, l;
	
	printf("Input number :");
	scanf("%d",&input);
	
	a = input%2;
	if (a==0)
	{
		printf("# ¦���� �ԷµǾ����ϴ�.\n");
	}
	else
	{
		for (i=1; i<=input; i++)
		{
			for (j=1; j<=input; j++)
			{
				if ((input-i)>=(j))
				{
					printf(" ");
				}
				else
				{
					printf("*");
				}
					
			}
				
			printf("\n");
		}
		printf("\n");
		
		for (i=1; i<=input; i++)
		{
			for (j=1; j<=input; j++)
			{
				if ((i)>(j))
				{
					printf(" ");
				}
				else
				{
					printf("*");
				}
					
			}
				
			printf("\n");
		}
		
		printf("\n");
		k=(input+1)/2;
		l=0;
		for (i=1; i<=input; i++)
		{
			
			for (j=1; j<=input; j++)
			{
				
				if ((j<=k+(l))&&(j>=k-(l)))
				{
					printf("*");
				}
				else
				{
					printf(" ");
				}
				
			}
			if (i<(k))
			{
				l=l+1;
			}	
			else
			{
				l=l-1;
			}
				
			printf("\n");
		}
	}
	
	
}
