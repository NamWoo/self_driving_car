#include <stdio.h>

void triangle1(int num);
void triangle2(int num);
void triangle3(int num);
void triangle4(int num);
void diamond(int num);
void sandglass(int num);
void rectangleEnpty(int num);

int main(void)
{
	int input, output;
	printf("���ڸ� �Է����ּ���:");
	scanf("%d",&input);
	
	if (input%2 == 0)
	{
		printf("¦���� �Է��Ͽ����ϴ�.\n");
		output = input+1;
		triangle1(output);
		triangle2(output);
		triangle3(output);
		triangle4(output);
		diamond(output);
		sandglass(output);
		rectangleEnpty(output);
	}
	else
	{
		printf("Ȧ���� �Է��Ͽ����ϴ�.\n");
	}
	
	
	return 0; 
}

void triangle1(int num)
{
	int i,input,j;
	input = num;
	for (i=1; i<=input; i++)
	{
		for (j=1; j<=input; j++)
		{
			if ((i)>=(j))
			{
				printf("*");
			}
			else
			{
				printf(" ");
			}
				
		}
			
		printf("\n");
	}
	printf("\n");
}

void triangle2(int num)
{
	int i,input,j;
	input = num;
	for (i=1; i<=input; i++)
	{
		for (j=0; j<=input; j++)
		{
			if ((input-i)>=(j))
			{
				printf("*");
			}
			else
			{
				printf(" ");
			}
				
		}
			
		printf("\n");
	}
	printf("\n");
}


void triangle3(int num)
{
	int i,input,j;
	input = num;
	for (i=1; i<=input; i++)
	{
		for (j=1; j<=input; j++)
		{
			if ((input-i)>=(j))
			{
				printf(" ");
			}
			else
			{
				printf("*");
			}
				
		}
			
		printf("\n");
	}
	printf("\n");
}

void triangle4(int num)
{
	int i,input,j;
	input = num;
	for (i=1; i<=input; i++)
	{
		for (j=1; j<=input; j++)
		{
			if ((i)>(j))
			{
				printf(" ");
			}
			else
			{
				printf("*");
			}
				
		}
			
		printf("\n");
	}
	
	printf("\n");
}

void diamond(int num)
{	
	int i,j,input,k,l;
	input = num;
	k=(input+1)/2;
	l=0;
	for (i=1; i<=input; i++)
	{
		
		for (j=1; j<=input; j++)
		{
			
			if ((j<=k+(l))&&(j>=k-(l)))
			{
				printf("*");
			}
			else
			{
				printf(" ");
			}
			
		}
		if (i<(k))
		{
			l=l+1;
		}	
		else
		{
			l=l-1;
		}
			
		printf("\n");
	}
	printf("\n");
}

void sandglass(int num)
{	
	int i,j,input,k,l;
	input = num;
	k=(input+1)/2;
	l=k-1;
	for (i=1; i<=input; i++)
	{
		
		for (j=1; j<=input; j++)
		{
			
			if ((j<=k+(l))&&(j>=k-(l)))
			{
				printf("*");
			}
			else
			{
				printf(" ");
			}
			
		}
		if (i<(k))
		{
			l=l-1;
		}	
		else
		{
			l=l+1;
		}
			
		printf("\n");
	}
	printf("\n");
}

void rectangleEnpty(int num)
{	
	int i,j,input;
	input = num;

	for (i=1; i<=input; i++)
	{
		
		for (j=1; j<=input; j++)
		{
			
			if ((i==1)||(i==input))
			{
				printf("*");
			}
			else
			{	
				if ((j==1)||(j==input))
				{
					printf("*");
				}
				else
				{
					printf(" ");
				}
				
			}
			
			
		}
	
		printf("\n");
	}
	printf("\n");
}

