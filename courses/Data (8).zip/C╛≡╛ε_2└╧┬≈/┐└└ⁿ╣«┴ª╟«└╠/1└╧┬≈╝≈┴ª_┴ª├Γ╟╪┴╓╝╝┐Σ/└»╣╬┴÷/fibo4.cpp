#include <stdio.h>

int fibo(int n) {				//recursion
	if (n <= 1) {
		return 1;
	}
	return fibo(n-1)+fibo(n-2);
}

void fibo_iter(int *arr,int n) {		//iteration
	int i;
	for (i = 2; i < n; i++) {
		*(arr+i) = *(arr+(i - 1)) + (*(arr+(i - 2)));
	}
}


int main() {
	int input,i;
	scanf("%d", &input);
	
	int arr[20] = { 1,1,0, };

//	fibo_iter(arr, input);
	for (i = 0; i < input; i++) {
		printf("%d ", fibo(i));
	}
	
//	for (i = 0; i < input; i++) {
//		printf("%d ",arr[i]);
//	}

	return 0;
}
