#include <stdio.h>

int main(void) {

	int input = 1;
	int flag = 0;
	int i = 0, j = 0;
	int a = 0;
	while (input) {

		printf("���ڸ� �Է��ϼ��� (����:0):");
		scanf_s("%d", &input);
		if (input == 0) {
			printf("Bye~~\n");
			break;
		}

		for (i = 2; i <= 100; i++) {
			for (j = i + i; j <= 100; j += i) {
				if (j == input) {
					flag = 1;
					break;
				}
			}
		}

		if (flag == 1) {
			printf("�Ҽ��� �ƴմϴ�.\n");
		}
		else if (flag == 0) {
			printf("�Ҽ��Դϴ�.\n");
		}
		flag = 0;
	}

	return 0;
}
