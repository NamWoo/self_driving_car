#include <stdio.h>

int main(void)
{
	int num;
	int a,b;
	int i;
	int j;
	
	
	while (1)
	{
		printf("Input number : ");
		scanf("%d", &num);
	
		a = num % 2;
	
		if (a==0)
		{
			printf("¦�� �Է�������\n");
		}
		else
		{
			break;
		}
	}

	
	a=1;

	for ( i=1; i<=num; i++)
	{
		while(a <= num-i)
		{
			printf(" ");
			a++;
		}
			
		while(a <= num)
		{
			printf("*");
			a++;
		}	
			
		printf("\n");
		a=1;
	}
	
	printf("\n");
	
	a=1;
	
	for ( i=1; i<=num; i++)
	{
		while(a < i)
		{
			printf(" ");
			a++;
		}
			
		while(a >= i)
		{
			
			if(a > num)
			{
				printf("\n");
				break;
			}
			printf("*");
			a++;
		}	
		a=1;
}
}
