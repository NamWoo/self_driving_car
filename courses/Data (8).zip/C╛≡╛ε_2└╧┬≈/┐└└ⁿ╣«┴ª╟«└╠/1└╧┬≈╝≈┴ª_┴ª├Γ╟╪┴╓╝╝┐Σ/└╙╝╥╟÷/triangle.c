#include <stdio.h> 

int main()
{
	int num;
	int i,j;
	

	printf("input number : ");
	scanf(" %d",&num);
		
	if(num%2==0){
		printf("Input number : %d \n",num);
		printf("#¦���� �Է� �Ǿ����ϴ�!");
		 
	}
		
	else{
		for(i=1;i<=num;i++){
			for(j=1;j+i<=num;j++)
			printf(" ");
				
			for(j=0;j<i;j++)
			printf("*");
				
			printf("\n");
		}
			
		printf("\n");

			
			
		for(i=num;i>=1;i--){
			for(j=1;j+i<=num;j++)
				printf(" ");
				
			for(j=0;j<i;j++)
				printf("*");
				
			printf("\n");
			}
			
			printf("\n");

		for(i=1;i<=num;i+=2){
			for(j=1;j<=(num-i)/2;j++)
				printf(" ");
			
			for(j=1;j<=i;j++)
				printf("*");
						
			printf("\n");
		}
		
		for(i=num-2;i>0;i-=2){
			for(j=1;j<=(num-i)/2;j++)
				printf(" ");
			
			for(j=1;j<=i;j++)
				printf("*");
						
			printf("\n");
		}
		
	}

	
	
	
	return 0;
}
