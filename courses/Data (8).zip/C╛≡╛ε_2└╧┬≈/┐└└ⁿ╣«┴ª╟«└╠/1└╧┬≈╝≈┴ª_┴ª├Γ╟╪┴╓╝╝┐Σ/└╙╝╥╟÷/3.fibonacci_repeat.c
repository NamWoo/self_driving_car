#include <stdio.h>

void fibo(int n){
	
	int bf=1,bbf=1;
	int save;
	int i,j;
	
	if(n>=2)
		j=1;
	
	else
		j=n;


	for(i=0;i<=j;i++)
		printf("1 ");
	
	if(n>=2){
		
		for(i=2;i<=n;i++){
			save=bf;
			bf=bf+bbf;
			bbf=save;
			printf("%d ",bf);	
		}
		
	
	}
	printf("\n");
}
	
	
int main()
{
	int n;
	printf("Input number : ");
	scanf("%d",&n);
		
	fibo(n);
		
	return 0;
}

