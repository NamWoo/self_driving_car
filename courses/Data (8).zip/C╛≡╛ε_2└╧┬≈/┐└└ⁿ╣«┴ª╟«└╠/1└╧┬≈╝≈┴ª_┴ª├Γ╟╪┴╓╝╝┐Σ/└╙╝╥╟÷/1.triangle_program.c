#include <stdio.h>

void triangle1 (int num){
	int i,j;
	for(i=1;i<=num;i++){
		for(j=1;j<=i;j++)
			printf("*");
		
		printf("\n");
	}
}

void triangle2 (int num){
	int i,j;
	for(i=num;i>0;i--){
		for(j=1;j<=i;j++)
			printf("*");
		
		printf("\n");
	}
}

void triangle3 (int num){
	int i,j;
	for(i=1;i<=num;i++){
		for(j=1;j<=num-i;j++)
			printf(" ");
			
		for(j=1;j<=i;j++)
			printf("*");
			
		printf("\n");
	}
}

void triangle4 (int num){
	int i,j;
	for(i=num;i>0;i--){
		for(j=1;j<=num-i;j++)
			printf(" ");
			
		for(j=1;j<=i;j++)
			printf("*");
			
		printf("\n");
	}
}

void diamond(int num){
	int i,j;
	
	for(i=1;i<= num;i+=2){
		for(j=1;j<=(num-i)/2;j++)
			printf(" ");
		
		for(j=1;j<=i;j++)
			printf("*");
		
		printf("\n");
	}
	
	for(i=num-2;i>0;i-=2){
			for(j=1;j<=(num-i)/2;j++)
			printf(" ");
		
		for(j=1;j<=i;j++)
			printf("*");
		
		printf("\n");
	}
}

void sandglass(int num){
	int i,j;
		for(i=num;i>0;i-=2)
		{
			for(j=1;j<=(num-i)/2;j++)
				printf(" ");
		
			for(j=1;j<=i;j++)
				printf("*");
		
			printf("\n");
		}
	
		for(i=1;i<= num;i+=2)
		{
			for(j=1;j<=(num-i)/2;j++)
				printf(" ");
		
			for(j=1;j<=i;j++)
				printf("*");
		
			printf("\n");
		}
}

void rectangleEmpty(int num){
	int i,j;
	
	for(i=1;i<=num;i++){
		if(i==1||i==num){
			for(j=1;j<=num;j++)
				printf("*");
			
			printf("\n");
		}
		
		else{
			for(j=1;j<=num;j++){
				if(j==1||j==num) printf("*");
				else printf(" ");
			}
			
			printf("\n");
			
		}
	}
}

int main(){
	
	int num;
	printf(" ���ڸ� ������ (¦�� �Է½� +1�� Ȧ���� �����˴ϴ�.) : ");
	scanf(" %d",&num);
	
	if(num%2==0)
		num++;
	
	printf("void triangle1(int num)\n");
	triangle1(num);
	printf("void triangle2(int num)\n");
	triangle2(num);
	printf("void triangle3(int num)\n");
	triangle3(num);
	printf("void triangle4(int num)\n");
	triangle4(num);
	printf("void diamond(int num)\n");
	diamond(num);
	printf("void sandglass(int num)\n");
	sandglass(num);
	printf("void rectangleEmpty(int num)\n");
	rectangleEmpty(num);
	return 0;
}
