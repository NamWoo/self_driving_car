#include <stdio.h> 

int fi[100000]={0,};


int fibo(int n){
		
	if(fi[n]!=0)
		return fi[n];
	
	else{
		fi[n]=fibo(n-2)+fibo(n-1);
		printf("%d ",fi[n]);
		return fi[n];
	}
	
} 


int main()
{
	int num;
	int i;
	
	printf("���� �Է��ϼ��� : ");
	
	scanf(" %d",&num);
	
	
	
	fi[1]=1;
	fi[0]=1;
	
	if(num >=2)
		i=1;
		
	else
		i=num;
	
	
	for(;i>=0;i--)
			printf("%d ",fi[i]);
	
	if(num>=2)
		fibo(num); 
	
	
	
	
	return 0;
}




