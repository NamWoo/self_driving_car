#include <stdio.h>

int main(){
	
	int i,j,n;
	
	printf("input number : ");
	scanf("%d",&n);
	
	if( n % 2 == 0)
	{
		printf("¦���� �ԷµǾ����ϴ�!!\n");
		exit(1);
	}
	
	for(i=0;i<n;i++)
	{
		for(j=i;j<n;j++)
			printf(" ");
		
		for(j=i;j>=0;j--)
			printf("*");
			
		printf("\n");
	}
	
	printf("\n\n\n");
	
	for(i=0;i<n;i++)
	{
		for(j=i;j>=0;j--)
			printf(" ");
			
		for(j=i;j<n;j++)
			printf("*");
		

		printf("\n");
	}
	
	
	printf("\n\n\n");
	
	for(i=0;i<=n;i++)
	{
		if( i % 2 == 1)
		{
			for(j=i;j<n-1;j+=2)
				printf(" ");
			
			for(j=i;j>0;j--)
				printf("*");
				
		printf("\n");		
		}
		
	}
	
	
	for(i=n-1;i>0;i--)
	{
		if( i % 2 == 1)
		{
			for(j=i;j<n-1;j+=2)
				printf(" ");
			
			for(j=i;j>0;j--)
				printf("*");
				
		printf("\n");		
		}
		
	}
	
	return 0;
}
