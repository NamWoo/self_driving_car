#include <stdio.h>

void sh1(input)
{
	int i, j, k;
	
	for(i = 1 ; i <= input ; i++){
		for(j = i ; j < input ; j++){
			printf(" ");
		}
		for(k = 1 ; k <= i ; k++){
			printf("*");
		}
		printf("\n");
	}
}

void sh2(input)
{
	int i, j, k;
	
	for(i = 1 ; i <= input ; i++){
		for(k = 1; k < i ; k++){
			printf(" ");
		}	
		for(j = i ; j <= input ; j++){
			printf("*");
		}
		printf("\n");
	}
}

void sh3(input)
{
	int i, j, k;
	int half = (input/2)+1;
	
	for(i = 1 ; i <= input ; i++){
		for(j = 1; j <= input ; j++){
			if(i<=half){
				if((j > half-i) && (j < half+i)) printf("*");
				else printf(" ");
			}
			else{
				if((j > i-half) && (j <= input-(i-half))) printf("*");
				else printf(" ");
			}
		}
		printf("\n");
	}
}


int main(void)
{
	int input;
	
	printf("Input number : ");
	scanf("%d", &input);

	if((input%2) == 0){
		printf("# ¦���� �Է� �Ǿ����ϴ�!\n");
		return 0; 
	}
	else{
		sh1(input);
		printf("\n");
		sh2(input);
		printf("\n");
		sh3(input);
		printf("\n");
	}
}
