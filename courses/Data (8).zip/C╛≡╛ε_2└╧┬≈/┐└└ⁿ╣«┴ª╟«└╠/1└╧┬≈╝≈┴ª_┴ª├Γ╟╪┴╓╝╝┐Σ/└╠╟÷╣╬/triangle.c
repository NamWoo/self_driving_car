#include<stdio.h>

int main(void)
{
	int num;
 	int a,b;
	printf("Input Number : ");	
	scanf("%d" , &num);
	if(num%2 == 0){
		printf("# ¦���� �ԷµǾ����ϴ�!");
	}else{
		for(a = 1; a <= num; a++){
			for(b = 0; b < num - a; b++){
				printf(" ");	
			}
			for(b = 0; b < a; b++){
				printf("*");	
			}
			printf("\n");
		}
		printf("\n");
		for(a = num; a > 0; a--){
			for(b = 0; b < num - a; b++){
				printf(" ");	
			}
			for(b = 0; b < a; b++){
				printf("*");	
			}
			printf("\n");
		} 
		
		printf("\n");
		int space = 0;
		int mid = num / 2;
		for(a = 0; a < num; a++){
			if(mid >= a){
				space = mid - a;
			}else{
				space = a - mid;
			}
			
			for(b = 0; b < space; b++){
				printf(" ");
			}
			for(b = 0; b < num - space*2; b++){
				printf("*");
			}
			for(b = 0; b < space; b++){
				printf(" ");
			}
			printf("\n");
		} 
		
	} 
	
}
