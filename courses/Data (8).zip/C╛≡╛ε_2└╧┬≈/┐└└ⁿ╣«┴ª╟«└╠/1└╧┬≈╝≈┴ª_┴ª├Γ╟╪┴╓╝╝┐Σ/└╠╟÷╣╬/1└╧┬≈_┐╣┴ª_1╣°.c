#include<stdio.h>

int main(void)
{
	int a;
	float b; 
	int result;
	scanf("%d", &a);
	scanf("%f", &b);	
	
	b = b * b / 10000; 
	result = a / b;
	
	if(result >= 20 && result < 25){
		printf("ǥ�� �Դϴ�.");		
	}else{
		printf("ü�߰����� �ʿ��մϴ�.");	
	} 
	
	return 0;
}
