#include<stdio.h>

//int min(int a[]);
//int max(int a[]);
double average(int a[], int maxi, int mini);

int main(){
	int score[5];
	printf("5�� �ɻ������� ���� �Է� : ");
	
	int i;
	for(i = 0; i < 5; i++){
		scanf("%d", &score[i]);
	}
	
	int maxi, mini;
	int max, min;
	max = min = score[0];
	maxi = mini = 0;
	//maxi = max(score);
	//mini = min(score);
	for(i = 0; i < 5; i++){
		if(score[i] > max){
			max = score[i];
			maxi = i;
		}
		if(score[i] < min){
			min = score[i];
			mini = i;
		}
	}
	
	printf("��ȿ���� : ");
	for(i = 0; i < 5; i++){
		if(i == maxi || i == mini) continue;
		printf("%3d", score[i]);
	}
	printf("\n");
	
	printf("��� : %.1lf", average(score, maxi, mini));
	
	return 0;
}

double average(int a[], int maxi, int mini) {
	int i;
	int sum = 0;
	for(i = 0; i < sizeof(a)/sizeof(int); i++){
		if(i == maxi || i == mini) continue;
		sum += a[i];
	}
	
	return ((double)sum)/3.0;
}
