#include <stdio.h>

int Maxi(int ary1[], int size);
int Mini(int ary1[], int size);

int Maxi(int ary1[], int size)
{
	int max = ary1[0];
	int i;
	
	for(i=0;i<size;i++)
		if(max<ary1[i])
			max=ary1[i];	
	
	return max;
}

int Mini(int ary1[], int size)
{
	int min = ary1[0];
	int i;
	
	for(i=0;i<size;i++)
		if(min>ary1[i])
			min=ary1[i];
	
	return min;
} 

int main(void)
{
	int ary[5];
	int i, size, tot=0;
	double avg;
	
	size = sizeof(ary) / sizeof(ary[0]);
	printf("5�� �ɻ������� ���� �Է� : ");
	
	for(i=0;i<size;i++)
	{
		scanf("%d", &ary[i]);
	}
	int Max = Maxi(ary, size);
	int Min = Mini(ary, size);	
	
	printf("��ȿ���� : ");	
	
	for(i=0;i<size;i++)
	{
		if((ary[i]==Max)||(ary[i]==Min))
			continue;
		printf("%d ", ary[i]);
		tot += ary[i];
	}
	avg = tot/3.0;
	
	printf("\n��� : %.1lf", avg);
	
	return 0;
}
