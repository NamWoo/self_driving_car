#include <stdio.h>

int main(void)
{
	int ary[6];
	int i, j, cnt;
	
	cnt=sizeof(ary)/sizeof(ary[0]);
	
	for(i=0;i<cnt;i++)
	{	
		printf("�ζǹ�ȣ �Է� : ");
		scanf("%d", &ary[i]);
			for(j=0;j<i;j++)
			{
				if(ary[i]==ary[j])
				{
					printf("���� ��ȣ�� �ֽ��ϴ�!\n");
					i--;
					break;
				}
			}
	}
	printf("�Էµ� �ζǹ�ȣ : ");
		
	for(i=0;i<cnt;i++)
		printf("%d ", ary[i]);
	
	return 0;	
}
