#include <stdio.h>

int get_weekday(int, int);
int get_days(int, int);
void disp_calender(int, int, int, int);

int mdays[12]={31,28,31,30,31,30,31,31,30,31,30,31};

int main()
{
	int year, month;
	int start;
	int days;
	
	printf("# Input Year, Month : "); 
	scanf("%d%d", &year, &month);

	start = get_weekday(year, month);
	days = get_days(year, month);
	disp_calender(year, month, start, days);

	return 0;
}

int get_weekday(int year, int month)
{
	int i,j;
	int cnt;
	int sum=0;
	int res;
	
	for(i=1; i<=(year-1); i++)
	{
		cnt = leap_check(i);
		if(cnt==1) sum += 366;
		else sum += 365;
	}
	
	for(j=0; j<(month-1); j++)
		sum += mdays[j];
	
	sum+=1;
	res = sum % 7; 
	
	return res;
}

int get_days(int year, int month)
{
	int cnt;
	
	cnt = leap_check(year);
	if(cnt==1)
		mdays[1] = 29;
	
	return mdays[month-1];
}

void disp_calender(int year, int month, int start, int days)
{
	printf("\n============<%d�� %d��>============\n\n", year, month);
	printf("------------------------------------\n");
	printf(" Sun  Mon  Tue  Wed  Thu  Fri  Sat\n");
	printf("------------------------------------\n");
	
	int i,j;
	int cnt;
	
	cnt=0;
	
	for(i=0; i<start; i++)
	{
		cnt++;
		printf("     ");
		if ((cnt%7)== 0)
			printf("\n");
	}
	
	for(j=1; j<=days; j++)
	{
		cnt++;
		printf("%3d  ", j);
		if ((cnt%7)== 0)
			printf("\n");
	}
}

int leap_check(int year)
{
	if(year%4!=0) return 0;
	else if(year%100!=0) return 1;
	else if(year%400==0) return 1;
	else return 0;
}

