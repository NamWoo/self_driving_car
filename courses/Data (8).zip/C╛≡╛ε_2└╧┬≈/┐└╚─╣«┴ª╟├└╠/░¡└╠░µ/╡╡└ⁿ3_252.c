#include<stdio.h>

void main()
{
	int lotto[6];
	int num=0, chk=0, cnt, test, i;
	
	cnt = sizeof(lotto)/sizeof(lotto[0]);
	
	while(1){
		printf("�ζǹ�ȣ �Է� : ");
		scanf("%d",&test);
		
		//���� ��ȣ üũ
		for(i=0; i<cnt; i++){
			if(num != i){
				if(test == lotto[i]){
					printf("���� ��ȣ�� �ֽ��ϴ�!\n");
					chk++;
				}				
			}
		}
		
		if(chk == 0){
			lotto[num] = test;
			//printf("lotto[%d]:%d\n",num,test);
			num++;
		}else{
			chk = 0;
		}
		
		if(num > 5) break;
		
	}
	
	printf("�Էµ� �ζǹ�ȣ : ");
	for(i=0; i<cnt; i++){
		printf("\t%d",lotto[i]);	
	}
	
}

/*

int main(void)
{
	int lotto[6];
	int num;
	int cnt = 0;
	int i;
	int dup;

	cnt = 0;
	while(cnt < 6)
	{
		printf("�ζǹ�ȣ �Է� : ");
		scanf("%d", &num);
		dup = 0;
		for(i=0; i<cnt; i++)
		{
			if(num == lotto[i])
			{
				dup = 1;
				break;
			}
		}
		if(dup == 0)
		{
			lotto[cnt] = num;
			cnt++;
		}
		else
		{
			printf("���� ��ȣ�� �ֽ��ϴ�!\n");
		}
	}

	printf("�Էµ� �ζǹ�ȣ : ");
	for(i=0; i<6; i++)
	{
		printf("%5d", lotto[i]);
	}

	return 0;
}

*/
