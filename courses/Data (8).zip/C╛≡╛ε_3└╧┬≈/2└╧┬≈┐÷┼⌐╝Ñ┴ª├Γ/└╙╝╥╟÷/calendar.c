#include<stdio.h>

int main(){
	
	int year, month;
	int last;
	int day;
	int i;
	
	while(1){
	
	printf("��, ���� �Է��ϼ���(����� 0) : ");
	scanf(" %d",&year);
	if(!year)
		break;
	scanf(" %d",&month);
	
	printf("\t    %d�� %d�� \n",year,month);
	printf("\t   =========== \n");
	printf("--------------------------------- \n");
	printf(" SUN MON TUE WED THU FRI SAT \n");
	printf("--------------------------------- \n");
	
	year--;
	last=365*year;
	last+=year/4;
	last-=year/100;
	last+=year/400;
	year++;
	
	for(i=1;i<month;i++){
		if(i==2)
			day=(!(year%400)||(year%100&&!(year%4)))?29:28;
 	
 		else day=i<=7?i%2?31:30:i%2?30:31;
		
		last+=day;
		
	}
	
	
	if(month==2)
		day=(!(year%400)||(year%100&&!(year%4)))?29:28;
 
 	else day=i<=7?i%2?31:30:i%2?30:31;
	
	for(i=0;i<=last%7;i++)
			printf("    ");
	
	for( i=1;i<=day;i++){
		if(!((last+i)%7))
			printf("\n");
			
		printf("  %2d",i);
	}
	

	printf("\n");
	
	
	
	
	
		
}
	return 0;
}




