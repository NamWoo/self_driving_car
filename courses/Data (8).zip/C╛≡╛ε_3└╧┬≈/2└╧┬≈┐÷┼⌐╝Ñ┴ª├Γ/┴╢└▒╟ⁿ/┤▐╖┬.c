#include <stdio.h>

int main()
{
	int year,month;
	int yy,day;
	int i,count,temp;
	int numOfDay;
	
	
	while(1)
	{
		numOfDay=0;
		printf("��, ���� �Է��ϼ���(����� 0) : ");
		scanf("%d%d",&year,&month);
		
		
		if(year == 0)
			break;
		
		printf("            %4d��   %2d��\n",year,month);
		printf("          ==================\n");
		printf("---------------------------------------\n");
		printf("  SUN  MON  TUE  WED  THU  FRI  SAT\n");
		printf("---------------------------------------\n");
		
		
		
			
		if(year%4 == 0)
		{
			if(year%100 == 0)
			{
				if(year%400 == 0)
					yy=1;
				else
					yy=0;
			}
			else
				yy=1;
		}
		else{
			yy =0;
		}
		
		for(i=1;i<year;i++)
		{
			if(i%4 == 0)
			{
				if(i%100 == 0)
				{
					if(i%400 == 0)
						numOfDay+=366;
					else
						numOfDay+=365;
				}
				else
					numOfDay+=366;
			}
			else
			{
				numOfDay+=365;
			}
		}
		
	//	printf("numOfDay : %d\n",numOfDay);
		for(i=1;i<month;i++){
			if( yy == 1)
			{
				switch(i)
				{
				case 1:
					numOfDay+=31;
					break;
				case 2:
					numOfDay+=29;
					break;
				case 3:
					numOfDay+=31;
					break;
				case 4:
					numOfDay+=30;
					break;
				case 5:
					numOfDay+=31;
					break;
				case 6:
					numOfDay+=30;
					break;
				case 7:
					numOfDay+=31;
					break;
				case 8:
					numOfDay+=31;
					break;
				case 9:
					numOfDay+=30;
					break;
				case 10:
					numOfDay+=31;
					break;
				case 11:
					numOfDay+=30;
					break;
				case 12:
					numOfDay+=31;
					break;
				}
				
			}
			else
			{
				switch(i)
				{
				case 1:
					numOfDay+=31;
					break;
				case 2:
					numOfDay+=28;
					break;
				case 3:
					numOfDay+=31;
					break;
				case 4:
					numOfDay+=30;
					break;
				case 5:
					numOfDay+=31;
					break;
				case 6:
					numOfDay+=30;
					break;
				case 7:
					numOfDay+=31;
					break;
				case 8:
					numOfDay+=31;
					break;
				case 9:
					numOfDay+=30;
					break;
				case 10:
					numOfDay+=31;
					break;
				case 11:
					numOfDay+=30;
					break;
				case 12:
					numOfDay+=31;
					break;
				}
			}
		}
	//0	printf("numOfDay : %d\n",numOfDay);
		numOfDay++;
		//printf("numOfDay = %d\n",numOfDay%7);
		
		if(yy == 1) //������ ���
		{
			switch(month)
			{
				case 1:
					temp=31;
					break;
				case 2:
					temp=29;
					break;
				case 3:
					temp=31;
					break;
				case 4:
					temp=30;
					break;
				case 5:
					temp=31;
					break;
				case 6:
					temp=30;
					break;
				case 7:
					temp=31;
					break;
				case 8:
					temp=31;
					break;
				case 9:
					temp=30;
					break;
				case 10:
					temp=31;
					break;
				case 11:
					temp=30;
					break;
				case 12:
					temp=31;
					break;					
			}
			
			i=0;
			count=1;
			while(count <= temp)
			{
				if(i>0 && i%7 == 0)
				{
					printf("\n");
				}
				
				if((numOfDay % 7 )> i && i<7)
					printf("     ");
				else
				{
					printf("%5d",count);
					count++;
				}
					
				
					
				i++;
			}
		}
		else
		{
		switch(month)
			{
				case 1:
					temp=31;
					break;
				case 2:
					temp=28;
					break;
				case 3:
					temp=31;
					break;
				case 4:
					temp=30;
					break;
				case 5:
					temp=31;
					break;
				case 6:
					temp=30;
					break;
				case 7:
					temp=31;
					break;
				case 8:
					temp=31;
					break;
				case 9:
					temp=30;
					break;
				case 10:
					temp=31;
					break;
				case 11:
					temp=30;
					break;
				case 12:
					temp=31;
					break;					
			}
			
			i=0;
			count=1;
			while(count <= temp)
			{
				if(i>0 && i%7 == 0)
				{
					printf("\n");
				}
				
				if((numOfDay % 7 )> i && i<7)
					printf("     ");
				else
				{
					printf("%5d",count);
					count++;
				}
					
				
					
				i++;
			}
		}
		
		printf("\n");
		
	}
	return 0;
}
