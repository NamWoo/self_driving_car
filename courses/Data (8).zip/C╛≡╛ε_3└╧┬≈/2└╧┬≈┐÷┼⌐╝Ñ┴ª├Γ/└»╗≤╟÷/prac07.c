
#include <stdio.h>
#include <string.h>

int mdays[12]={31,28,31,30,31,30,31,31,30,31,30,31};

int get_weekday(int year, int month);
int get_days(int year, int month);
void disp_calender(int year, int month, int start, int days);

int main() {

    int year, month;
    int start;  		// 1일이 출력되는 시작위치를 맞추기 위한 변수  ( 0 ~ 6이 될 수 있으며, 0의 경우 일요일)
    int days;		    // 각 월의 일 수를 저장할 변수

    // 입력 부분
    printf("# Input Year, Month : ");
    scanf("%d%d", &year, &month);

    // 출력할 년, 월에 해당하는 1일의 요일 계산
    start = get_weekday(year, month);

    // 출력할 달의 일수 계산
    days = get_days(year, month);

    // 달력 출력
    disp_calender(year, month, start, days);

    return 0;
}

int get_weekday(int year, int month) {
    int start;
    int last_year = year - 1;

    start = ((last_year + (last_year/4) - (last_year/100) + (last_year/400) + 1) % 7);

    for(int i = 1; i < month; i++) {
        start += mdays[i];
    }

    return start %= 7;
}

int get_days(int year, int month) {
    // 윤년 체크
    if (month == 2 && leap_check(year)) {
        mdays[1] = 29;
    }

    return mdays[month - 1];
}

void disp_calender(int year, int month, int start, int days) {
    printf("===================");
    printf("\n");
    printf("   %d 년 %d 월   ", year, month);
    printf("\n");
    printf("===================");
    printf("\n");
    printf(" ");
    printf("일");
    printf(" ");
    printf("월 ");
    printf(" ");
    printf("화");
    printf(" ");
    printf("수");
    printf(" ");
    printf("목 ");
    printf(" ");
    printf("금");
    printf(" ");
    printf(" 토");
    printf(" ");
    printf("\n");

    // 주단위 출력
    int weekly_routine = 0;
    for(int i = 0; i < days; i++) {

        if( weekly_routine % 7 == 0 && start == -1 ) {
            // 첫째 주 제외
            printf("\n");
            weekly_routine == 0;
        }

        if( i < start ) {
            printf(" ");
            printf(" ");
            printf(" ");
            i--;
            start--;
        } else if( i >= start ) {
            printf(" ");
            printf("%d", i+1);
            if(i < 10) printf(" ");
            start = -1;
        }

        weekly_routine++;
    }
}

// 윤년 검사 함수
int leap_check(int year)
{
    if(year%4!=0) return 0;
    else if(year%100!=0) return 1;
    else if(year%400==0) return 1;
    else return 0;
}