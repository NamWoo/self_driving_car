#include <stdio.h>
#include <time.h>

struct park
{
	int c_num;
	int time_in[6];
};

int show_menu(void);
void park_in(struct park (*space)[2][5]);
void park_out(struct park (*space)[2][5]);
void state(struct park (*space)[2][5]);
void info(struct park (*space)[2][5]);
void show_floor(struct park (*space)[5], int floor);
int empty(struct park (*space)[5], int floor);

int main(void)
{
	struct park space[3][2][5]={0};
	
	int sel;

	while(1)
	{
		sel = show_menu();
		
		switch(sel)
		{
			case 1:
				park_in(space);
				break;
			
			case 2:
				park_out(space);
				break;
			
			case 3:
				state(space);
				break;
				
			case 4:
				info(space);
				break;
			
			case 5:
				return 0;
			
			default:
				continue;
		}
	}
	
	
	return 0;
}

int show_menu(void)
{
	int n;

	printf("===================\n");
	printf(" 1. ����           \n");
	printf(" 2. ����           \n");
	printf(" 3. ���� ��Ȳ ��� \n");
	printf(" 4. ���� ���� ��� \n");
	printf(" 5. ����           \n");
	printf("===================\n");
	printf("��ȣ �Է� : ");
	scanf("%d", &n);
	printf("\n");

	return n;
}

void park_in(struct park (*space)[2][5])
{
	time_t timer = time(NULL);
	struct tm tm=*localtime(&timer);
	
	int i, cnt;
	int park_num, car_num, dir;
	int floor;

	printf("���� ��ȣ �Է� : ");
	scanf("%d", &car_num);
	printf("\n");

	printf("���� ���� ����");
	for(i=0;i<3;i++)
	{
		cnt = empty(space[i], i);
		printf("\nB%d�� : %d�ڸ� ", i+1, cnt);
	}
	printf("\n\n");

	i = 0;

	while(1)
	{
		show_floor(space[i], i);
		
		printf("���� ��ȣ �Է�(���� �� 0) : ");
		scanf("%d", &park_num);
		printf("\n");
		
		if(park_num!=0)
			break;

		if(i==0)
			dir=0;
		else if(i==2)
			dir=1;

		if(dir==0)
			i++;
		else
			i--;
	}

	space[i][(park_num-1)/5][(park_num-1)%5].c_num=car_num;
	
	space[i][(park_num-1)/5][(park_num-1)%5].time_in[0]=tm.tm_year+1900;
	space[i][(park_num-1)/5][(park_num-1)%5].time_in[1]=tm.tm_mon+1;
	space[i][(park_num-1)/5][(park_num-1)%5].time_in[2]=tm.tm_mday;
	space[i][(park_num-1)/5][(park_num-1)%5].time_in[3]=tm.tm_hour;
	space[i][(park_num-1)/5][(park_num-1)%5].time_in[4]=tm.tm_min;
	space[i][(park_num-1)/5][(park_num-1)%5].time_in[5]=tm.tm_sec;
	
	printf("================[���� �Ϸ�]=================\n\n");
}

void park_out(struct park (*space)[2][5])
{
	int car_num;

	time_t timer = time(NULL);
	struct tm tm=*localtime(&timer);
	
	printf("���� ��ȣ �Է� : ");
	scanf("%d", &car_num);
	printf("\n");

	for(int i=0;i<3;i++)
	{
		for(int j=0;j<2;j++)
		{
			for(int k=0;k<5;k++)
			{
				if(car_num==space[i][j][k].c_num)
				{
					space[i][j][k].c_num=0;
					
					printf("���� �Ⱓ : %d-%d-%d %d:%d:%d\n\n",
    					tm.tm_year-space[i][j][k].time_in[0]+1900, tm.tm_mon-space[i][j][k].time_in[1]+1, tm.tm_mday-space[i][j][k].time_in[2],
						tm.tm_hour-space[i][j][k].time_in[3], tm.tm_min-space[i][j][k].time_in[4], tm.tm_sec-space[i][j][k].time_in[5]);
		
					
					printf("================[���� �Ϸ�]=================\n\n");
					
					return;
				}
			}
		}
	}
}

void state(struct park (*space)[2][5])
{
	for(int i=0;i<3;i++)
	{
		show_floor(space[i], i);
	}
}

void info(struct park (*space)[2][5])
{
	int car_num;
	
	time_t timer = time(NULL);
	struct tm tm=*localtime(&timer);
	
	printf("���� ��ȣ �Է� : ");
	scanf("%d", &car_num);
	printf("\n");
	
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<2;j++)
		{
			for(int k=0;k<5;k++)
			{
				if(car_num==space[i][j][k].c_num)
				{
					printf("���� �ð� : %d-%d-%d %d:%d:%d\n",
    					space[i][j][k].time_in[0], space[i][j][k].time_in[1], space[i][j][k].time_in[2],
						space[i][j][k].time_in[3], space[i][j][k].time_in[4], space[i][j][k].time_in[5]);
					
					printf("���� �Ⱓ : %d-%d-%d %d:%d:%d\n\n",
    					tm.tm_year-space[i][j][k].time_in[0]+1900, tm.tm_mon-space[i][j][k].time_in[1]+1, tm.tm_mday-space[i][j][k].time_in[2],
						tm.tm_hour-space[i][j][k].time_in[3], tm.tm_min-space[i][j][k].time_in[4], tm.tm_sec-space[i][j][k].time_in[5]);
						
					return;
				}
			}
		}
	}
}

void show_floor(struct park (*space)[5], int floor)
{
	int num=1;

	printf("===================[B%d��]===================\n", floor+1);
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<5;j++)
		{
			if(space[i][j].c_num==0)
			{
				printf("%2d[    ] ", num);
			}
			else
			{
				printf("%2d[%d] ", num, space[i][j].c_num);
			}
			num++;
		}
		printf("\n");
	}
	printf("\n");
}

int empty(struct park (*space)[5], int floor)
{
	int cnt=0, num=0;

	for(int i=0;i<2;i++)
	{
		for(int j=0;j<5;j++)
		{
			if(space[i][j].c_num==0)
				cnt++;
			
			num++;
		}
	}

	return cnt;
}



