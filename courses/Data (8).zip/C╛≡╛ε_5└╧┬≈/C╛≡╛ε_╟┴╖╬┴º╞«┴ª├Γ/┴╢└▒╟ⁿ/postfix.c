#include <stdio.h>
#include <stdlib.h>

//Stack�� Queue�� �̿��� ��� 
typedef struct Node{
	char data[10];
	struct Node *next;
}Node;

//Queue
typedef struct Queue{
	Node *front;
	Node *rear;
	
	int count;
}Queue;
//Stack
typedef struct Stack{
	Node *top;
}Stack;

//Queue ���� �Լ� 
void QueueSet(Queue *queue);
int isEmpty(Queue *queue);
void enQueue(Queue *queue, char *arr); //arr���� ���Ŀ��� �и��Ǿ��� ���� Ȥ�� ������ 
void deQueue(Queue *queue,char *arr);

//stack ���� �Լ�
 
void StackSet(Stack *stack);
int isEmptyS(Stack *stack);
void push(Stack *stack, char *arr);
void pop(Stack *stack, char *arr);



int main()
{
	int i=0,j=0;
	char input[100];
	char output[10];
	int temp;
	char flag[10];
	char flag2[10]; 
	
	double result =0;
	
	Queue queue;
	Queue postfix;
	Stack stack;
	
	
	
	QueueSet(&queue);
	QueueSet(&postfix);
	StackSet(&stack);
	
	printf("input : ");
	gets(input);
	
//	printf("input check : %s\n",input);
	//�������� �Է� 
	while(input[i] != '\0')
	{
		switch(input[i])
		{
			case '+':
				flag[j] = '\0';
			//	printf("check num %s\n",flag);
				if(flag[0] != '\0')
					enQueue(&queue,flag);
				flag[0] = '+';
				flag[1] = '\0';
				enQueue(&queue,flag);
				j=0;
			break;
			case '-':
				
				flag[j] = '\0';
				enQueue(&queue,flag);
				flag[0] = '-';
				flag[1] = '\0';
				enQueue(&queue,flag);
				j=0;
				break;
			case '*':
				if(flag[0] != '\0')
					flag[j] = '\0';
				enQueue(&queue,flag);
				flag[0] = '*';
				flag[1] = '\0';
				enQueue(&queue,flag);
				j=0;
				break;
			case '/':
				flag[j] = '\0';
				enQueue(&queue,flag);
				flag[0] = '/';
				flag[1] = '\0';
				enQueue(&queue,flag);
				j=0;
				break;
			case '(':
				if( i != 0 )
				{
					flag[j] = '\0';
					enQueue(&queue,flag);
				}
				flag[0] = '(';
				flag[1] = '\0';
				enQueue(&queue,flag);
				j=0;
				break;
			case ')':
				flag[j] = '\0';
				if(flag[0] != '\0')
					enQueue(&queue,flag);
				flag[0] = ')';
				flag[1] = '\0';
				enQueue(&queue,flag);
				j=0;
				break;
			default:
			//	printf("check\n");
				flag[j] = input[i];
				j++;
				break;
		}
		
		i++;
		
		if(input[i] == '\0')
		{
			if(input[i-1] == ')')
				break;
			enQueue(&queue,flag);
			break;
		}
	}
	
	StackSet(&stack);
	printf("converting...\n"); 
	while(!isEmpty(&queue))
	{
	//	printf("check\n");
		deQueue(&queue,output);
		printf("dequeue : %s\n",output);
	}
	
	//���� ���� �Է� 
	
	while(isEmpty(&queue) != 0)
	{
		deQueue(&queue,flag);
		
		if(!strcmp(flag,"+") || !strcmp(flag,"-") )
		{
			printf("check!\n");
			if(isEmptyS(&stack) == 0)
				push(&stack,flag);
			else
			{
				if(! strcmp(stack.top->data,"+") || !strcmp(stack.top->data,"-") )
				{
					pop(&stack,flag2);
					enQueue(&postfix,flag2);
					push(&stack,flag);
				}
				else
				{
					push(&stack,flag);	
				}
			}
		}
		else if(!strcmp(flag,"*") || !strcmp(flag,"/"))
		{
			printf("check!\n");
			if(!strcmp(stack.top->data,"*") || !strcmp(stack.top->data,"/"))
			{
				pop(&stack,flag2);
				enQueue(&postfix,flag2);
				push(&stack,flag);
			}
			else
			{
				push(&stack,flag);
			}
		}
		else if(!strcmp(flag,"("))
		{
			enQueue(&postfix,flag);
		}
		else if(!strcmp(flag,")"))
		{
			while(1)
			{
				pop(&stack,flag2);
				enQueue(&postfix,flag2);
				if(!strcmp(flag2,"("))
					break;
			}
			
		}
		else
		{
			enQueue(&postfix,flag);
		}
	}
	
	while(isEmptyS(&stack) != 0)
	{
		pop(&stack,flag2);
		enQueue(&postfix,flag2);
	}
	
	printf("\n\npostfix --------\n");

	while(isEmpty(&postfix) != 0)
	{
		deQueue(&postfix,output);
		printf("%s ");
	}
	
	return 0;
}


void QueueSet(Queue *queue)
{
	queue->front = NULL;
	queue->rear = NULL;
	queue->count = 0;
}
int isEmpty(Queue *queue)
{
	int i;
	i = queue->count;
	
//	printf("check count %d\n",i);
	
	return i;
}
void enQueue(Queue *queue, char *arr)
{
	Node *temp = (Node *)malloc(sizeof(Node)); 
	strcpy(temp->data,arr);
	temp->next = NULL;
	
	//printf("enQueue check %s\n",temp->data);
	
	
	if(!isEmpty(queue))
		queue->front = temp;
	else
		queue->rear->next = temp;
		
	printf("enQueue check %s\n",temp->data);
	queue->rear = temp;
	queue->count++;
	//printf("current queue count : %d\n",queue->count);
		
}
void deQueue(Queue *queue,char *arr)
{
	Node *node;
	
//	printf("deQueue empty check : %d\n",isEmpty(queue));
	
	if(!isEmpty(queue))
		arr[0] = NULL;
	
	
	node = queue->front;
	
	strcpy(arr,node->data);
//	arr = node->data;
//	printf("check!\n");
	queue->front = node->next;
//	printf("check!\n");
//	printf("output data : %s,%s\n",arr,node->data);

		
	free(node);
	
	queue->count--;
	
}


// Stack �Լ�

void StackSet(Stack *stack)
{
	stack->top = NULL;
}
int isEmptyS(Stack *stack)
{
	if(stack->top == NULL)
		return 0;
	else
		return 1;
}
void push(Stack *stack, char *arr)
{
	Node *temp = (Node *)malloc(sizeof(Node));
	//printf("stack arr check : %s\n",arr);
	strcpy(temp->data,arr);
//	printf("stack input check : %s\n",temp->data);
	temp->next = stack->top;
	stack->top = temp;
}
void pop(Stack *stack, char *arr)
{
	Node *temp;
	
	if(!isEmptyS(stack))
		arr[0] = NULL;
		
	temp = stack->top;
	strcpy(arr,temp->data);
	
	//printf("pop arr check : %s\n",arr);
	stack->top = temp->next;
	
	free(temp);
}
