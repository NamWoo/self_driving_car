//�ּҷ� ���� ���α׷�

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct book{
	char *name;
	char *phone;
	char *email;
	char *note;
};

int enter_name(char *p, int *i){
	
	printf("�̸�[%d] : ", *i);
	gets(p);
	
	if(strcmp(p,"end") == 0) return 0;
	else return 1;
}

void enter_phone(char *p, int *i){
	
	do{
		printf("��ȣ[%d] : ", *i);
		gets(p);
		if(strlen(p) != 11){
			printf("�߸� �Է��ϼ̽��ϴ�.\n");
		}
	}while(strlen(p) != 11);
}

void enter_email(char *p, int *i){
	
	int j;
	int check;
	
	do{
		check = 0;
		
		printf("����[%d] : ", *i);
		gets(p);
		
		for(j = 0 ; j < strlen(p) ; j++){
			if(p[j] == '@' || p[j] == '.') check++;
		}
		if(check != 2) printf("��ȿ���� ���� �̸��� �ּ��Դϴ�.\n");
	}while(check != 2);
}

void enter_note(char *p, int *i){
	
	printf("���[%d] : ", *i);
	gets(p);
}

int main(void){
	
	struct book *arr;
	int size;
	int a,i ;
	
	do{
		printf("�Է� �� : ");		
		a = scanf("%d",&size);
		if(a != 1) printf("���ڸ� �Է��� �ּ���.\n");
		fflush(stdin);
	}while(a != 1);

	arr = (struct book*)malloc(sizeof(struct book)*size);
	if(arr == NULL){
		printf("�޸𸮰� �����մϴ�!\n");
		exit(1);
	}
	
	char *p_name[size];
	char *p_phone[size];
	char *p_email[size];
	char *p_note[size];
	
	for(i = 0 ; i < size ; i++){
		
		int *num = &i;
		arr[i].name = (char *)malloc(20);
		arr[i].phone = (char *)malloc(20);
		arr[i].email = (char *)malloc(20);
		arr[i].note = (char *)malloc(80);
		
		p_name[i] = arr[i].name;
		p_phone[i] = arr[i].phone;
		p_email[i] = arr[i].email;
		p_note[i] = arr[i].note;
		
		if(p_name[i]==NULL || p_phone==NULL || p_email==NULL || p_note==NULL){
			printf("�޸𸮰� �����մϴ�!\n");
			exit(1);
		}
		
		printf("\n���Ḧ ���Ͻø� 'end'�� �Է����ּ���.\n\n");
				
		if(enter_name(p_name[i],num) == 0) break;
		enter_phone(p_phone[i],num);
		enter_email(p_email[i],num);
		enter_note(p_note[i],num);
	}
	
	FILE *fp = fopen("book.txt","a");
	
	for(i = 0 ; i < size ; ++i){
		
		if(strcmp(arr[i].name,"end")==0) break;	
		printf("\n---------����[%d]----------\n",i);	
		printf("name [%d] : %s\n", i, p_name[i]);
		printf("phone[%d] : %s\n", i, p_phone[i]);
		printf("email[%d] : %s\n", i, p_email[i]);
		printf("note [%d] : %s\n", i, p_note[i]);
		
		fprintf(fp,"\nname [%d] : %s\n", i, p_name[i]);
		fprintf(fp,"phone[%d] : %s\n", i, p_phone[i]);
		fprintf(fp,"email[%d] : %s\n", i, p_email[i]);
		fprintf(fp,"note [%d] : %s\n", i, p_note[i]);
		
		free(arr[i].name);
		free(arr[i].phone);
		free(arr[i].email);
		free(arr[i].note);
	}
		
	free(arr);
	fclose(fp);
	
	return 0;
}
