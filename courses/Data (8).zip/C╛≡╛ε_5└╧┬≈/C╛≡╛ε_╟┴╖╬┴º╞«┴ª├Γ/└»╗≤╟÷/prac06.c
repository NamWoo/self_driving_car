#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// 스터티룸 예약 시스템

int disp_menu(void);
void init_bookings(void);
void add_schedule(void);
void show_schedule(void);
void reset_schedule(void);

struct Room {
    char name[50];
    int number;
    int capacity;
};

struct Room *Schedule[50];
int book_numbers = 0;

int main(void) {
    init_bookings();
    int selection;

    while (1)
    {
        selection = disp_menu();
        fflush(stdin);
        if (selection == 0) break;

        switch (selection)
        {
            case 1:
                add_schedule();
                break;
            case 2:
                show_schedule();
                break;
            case 3:
                reset_schedule();
                break;
            default:
                printf("@ 메뉴 번호가 아닙니다!\n\n");
                break;
        }
    }

    return 0;
};

// 메뉴 출력 후 선택 번호 반환
int disp_menu(void)
{
    int num;

    printf("\n===[ 스터디룸 예약 시스템 ]===\n");
    printf("1. 회의실 예약\n");
    printf("2. 예약 상태 조회\n");
    printf("3. 스케쥴 리셋\n");
    printf("0. 종료\n");
    printf("---------------------------\n");

    printf("> 번호 선택 : ");
    scanf("%d", &num);

    return num;
}

void init_bookings(void) {

    int i;

    for (i = 0; i < 20; i++)    // 요소 개수만큼 반복
    {
        Schedule[i] = malloc(sizeof(struct Room));    // 각 요소에 구조체 크기만큼 메모리 할당
    }
}

void add_schedule(void) {

    char name[50];
    int room, numbers;

    // 버퍼 비우는 코드
    while( getchar() != '\n' );

    fputs("> 이름을 입력하세요. ", stdout);
    fgets(name, sizeof(name), stdin);
    printf("\n");

    printf("> 스터디룸을 선택하세요. [1-5] ");
    scanf("%d", &room);
    printf("\n");

    printf("> 인원을 입력하세요. [1-5] ");
    scanf("%d", &numbers);
    printf("\n");

    if(Schedule[book_numbers] != NULL) {

        strcpy(Schedule[book_numbers]->name, name);
        Schedule[book_numbers]->capacity = numbers;
        Schedule[book_numbers]->number = book_numbers + 1;

        printf("Name: %s", Schedule[book_numbers]->name);
        printf("\n");
        printf("Capacity: %d", Schedule[book_numbers]->capacity);
        printf("\n");
        printf("Booking Number: %d", Schedule[book_numbers]->number);
        printf("\n");

        book_numbers++;
    }

    printf("예약이 완료되었습니다.\n");

};

void show_schedule(void) {

    int i;

    printf("=========================\n");

    for(i = 0; i < book_numbers; i++) {

        if(Schedule[i] != NULL) {

            printf("\n");
            printf("부킹넘버: %d\n", Schedule[i]->number);
            printf("인원: %d\n", Schedule[i]->capacity);
            printf("예약자: %s\n", Schedule[i]->name);
            printf("\n");

        }

    }

    printf("=========================\n");
};

void reset_schedule(void) {

    int i;

    for (i = 0; i < 50; i++) {
        free(Schedule[i]);
    }

    printf("에약이 초기회 되었습니다.\n");
}