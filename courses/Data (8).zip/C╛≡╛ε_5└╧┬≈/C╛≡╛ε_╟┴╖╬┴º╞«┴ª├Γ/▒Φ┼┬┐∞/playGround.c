#include "week1/190517/190517_project.h"

int main() {
	main_of_project();
	return 0;
}


