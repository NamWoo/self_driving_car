#include <stdio.h>


int main(){
	
	int map[5][6]={0};
	 
	int i,j;
	int su=1;
	
	for( i=0;i<4;i++)
	for(j=0;j<5;j++ ){
			map[i][j]=su;
			map[4][5]+=su++; 
				}

	for(i=0;i<4;i++)
	for(j=0;j<5;j++)
	map[i][5]+=map[i][j];
	
	for(j=0;j<5;j++)
	for(i=0;i<4;i++)
	map[4][j]+=map[i][j];
	
	for( i=0;i<5;i++){
	
	for(j=0;j<6;j++ )
	printf("%5d",map[i][j]);
	
	printf("\n");
}
	
	
	return 0;

}




