#include <stdio.h>
#include <string.h>

int main(void)
{
	int ary[5][6];
	int i, j, num=1;
	
	for(i=0;i<4;i++)
	{
		for(j=0;j<5;j++)
		{
			ary[i][j]=num;
			num++;
		}
	}
	
	for(i=0;i<4;i++)
	{
		num=0;
		for(j=0;j<5;j++)
		{
			num+=ary[i][j];
		}
		ary[i][5]=num;
	}
	
	for(j=0;j<5;j++)
	{
		num=0;
		for(i=0;i<4;i++)
		{
			num+=ary[i][j];
		}
		ary[4][j]=num;
	}
	
	num=0;
	for(i=0;i<4;i++)
	{
		num+=ary[i][5];
	}
	
	ary[4][5]=num;
	
	for(i=0;i<5;i++)
	{
		
		for(j=0;j<6;j++)
		{
			printf("%d\t",ary[i][j]);
		}
		printf("\n");
	}
}
