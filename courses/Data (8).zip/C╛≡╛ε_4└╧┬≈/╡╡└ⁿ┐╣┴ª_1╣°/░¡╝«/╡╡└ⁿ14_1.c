#include <stdio.h>

int main()
{
	char arr[5][6]={0,};
	
	int cnt=1;
	
	for(int i=0;i<4;i++)
	{
		for(int j=0;j<5;j++)
		{
			arr[i][j]=cnt;
		
			arr[i][5]+=arr[i][j];
			arr[4][j]+=arr[i][j];
			arr[4][5]+=arr[i][j];
			
			cnt++;
		}
	}
	
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<6;j++)
		{
			printf("%8d",arr[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}


