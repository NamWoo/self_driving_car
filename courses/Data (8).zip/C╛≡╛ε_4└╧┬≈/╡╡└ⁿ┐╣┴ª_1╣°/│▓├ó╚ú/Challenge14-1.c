#include <stdio.h>
int a[5][6] = {0};
int main(){
	
	
	int i, j;
	int num = 1;
	for(i = 0; i < 4; i++){
		for(j = 0; j < 5; j++){
			a[i][j] = num++;
		}
	}
	
	for(i = 0; i < 4; i++){
		for(j = 0; j < 5; j++){
			a[i][5] += a[i][j];
		}
	}
	
	for(j = 0; j <= 5; j++){
		for(i = 0; i < 4; i++){
			a[4][j] += a[i][j];
		}
	}
	
	for(i = 0; i < 5; i++){
		for(j = 0; j < 6; j++){
			printf("%4d", a[i][j]);
			if(j == 5){
				printf("\n");
			}
		}
	}
	
	return 0;
}
