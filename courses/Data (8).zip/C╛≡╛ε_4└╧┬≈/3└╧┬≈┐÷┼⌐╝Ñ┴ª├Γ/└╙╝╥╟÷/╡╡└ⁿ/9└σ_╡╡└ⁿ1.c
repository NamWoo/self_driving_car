#include <stdio.h>


void func(int *pmod, int *prem){
	int num;
	printf("����Է� : ");
	scanf(" %d",&num);
	
	*pmod=num/4;
	*prem=num%4;
	
	
	
	return 0;
}




int main(){
	
	int mod,rem;
	func(&mod,&rem);
	printf("�� : %d, ������ : %d",mod, rem);
	
	
	
	return 0;
}
