#include <stdio.h>

char num[46];

void input_nums(int *lotto_nums);
void print_nums(int *lotto_nums);



int main(){
	
	int lotto_nums[6];
	
	input_nums(lotto_nums);
	print_nums(lotto_nums);

	
	return 0;
}

void input_nums(int *lotto_nums){
	int i;
	int n;
	
	for(i=0;i<6;){
		printf("��ȣ �Է� : ");
		scanf(" %d",&n);
		
		if(num[n]){
			printf("���� ��ȣ�� �ֽ��ϴ�!\n");
			continue;
		} 
		num[n]=1;
		lotto_nums[i]=n;
		i++;
	}
	
}
void print_nums(int *lotto_nums){
	
	int i;
	
	printf("�ζ� ��ȣ :");
	
	for(i=0;i<6;i++)
	{
		printf(" %d ",lotto_nums[i]);	
	}
	
	printf("\n");
}


