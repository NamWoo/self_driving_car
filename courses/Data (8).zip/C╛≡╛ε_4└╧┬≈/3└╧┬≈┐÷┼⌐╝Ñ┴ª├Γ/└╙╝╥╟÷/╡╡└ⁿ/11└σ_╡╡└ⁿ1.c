#include <stdio.h>

//int check_same(int *lotto_nums,int *my_nums);

int main(){
	
	char arr;
	int flag;
	int num,max;
	
	do{	
		num=0;
		do{
			flag = scanf("%c",&arr);
			num++;
		}while(!(arr==10||flag==-1));
		
		max=max<num?num:max;
		
		}while(flag!=-1); 
	
	
	printf("���� �� �ܾ��� ���� : %d",max-1);
	
	
	return 0;
}

/*
int check_same(int *lotto_nums,int *my_nums){
	int re=0;
	int i,j;
	
	for(i=0;i<6;i++){
		for(j=0;j<6;j++){
			if(lotto_nums[i]==my_nums[j])
				re++;
		}
	}
	
	
	return re;
	
}*/


