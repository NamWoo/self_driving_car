#include "stdafx.h"
#include "MyIterator.h"

CMyIterator::CMyIterator(void)
	: m_pHead(NULL), m_pCurrent(NULL)
{
}

CMyIterator::~CMyIterator(void)
{
}