# eswcontest
2019 임베디드 소프트웨어 경진대회 


|||
|:---:|:---:|
|[preplanning](./01_Preplanning/readme.md)
|Executing||
|Controlling||
