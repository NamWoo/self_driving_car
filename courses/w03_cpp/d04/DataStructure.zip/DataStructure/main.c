#include <stdio.h>
#include "list.h"
#include "heap.h"
#include "queue.h"

int main()
{
    
    
    return 0;   
}
