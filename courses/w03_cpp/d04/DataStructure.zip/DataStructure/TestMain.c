#include <stdio.h>
#include "queue.h"
#include "heap.h"
#include "list.h"
#include "TEST_MACRO.h"

#include <malloc.h>
#include <memory.h>
#include <assert.h>

int main()
{
    List* myList = (List*)malloc(sizeof(List));
    InitList(myList);

    TEST_START(리스트초기화);
    assert(myList->Head ==NULL) ;
    assert(myList->Tail ==NULL) ;
    STAGE_CLEAR(리스트 초기화);
    PRINT_SCORE(10);

    TEST_START(리스트 삽입);
    Node* n1 = (Node*)malloc(sizeof(Node));
    Node* n2 = (Node*)malloc(sizeof(Node));
    n1->Data = 100;
    n2->Data = 200;
    
    assert(InsertNodeIntoList(n1,0,myList)==0);
    assert(InsertNodeIntoList(n2,0,myList)==0);
    STAGE_CLEAR(리스트 삽입 성공);
    PRINT_SCORE(30);

    TEST_START(인덱스데이타 얻어오기);
    assert(GetIdxData(myList,0)==100);
    assert(GetIdxData(myList,1)==200);
    STAGE_CLEAR(인덱스 데이터 얻어오기);
    PRINT_SCORE(50);

    TEST_START(사이즈 반환);
    assert(GetListSize(myList)==2);
    STAGE_CLEAR(사이즈반환);
    PRINT_SCORE(70);

    TEST_START(리스트 제거);
    assert(DestroyList(myList)==0);
    PRINT_SCORE(100);
}