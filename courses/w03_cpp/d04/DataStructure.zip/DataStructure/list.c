#include <malloc.h>
#include <stdlib.h>
#include <stdio.h>
#include "list.h"
#include <assert.h>
#include "TEST_MACRO.h"

//  리스트 초기화하기 (초기화할 리스트 받기, 동적할당 해제를 해주는 함수등록하기)
void InitList(List* list)
{
    list->Head = NULL;
    list->Tail = NULL;
}


//  리스트 제거하기 제거할게 없으면 -1 반환 성공시 0
int DestroyList(List* list)
{
    if(list->Head==NULL)
    {
        return -1;
    }
    while(list->Head->Next!=NULL)
    {
        Node* temp = list->Head->Next;
        free(list->Head = NULL);
        list->Head = temp;
    }
    return 0;
}

// 노드를 idx 번쨰에 리스트에 넣는다 (idx 위치에 노드가 위치하게됨) 실패시 -1, 성공시 0반환, 
int InsertNodeIntoList(Node* element,int idx, List* list)
{
    int cIdx=0;
    Node* tempNode = list->Head;
    while(1)
    {
        if(list->Head==NULL)
        {
            list->Head = element;
            element->Next = list->Tail;
            break;
        }
        if(cIdx++ == idx)
        {
            element->Next = tempNode->Next;
            tempNode->Next = element;
            break;
        }
        tempNode = tempNode->Next;
        if(tempNode==NULL)
        {
            return -1;
        }
    }
    return 0;
    
}

// 리스트의 사이즈를 반환
int GetListSize(List* list)
{
    int size = 0;
    Node* temp = list->Head;
    while(temp!=list->Tail)
    {
        temp = temp->Next;
        ++size;
    }
    return size;
}

//idx 번째의 노드의 데이터를 가져온다
int GetIdxData(List* list, int idx)
{
    int cIdx=0;
    Node* temp  = list->Head;
    while(cIdx!=idx)
    {   
        temp = temp->Next; 
    }
    return temp->Data;
}

void TestList()
{



}
