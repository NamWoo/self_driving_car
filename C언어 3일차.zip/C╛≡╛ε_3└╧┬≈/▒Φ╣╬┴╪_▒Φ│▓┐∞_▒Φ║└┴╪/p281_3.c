#include<stdio.h>

void rotate(int *pa, int *pb, int *pc)
{
	int temp;
	
	temp = *pa;
	
	*pa = *pb;
	*pb = *pc;
	*pc = temp;
	
}

int main(void)
{
	int i ;
	int flag = 10;
	
	int a = 1;
	int b = 2;
	int c = 3;
	
	int *pa = &a;
	int *pb = &b;
	int *pc = &c;
	
	while(1){		
		
		if(flag != 10){
			break;
		}
		printf("%d:%d:%d",*pa,*pb,*pc); 
		rotate(&pa, &pb, &pc);
		
		scanf("%c",&flag);	
	}
	
	return 0;
		
}
