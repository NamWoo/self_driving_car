#include <stdio.h>

void rotate(int *pa,int *pb, int *pc)
{
	char input;
	int temp;
	printf("%d:%d:%d\n",*pa,*pb,*pc);
	scanf("%c",&input);
	
	
	while(input== 10){
		
		temp = *pa;
		*pa = *pb;
		*pb = *pc;
		*pc = temp; 
		
		printf("%d:%d:%d\n",*pa,*pb,*pc);
		scanf("%c",&input);
		
	}
}

int main()
{
	int a=1,b=2,c=3;
	
	
	rotate(&a,&b,&c);
	
	
		
	return 0;
}
