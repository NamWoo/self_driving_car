//calendar

int det_yoon(int year){
	
	int det = 0;
	
	if(year%4 == 0){
		det = 1;
		if(year%100 == 0){
			det = 0;
			if(year%400 == 0){
				det = 1;
			}
		}
	}
		
	return det;
}


int day_counter(int year, int month)
{
	int t_day_y, t_day_m, t_day;
	int i,j;
	
	//day count(untill year-1)
	for(i = 1 ; i < year ; i++){
		if(det_yoon(year) == 1) t_day_y += 366;
		else t_day_y += 365;
	}
	
	for(j = 1; j < month ; j++){
		if(j%2 == 0 && j < 8){
			if(j == 2){
				if(det_yoon(year)==1) t_day_m += 29;
				else t_day_m += 28;
			}
			else t_day_m += 30;
		}
		else if(j%2 == 1 && j < 8){
			t_day_m += 31;
		}
		else if(j%2 == 0 && j >= 8){
			t_day_m += 31;
		}
		else if(j%2 == 1 && j >= 8){
			t_day_m += 30;
		}
	}
	
	t_day = t_day_y + t_day_m;
	
	return t_day;
}


void draw_cal(int year, int month, int num_days)
{	
	int rem;
	int i, j;
	int end_day;
	
	rem = num_days%7;
	
	//end_day
	if(month%2 == 0 && month < 8){
		if(month == 2){
			if(det_yoon(year)==1) end_day = 29;
			else end_day = 28;
		}
			else end_day = 30;
	}
	else if(month%2 == 1 && month < 8){
		end_day = 31;
	}
	else if(month%2 == 0 && month >= 8){
		end_day = 31;
	}
	else if(month%2 == 1 && month >= 8){
		end_day = 30;
	}
	
	for(i = 1 ; i <= 35 ; i++){
		
		if((i-rem) > end_day){
			printf("\n");
			printf("\n");
			break;
		}
		
		if(i <= rem){
			printf("      ");
			continue;
		}
		
		printf("%2d    ",i-rem);
		
		if(i%7 == 0){
			printf("\n");
		}
	}
	
}


int main(void)
{
	int year, month;
	
	while(1){
		printf("��, ���� �Է��ϼ���(����� 0) :");
		scanf("%d %d",&year,&month);
		
		if(year == 0) break;
		
		printf("\n");
		printf("                 %d��  %d��              \n",year,month);
		printf("            ===================          \n");
		printf("-----------------------------------------\n");
		printf(" SUN   MON   TUE   WED   THU   FRI   SAT \n");
		printf("-----------------------------------------\n");
		
		//test_function
		draw_cal(year, month, day_counter(year,month));
	}
	
	return 0;
}
