#include<stdio.h>

int main(void)
{
	int num[6] = {0, 0, 0, 0, 0, 0};
	int i, j;
	int temp;
	
	for(i = 0 ; i < 6 ; i++){
		printf("�ζǹ�ȣ �Է� : ");
		scanf("%d", &num[i]);
		
		for(j = 0 ; j < 6 ; j++){
			if(num[i] == num[j] && i != j){
				printf("���� ��ȣ�� �ֽ��ϴ�! \n");
				i -= 1;
				break;
			}
		}		
	}
	
	printf("�Էµ� �ζ� ��ȣ : \t");
	for(j = 0 ; j < 6 ; j++){
		printf("%d\t", num[j]);
	}
	
	return 0;
}
