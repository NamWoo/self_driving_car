#include<stdio.h>
/*
int max(int ary[]){
	
	int i, len;
	int max = ary[0];
	
	len = sizeof(ary)/sizeof(ary[0]);
	
	for(i = 0 ; i < len ; i++){
		max = (ary[i]>max)? ary[i]:max ;
	}
	
	return max;
}

int min(int ary[]){
	
	int i, len;
	int min = ary[0];
	
	len = sizeof(ary)/sizeof(ary[0]);
	
	for(i = 0 ; i < len ; i++){
		min = (ary[i]<min)? ary[i]:min ;
	}
	
	return min;
}
*/

int main(void){
	
	int ary[5]={0};
	int i, len;
	double avg;
	int max, min;
	
	int sum = 0;
	
	printf("5���� �ɻ������� ���� �Է� : ");	
	for(i = 0 ; i < 5 ; i++){
		scanf("%d",&ary[i]); 
	}
	
	len = sizeof(ary)/sizeof(ary[0]);
	
	max = ary[0];
	min = ary[0];
	
	for(i = 0 ; i < len ; i++){
		if(ary[i] > max){
			max = ary[i];
		}
		if(ary[i] < min){
			min = ary[i];
		}
	}
	
	printf("��ȿ���� : \t");

	for(i = 0 ; i < 5 ; i++){
		
		sum += ary[i];
		
		if(max == ary[i] || min == ary[i]) continue;
		printf("%d\t", ary[i]);
	}
	printf("\n");
	
	
	avg = (sum-max-min)/(float)(len-2);
	
	printf("���� : %d\n", sum);
	printf("��� : %.1f", avg);
	
	return 0;
}
