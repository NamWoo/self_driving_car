#include<stdio.h>
//#include<stdlib.h>
int map[200][200];
int go_n, back_n;
int num,pp,st,ed;
	
void go(int via, int s){
	int j;
	
	for(j=s;j<num;j++)
        
		if(map[s][j]>=pp){
			if(j==ed)
				go_n++;       
			else
				if(via<=3)
					go(via+1,j);	
		}

}


void back(int via,int s){
	
	int i;

	for(i=s;i>=0;i--)
		if(map[s][i]>=pp){
			if(i==st)
				back_n++;		
			else
				if(via<=3)
                    back(via+1,i);
                
		}
	
	

    
	return;
	
}

int main(){
	
	int t;
	int tc;

	int i,j;

	scanf(" %d",&t);
	
	for(tc=1;tc<=t;tc++){
		
		go_n=0;back_n=0;
		
		scanf(" %d %d %d %d",&num,&pp,&st,&ed);
		
		st--;
		ed--;
		
		for(i=0;i<num;i++)
			for(j=0;j<num;j++)
				scanf(" %d",&map[i][j]);
		
		go(0,st);
		back(0,ed);
		
		
		
		
		printf("#%d %d %d",tc,go_n,back_n);
	}
	
	
	return 0;
}
