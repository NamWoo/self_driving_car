#include<stdio.h>

int leapyear(int n){
	if(n%4!=0) return 0;
	if(n%100==0 && n%400!=0) return 0;
	return 1;
}
void print_calendar(int year, int month){
	printf("\n\t%4d�� %2d��\n",year,month);
	printf("\t===========\n");
	printf("----------------------------\n");
	printf(" SUN MON TUE WED THU FRI SAT\n");
	printf("----------------------------\n");
	
	int i;
	int total=0;
	for(i=1;i<year;i++){
		if(leapyear(i)) total+=366;
		else total+=365;
	}
	
	int ary[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
	total++;
	for(i=1;i<month;i++){
		total+=ary[i];
	}
	if(leapyear(year)){
		ary[2]++;
		if(month>2) total++;
	}
	
	int s=total%7;
	int day=1;
	
	while(day<=ary[month]){
		printf(" ");
		
		for(i=0;i<7;i++){
			if(day==1 && i<s)
			  printf("    ");
			else{
				printf("%3d ",day);
				day++;
			}
			if(day>ary[month]) break;	  
		}
		printf("\n");
	}
	printf("\n");
}

int main(void){
	
	while(1){
		int year, month;
		printf("> ��, ���� �Է��ϼ���(����� 0) : ");
		
		scanf("%d",&year);
		if(year==0) break;
		
		scanf("%d",&month);
		print_calendar(year,month);
	}
}
