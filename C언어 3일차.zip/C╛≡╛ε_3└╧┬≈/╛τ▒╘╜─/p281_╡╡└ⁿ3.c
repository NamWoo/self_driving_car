#include <stdio.h>

void rotate(int *pa, int *pb, int *pc)
{
	char enter;
	int temp;
		while(1){
		scanf("%c",&enter);
		if(enter=='\n'){
			printf("%d : %d : %d",*pa,*pb,*pc);
				temp = pa;
				pa = pb;
				pb = pc;
				pc = temp;
		}
		else
		break;
	}				
}

int main()
{
	int a=1;
	int b=2;
	int c=3;
	rotate(&a, &b, &c);

	return 0;
}
