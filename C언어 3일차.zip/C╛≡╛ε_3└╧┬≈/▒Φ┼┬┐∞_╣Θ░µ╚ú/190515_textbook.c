#define _CRT_SECURE_NO_WARNINGS
#define __TEXTBOOK_190515__
#ifdef __TEXTBOOK_190515__

#include <stdio.h>

void rotate(int *pa, int *pb, int *pc) {

	while (1) {
		char c;
		scanf("%c", &c);
		if (c == '\n') {
			printf("%d:%d:%d", *pa, *pb, *pc);
			int *temp = pa;
			pa = pb;
			pb = pc;
			pc = temp;
		}
		else {
			break;
		}
		
	}
}

int main() {
	int a = 1;
	int b = 2;
	int c = 3;
	rotate(&a, &b, &c);
	return 0;
}


#endif