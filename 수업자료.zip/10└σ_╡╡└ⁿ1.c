#include <stdio.h>


void print_graph(int *ps, int size){
	
	int i;
	int j;
	
	for(i=0;i<size;i++){
		printf("(%3d) ",ps[i]);
		
		for(j=0;j<ps[i]/5;j++)
			printf("*");
			
		printf("\n");
			
	}
	
	
	
	return 0;
}




int main(){
	
	int score[5]={72,88,95,64,100}; 
	print_graph(score,5);
	
	
	
	return 0;
}
