int main(void){
	
	char *prt[]={"red","orange","pink","white","blue","brown","black","gray"};
	
	printf("%c\n",**prt); //r
	printf("%s\n",prt[1]); //orange
	printf("%s\n",prt[1]+3); //nge
	printf("%c\n",*(*(prt+1)+1)); //r
	printf("%c\n",(*(*(prt+2)+1))); //i
	printf("%s\n",prt[3]+2); //ite
		
	
}

*(*(prt+1)+1))

(prt+1) // orange



*(*(prt+1)+1))

*(*(prt+1)+1))
