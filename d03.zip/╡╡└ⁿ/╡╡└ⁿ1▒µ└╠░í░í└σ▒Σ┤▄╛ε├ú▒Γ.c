#include <stdio.h>

int main(void)
{
	char word;
	
	word = getchar();
	printf("%c",word);
	
	return 0;
}
